// Jodel Zero — JodelZeroApp.swift
// نقطة الدخول: تُنشأ `AppStore` مرة واحدة هنا (مصدر الحقيقة الوحيد)
// وتُحقن في كل الشاشات عبر `.environmentObject`.
// يفتح التطبيق مباشرة على الخلاصة — بلا دخول، بلا كود تفعيل، بلا جدار دفع.
// SwiftUI + Foundation فقط، iOS 16+، بلا اعتماديات خارجية.

import SwiftUI

@main
struct JodelZeroApp: App {
    /// مصدر الحقيقة الوحيد — يُنشأ مرة في بنية التطبيق، أبداً داخل جسم شاشة.
    @StateObject private var store = AppStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .preferredColorScheme(store.profile.darkMode ? .dark : .light)
                .environment(\.locale, Locale(identifier: store.profile.language.rawValue))
        }
    }
}
