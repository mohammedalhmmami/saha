import SwiftUI
import UIKit

/// محادثة فردية: فقاعات الرسائل، فايب الطرف الآخر في الأعلى مع محرر «وش جوّك؟»
/// لفايب الخاص بي، وملصقات، ومشاركة وسائط بموافقة متبادلة.
/// النصوص العربية من `ar.lproj/Localizable.strings` حرفياً:
/// `chat_connect_edit_profile_emoji_selection_title` = «وش جوّك؟»،
/// `chat_connect_edit_profile_emoji_preview_common_title` = «يا سلام، توافق سلس 💫»،
/// `newstack_chat_push_notification_activation` = «يريد %@ البدء في مشاركة محتوى مرئي ومسموع في محادثتكما الخاصّة»،
/// `chat_block_button` = «🚫 أحظر المستخدم».
///
/// الوسائط: التطبيق محلي أولاً ولا يرفع أي صورة حقيقية. رسالة الوسائط تُمثَّل
/// برمز SF Symbol (`imageSymbol`) + تعليق نصي فقط، وتُرسل عبر
/// `store.sendMessage(to:text:isMedia:)` — وهذا موثّق هنا بصراحة لا كرفع فعلي.
/// الموافقة المتبادلة: لا تُرسل وسائط قبل موافقة الطرفين؛ حالة الموافقة
/// تُحفظ محلياً لكل محادثة (لا خادم)، وزر «قبول الطرف الآخر» موسوم صراحةً
/// بأنه تجربة محلية فقط لاختبار التدفق على جهاز واحد.
struct ChatView: View {
    let conversation: Conversation

    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss

    @State private var draft = ""
    @State private var showVibeEditor = false
    @State private var showConsentSheet = false
    @State private var showMediaComposer = false
    @State private var showStickerPicker = false
    @State private var showBlockConfirmation = false
    @State private var showBlockedAlert = false
    @State private var selectedStickerPack = "emojis"

    /// فايب الخاص بي — محلي فقط (نموذج `Conversation.vibe` هو فايب الطرف الآخر).
    @AppStorage("com.nebra.saha.myVibe") private var myVibe = "😀"
    /// حالة الموافقة على الوسائط لكل محادثة: "requested" أو "consented" (JSON محلي).
    @AppStorage("com.nebra.saha.mediaConsent") private var consentData = ""

    /// المحادثة الحية من المتجر حتى تنعكس الرسائل الجديدة فوراً.
    private var liveConversation: Conversation {
        store.conversations.first(where: { $0.id == conversation.id }) ?? conversation
    }

    private var consentState: String {
        MediaConsentStore.state(for: conversation.id, in: consentData)
    }

    /// الموافقة مكتملة: موافقة محلية مسجلة، أو رسالة وسائط سابقة بموافقة.
    private var mediaConsented: Bool {
        consentState == "consented"
            || liveConversation.messages.contains { $0.isMedia && $0.mediaConsented }
    }

    private var mediaRequested: Bool { consentState == "requested" }

    var body: some View {
        VStack(spacing: 0) {
            vibeHeader

            if liveConversation.isBlocked {
                Label("هذه المحادثة محظورة. لن تصلك رسائل جديدة منها.", systemImage: "nosign")
                    .font(.caption)
                    .foregroundStyle(.red)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.red.opacity(0.08))
            }

            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 10) {
                        if liveConversation.messages.isEmpty {
                            Text("ابدأ المحادثة برسالة طيبة — تذكّر أن الطرف الآخر شخص حقيقي مثلك.")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.center)
                                .frame(maxWidth: .infinity)
                                .padding()
                        }
                        ForEach(liveConversation.messages) { message in
                            MessageBubble(message: message)
                                .id(message.id)
                                .frame(maxWidth: .infinity, alignment: message.isMine ? .trailing : .leading)
                        }
                    }
                    .padding()
                }
                .onAppear {
                    scrollToLast(proxy: proxy)
                }
                .onChange(of: liveConversation.messages.count) { _ in
                    withAnimation { scrollToLast(proxy: proxy) }
                }
            }

            if showStickerPicker {
                stickerPicker
            }

            inputBar
        }
        .navigationTitle(liveConversation.otherTag)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button("وش جوّك؟") { showVibeEditor = true }
                    Button(role: .destructive) {
                        showBlockConfirmation = true
                    } label: {
                        Label("🚫 أحظر المستخدم", systemImage: "nosign")
                    }
                } label: {
                    Label("خيارات المحادثة", systemImage: "ellipsis.circle")
                }
            }
        }
        .confirmationDialog("🚫 أحظر المستخدم", isPresented: $showBlockConfirmation, titleVisibility: .visible) {
            Button("🚫 أحظر المستخدم", role: .destructive) {
                store.blockUser(tag: liveConversation.otherTag)
                showBlockedAlert = true
            }
            Button("إلغاء", role: .cancel) {}
        } message: {
            Text("لن يتمكن هذا الشخص من بعث رسائل أو طلبات جديدة لك وسيتم حذف المحادثة آليا.")
        }
        .alert("تم حظر المستخدم", isPresented: $showBlockedAlert) {
            Button("حسناً") { dismiss() }
        } message: {
            Text("تم حظر \(liveConversation.otherTag).")
        }
        .sheet(isPresented: $showVibeEditor) {
            VibeEditorSheet(myVibe: $myVibe, otherVibe: liveConversation.vibe)
        }
        .sheet(isPresented: $showConsentSheet) {
            MediaConsentSheet(
                otherTag: liveConversation.otherTag,
                requested: mediaRequested,
                onRequest: {
                    store.requestMediaConsent(in: liveConversation)
                    MediaConsentStore.set("requested", for: conversation.id, data: &consentData)
                },
                onLocalAccept: {
                    // تجربة محلية فقط: على جهاز واحد لا يوجد طرف آخر حقيقي ليقبل.
                    MediaConsentStore.set("consented", for: conversation.id, data: &consentData)
                }
            )
        }
        .sheet(isPresented: $showMediaComposer) {
            MediaComposerSheet { symbol, caption in
                // لا رفع صور حقيقي: الوسائط تُمثَّل برمز + تعليق (انظر تعليق أعلى الملف).
                let text = caption.isEmpty ? "وسائط: \(symbol)" : caption
                store.sendMessage(to: liveConversation, text: text, isMedia: true)
            }
        }
    }

    /// ترويسة الفايب: إيموجي مزاج الطرف الآخر + زر تحرير فايب الخاص بي.
    private var vibeHeader: some View {
        HStack(spacing: 12) {
            Text(liveConversation.vibe.isEmpty ? "🙂" : liveConversation.vibe)
                .font(.largeTitle)
            VStack(alignment: .leading, spacing: 2) {
                Text(liveConversation.otherTag)
                    .font(.headline)
                Text("فايبه اليوم \(liveConversation.vibe.isEmpty ? "🙂" : liveConversation.vibe)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Button {
                showVibeEditor = true
            } label: {
                VStack(spacing: 2) {
                    Text(myVibe)
                        .font(.title2)
                    Text("وش جوّك؟")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
            .buttonStyle(.plain)
            .accessibilityLabel("وش جوّك؟ غيّر فايبك الحالي \(myVibe)")
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(Color(.secondarySystemBackground))
    }

    /// شريط الإدخال: زر وسائط (موافقة أولاً)، زر ملصقات، حقل نص، زر إرسال.
    private var inputBar: some View {
        HStack(spacing: 8) {
            Button {
                if mediaConsented {
                    showMediaComposer = true
                } else {
                    showConsentSheet = true
                }
            } label: {
                Image(systemName: mediaConsented ? "photo.on.rectangle" : "photo.badge.plus")
                    .font(.title3)
                    .frame(minWidth: 44, minHeight: 44)
                    .foregroundStyle(mediaConsented ? .green : .secondary)
            }
            .accessibilityLabel(mediaConsented ? "إرسال وسائط" : "مشاركة وسائط — تتطلب موافقة متبادلة أولاً")
            .accessibilityHint(mediaRequested ? "طلب الموافقة أُرسل، بانتظار موافقة الطرف الآخر" : "")

            Button {
                withAnimation { showStickerPicker.toggle() }
            } label: {
                Image(systemName: "face.smiling")
                    .font(.title3)
                    .frame(minWidth: 44, minHeight: 44)
            }
            .accessibilityLabel("الملصقات")

            TextField("اكتب رسالة…", text: $draft, axis: .vertical)
                .lineLimit(1...4)
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
                .background(Color(.tertiarySystemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 18))

            Button {
                sendDraft()
            } label: {
                Image(systemName: "arrow.up.circle.fill")
                    .font(.title2)
                    .frame(minWidth: 44, minHeight: 44)
            }
            .disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            .accessibilityLabel("إرسال")
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 6)
        .background(Color(.systemBackground))
    }

    /// منتقي الملصقات: تمرير أفقي لحزم الملصقات المنسوخة إلى `Resources/Stickers/`
    /// (تُحفظ بنفس مجلدات الحزم: emojis / typos / Molang / oldschool / doodle).
    /// تُعرض فقط الملصقات الموجودة فعلاً في الحزمة (فحص `UIImage(named:)`).
    private var stickerPicker: some View {
        VStack(alignment: .leading, spacing: 8) {
            Picker("حزمة الملصقات", selection: $selectedStickerPack) {
                ForEach(StickerCatalog.packs, id: \.self) { pack in
                    Text(StickerCatalog.displayName(for: pack)).tag(pack)
                }
            }
            .pickerStyle(.segmented)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(StickerCatalog.names(for: selectedStickerPack), id: \.self) { name in
                        Button {
                            store.sendMessage(to: liveConversation, text: name, isMedia: true)
                            showStickerPicker = false
                        } label: {
                            Image(name)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 56, height: 56)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("ملصق \(name)")
                    }
                }
                .padding(.horizontal)
            }
            .frame(height: 72)
        }
        .padding(.vertical, 8)
        .background(Color(.secondarySystemBackground))
    }

    private func sendDraft() {
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        store.sendMessage(to: liveConversation, text: text, isMedia: false)
        draft = ""
    }

    private func scrollToLast(proxy: ScrollViewProxy) {
        if let last = liveConversation.messages.last {
            proxy.scrollTo(last.id, anchor: .bottom)
        }
    }
}

/// فقاعة رسالة واحدة: رسائلي يميناً (خضراء)، رسائل الطرف الآخر يساراً (رمادية).
/// رسالة الوسائط تظهر برمز + تعليق (لا صورة مرفوعة)؛ رسالة الملصق تعرض صورة الملصق.
private struct MessageBubble: View {
    let message: ChatMessage

    private var isSticker: Bool { message.text.hasPrefix("Stickers/") }

    var body: some View {
        VStack(alignment: message.isMine ? .trailing : .leading, spacing: 2) {
            if isSticker {
                Image(message.text)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 120, height: 120)
            } else {
                VStack(alignment: .leading, spacing: 6) {
                    if message.isMedia {
                        // تمثيل الوسائط برمز + تعليق — لا رفع صور حقيقي في الوضع المحلي.
                        HStack(spacing: 6) {
                            Image(systemName: "photo")
                            Text(message.mediaConsented ? "وسائط بموافقة متبادلة" : "وسائط")
                                .font(.caption.weight(.semibold))
                        }
                        .foregroundStyle(message.isMine ? .white.opacity(0.9) : .secondary)
                    }
                    Text(message.text)
                        .font(.body)
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .background(message.isMine ? Color.green : Color(.tertiarySystemBackground))
                .foregroundStyle(message.isMine ? .white : .primary)
                .clipShape(RoundedRectangle(cornerRadius: 18))
            }
            Text(message.createdAt, style: .time)
                .font(.caption2)
                .foregroundStyle(.secondary)
                .padding(.horizontal, 6)
        }
    }
}

/// محرر الفايب الخاص بي: «وش جوّك؟» — اختيار إيموجي المزاج.
/// عند تطابق فايبي مع فايب الطرف الآخر تظهر «يا سلام، توافق سلس 💫».
private struct VibeEditorSheet: View {
    @Binding var myVibe: String
    let otherVibe: String

    @Environment(\.dismiss) private var dismiss

    private let vibes = ["😀", "😂", "😎", "🥳", "😍", "🤔", "😴", "😢", "😡", "🤯", "🥶", "😇", "🤠", "😜", "🥺", "😤"]

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                Text("وش جوّك؟")
                    .font(.custom("Gotham-Bold", size: 22, relativeTo: .title2))
                HStack(spacing: 20) {
                    VStack {
                        Text(myVibe).font(.system(size: 48))
                        Text("أنا").font(.caption).foregroundStyle(.secondary)
                    }
                    Text("+")
                        .font(.title)
                        .foregroundStyle(.secondary)
                    VStack {
                        Text(otherVibe.isEmpty ? "🙂" : otherVibe).font(.system(size: 48))
                        Text("الطرف الآخر").font(.caption).foregroundStyle(.secondary)
                    }
                }
                if myVibe == otherVibe && !otherVibe.isEmpty {
                    Text("يا سلام، توافق سلس 💫")
                        .font(.headline)
                        .foregroundStyle(.green)
                }
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 44))], spacing: 12) {
                    ForEach(vibes, id: \.self) { emoji in
                        Button {
                            myVibe = emoji
                        } label: {
                            Text(emoji)
                                .font(.largeTitle)
                                .frame(minWidth: 44, minHeight: 44)
                                .background(myVibe == emoji ? Color.green.opacity(0.15) : Color.clear)
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("فايب \(emoji)")
                    }
                }
                Spacer()
            }
            .padding()
            .navigationTitle("وش جوّك؟")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("تم") { dismiss() }
                }
            }
        }
    }
}

/// ورقة طلب الموافقة المتبادلة على مشاركة الوسائط.
/// النص حرفي من `newstack_chat_push_notification_activation`:
/// «يريد %@ البدء في مشاركة محتوى مرئي ومسموع في محادثتكما الخاصّة».
private struct MediaConsentSheet: View {
    let otherTag: String
    let requested: Bool
    var onRequest: () -> Void
    var onLocalAccept: () -> Void

    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                Image(systemName: "photo.badge.plus")
                    .font(.largeTitle)
                    .foregroundStyle(.green)
                Text("يريد البدء في مشاركة محتوى مرئي ومسموع")
                    .font(.headline)
                    .multilineTextAlignment(.center)
                Text("مشاركة الصور والمقاطع الصوتية في محادثتكما الخاصّة تتطلب موافقة الطرفين. لن تُرسل أي وسائط قبل أن يوافق \(otherTag) أيضاً.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                if requested {
                    Label("طلب الموافقة أُرسل — بانتظار موافقة الطرف الآخر", systemImage: "clock")
                        .font(.caption)
                        .foregroundStyle(.orange)
                        .multilineTextAlignment(.center)
                }
                Button("إرسال طلب الموافقة") {
                    onRequest()
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
                .tint(.green)
                .disabled(requested)
                Button("قبول الطرف الآخر (تجربة محلية فقط)") {
                    onLocalAccept()
                    dismiss()
                }
                .buttonStyle(.bordered)
                .font(.caption)
                Text("زر القبول أعلاه محاكاة محلية لاختبار التدفق على جهاز واحد فقط؛ في الاستخدام الحقيقي يقبل الطرف الآخر من جهازه.")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                Spacer()
            }
            .padding()
            .navigationTitle("مشاركة وسائط")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("إلغاء") { dismiss() }
                }
            }
        }
    }
}

/// مؤلف رسالة وسائط: اختيار رمز توضيحي + تعليق.
/// لا رفع صور حقيقي — الرمز والتعليق هما كل ما يُرسل (وضع محلي أولاً).
private struct MediaComposerSheet: View {
    var onSend: (_ symbol: String, _ caption: String) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var symbol = "photo"
    @State private var caption = ""

    private let symbols = ["photo", "camera", "video", "music.note", "mic", "waveform"]

    var body: some View {
        NavigationStack {
            Form {
                Section("الرمز التوضيحي") {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 44))], spacing: 12) {
                        ForEach(symbols, id: \.self) { item in
                            Button {
                                symbol = item
                            } label: {
                                Image(systemName: item)
                                    .font(.title2)
                                    .frame(minWidth: 44, minHeight: 44)
                                    .background(symbol == item ? Color.green.opacity(0.15) : Color.clear)
                                    .foregroundStyle(symbol == item ? .green : .primary)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                Section("التعليق") {
                    TextField("اكتب تعليقاً على الوسائط…", text: $caption, axis: .vertical)
                        .lineLimit(3...)
                }
                Section {
                    Text("التطبيق محلي أولاً: لا يُرفع أي ملف حقيقي. تُرسل الوسائط كرمز توضيحي مع تعليق نصي فقط.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("إرسال وسائط")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("إلغاء") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("إرسال") {
                        onSend(symbol, caption.trimmingCharacters(in: .whitespacesAndNewlines))
                        dismiss()
                    }
                }
            }
        }
    }
}

/// حالة الموافقة على الوسائط لكل محادثة، محفوظة محلياً كـ JSON.
/// لا فك قسري: بيانات تالفة تعني «لا حالة».
private enum MediaConsentStore {
    static func state(for id: UUID, in data: String) -> String {
        guard let raw = data.data(using: .utf8),
              let dict = try? JSONDecoder().decode([String: String].self, from: raw) else {
            return ""
        }
        return dict[id.uuidString] ?? ""
    }

    static func set(_ state: String, for id: UUID, data: inout String) {
        var dict: [String: String] = [:]
        if let raw = data.data(using: .utf8),
           let decoded = try? JSONDecoder().decode([String: String].self, from: raw) {
            dict = decoded
        }
        dict[id.uuidString] = state
        if let raw = try? JSONEncoder().encode(dict),
           let text = String(data: raw, encoding: .utf8) {
            data = text
        }
    }
}

/// فهرس الملصقات من حزمة الملصقات في أصول إعادة البناء (`ImgLY.bundle/sticker/`)
/// (تُنسخ إلى `Resources/Stickers/` مع الحفاظ على مجلدات الحزم).
/// الأسماء حرفية من الملفات؛ تُفحص وجودها في الحزمة وقت العرض فلا تظهر روابط مكسورة.
private enum StickerCatalog {
    static let packs = ["emojis", "typos", "Molang", "oldschool", "doodle", "extraEmojis", "hands"]

    static func displayName(for pack: String) -> String {
        switch pack {
        case "emojis": return "إيموجي"
        case "typos": return "كلمات"
        case "Molang": return "مولانغ"
        case "oldschool": return "كلاسيك"
        case "doodle": return "رسم"
        case "extraEmojis": return "إيموجي +"
        case "hands": return "أيدي"
        default: return pack
        }
    }

    /// أسماء الملصقات الموجودة فعلاً في الحزمة (بدون لاحقة، بصيغة مسار الحزمة).
    static func names(for pack: String) -> [String] {
        allNames(for: pack).filter { UIImage(named: $0) != nil }
    }

    private static func allNames(for pack: String) -> [String] {
        switch pack {
        case "emojis":
            return [
                "imgly_sticker_emoji_anguished", "imgly_sticker_emoji_ape", "imgly_sticker_emoji_beer",
                "imgly_sticker_emoji_crying", "imgly_sticker_emoji_devil", "imgly_sticker_emoji_doubtful",
                "imgly_sticker_emoji_drooling", "imgly_sticker_emoji_flushed", "imgly_sticker_emoji_grim",
                "imgly_sticker_emoji_grimacing", "imgly_sticker_emoji_halo", "imgly_sticker_emoji_hand_pointing_left",
                "imgly_sticker_emoji_hand_pointing_right", "imgly_sticker_emoji_hanky", "imgly_sticker_emoji_happyface",
                "imgly_sticker_emoji_hearteyes", "imgly_sticker_emoji_lips", "imgly_sticker_emoji_melon",
                "imgly_sticker_emoji_nauseated", "imgly_sticker_emoji_pacman", "imgly_sticker_emoji_persevering",
                "imgly_sticker_emoji_pizza", "imgly_sticker_emoji_rollingeyes", "imgly_sticker_emoji_sad",
                "imgly_sticker_emoji_skull", "imgly_sticker_emoji_smile", "imgly_sticker_emoji_sunglasses",
                "imgly_sticker_emoji_tearsofjoy", "imgly_sticker_emoji_thumbsup", "imgly_sticker_emoji_tongueout",
                "imgly_sticker_emoji_unamused", "imgly_sticker_emoji_unicorn", "imgly_sticker_emoji_vomiting",
                "imgly_sticker_emoji_winking", "imgly_sticker_emoji_zany"
            ].map { "Stickers/emojis/\($0)" }
        case "doodle":
            return [
                "imgly_sticker_doodle_camera", "imgly_sticker_doodle_divingmask", "imgly_sticker_doodle_fish",
                "imgly_sticker_doodle_hat", "imgly_sticker_doodle_hula", "imgly_sticker_doodle_jetpack",
                "imgly_sticker_doodle_pipe", "imgly_sticker_doodle_rocket", "imgly_sticker_doodle_saturn",
                "imgly_sticker_doodle_skateboard", "imgly_sticker_doodle_spaceman", "imgly_sticker_doodle_star",
                "imgly_sticker_doodle_starfish", "imgly_sticker_doodle_sun", "imgly_sticker_doodle_surfing",
                "imgly_sticker_doodle_wing_01", "imgly_sticker_doodle_wing_02"
            ].map { "Stickers/doodle/\($0)" }
        case "typos":
            return [
                "imgly_sticker_typo_bffs1", "imgly_sticker_typo_bffs1_white", "imgly_sticker_typo_bffs2_black",
                "imgly_sticker_typo_bffs2_white", "imgly_sticker_typo_forever", "imgly_sticker_typo_forever2",
                "imgly_sticker_typo_forever2_white", "imgly_sticker_typo_forever_white",
                "imgly_sticker_typo_goodluck01_green", "imgly_sticker_typo_goodluck01_white",
                "imgly_sticker_typo_goodluck02_green", "imgly_sticker_typo_goodluck02_white",
                "imgly_sticker_typo_goodluck03_green", "imgly_sticker_typo_goodluck03_white",
                "imgly_sticker_typo_happybirthday", "imgly_sticker_typo_happybirthday2",
                "imgly_sticker_typo_happybirthday_3d_block_blue", "imgly_sticker_typo_happybirthday_3d_block_candy",
                "imgly_sticker_typo_happybirthday_3d_block_disco", "imgly_sticker_typo_happybirthday_3d_block_red",
                "imgly_sticker_typo_happybirthday_3d_red", "imgly_sticker_typo_happybirthday_3d_turquoise",
                "imgly_sticker_typo_happybirthday_circus", "imgly_sticker_typo_happybirthday_overlaid",
                "imgly_sticker_typo_justlove_pink", "imgly_sticker_typo_justlove_white",
                "imgly_sticker_typo_mademayday_black", "imgly_sticker_typo_mademayday_weiss",
                "imgly_sticker_typo_takeiteasy", "imgly_sticker_typo_youandme02_black",
                "imgly_sticker_typo_youandme02_blackwhite", "imgly_sticker_typo_youandme02_white",
                "imgly_sticker_typo_youandme_bang_pink", "imgly_sticker_typo_youandme_bang_white"
            ].map { "Stickers/typos/\($0)" }
        case "oldschool":
            return [
                "glasses_nerd", "glasses_normal", "glasses_shutter_green", "glasses_shutter_yellow",
                "glasses_sun", "hat_cap", "hat_party", "hat_sherrif", "heart", "mustache1",
                "mustache2", "mustache3", "mustache_long", "pipe", "smile", "snowflake",
                "star", "teardrop"
            ].map { "Stickers/oldschool/\($0)" }
        case "hands":
            return [
                "imgly_sticker_hand_alive", "imgly_sticker_hand_five", "imgly_sticker_hand_friends",
                "imgly_sticker_hand_fuck", "imgly_sticker_hand_heart", "imgly_sticker_hand_luck",
                "imgly_sticker_hand_ok", "imgly_sticker_hand_vibes"
            ].map { "Stickers/hands/\($0)" }
        case "Molang", "extraEmojis":
            return (1...30).map { "Stickers/\(pack)/sticker_\($0)" }
        default:
            return []
        }
    }
}
