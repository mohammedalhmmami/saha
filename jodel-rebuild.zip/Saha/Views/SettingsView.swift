import AVFoundation
import SwiftUI

// MARK: - SettingsView
// الإعدادات: اللغة، الإشعارات، الوضع الداكن، السمة، أيقونة التطبيق،
// طلبات المراسلة، المحظورون، الخصوصية، الحساب (حذف)، الدعم/الأسئلة الشائعة، عن التطبيق.

struct SettingsView: View {
    @EnvironmentObject var store: AppStore

    @State private var showingDeleteConfirmation = false
    @State private var showingEraseConfirmation = false
    @State private var showingServerUnavailable = false
    @State private var showingBanAlert = false
    @State private var showingUnblockConfirmation: String?
    // لا تكشف واجهة AppStore حالة طلبات المراسلة؛ تُحفظ الحالة محلياً هنا
    // وتُمرَّر كل تغييراتها إلى store.toggleMessageRequests.
    @State private var messageRequestsEnabled = true

    private var jodelGreen: Color { Color(red: 30 / 255, green: 122 / 255, blue: 76 / 255) }

    /// أسماء السمات الثماني — نفس القائمة في PlusView.
    private var themes: [String] {
        ["افتراضي", "غابة", "محيط", "غروب", "ليلكي", "ذهبي", "وردي", "فحمي"]
    }

    /// أيقونات التطبيق الخمس (premiumLogo1–5 من الأصول المستخرجة).
    private var appIcons: [String] {
        ["premiumLogo1", "premiumLogo2", "premiumLogo3", "premiumLogo4", "premiumLogo5"]
    }

    /// إصدار التطبيق من الحزمة — قراءة آمنة بلا force unwrap.
    private var appVersionText: String {
        guard let info = Bundle.main.infoDictionary,
              let version = info["CFBundleShortVersionString"] as? String,
              let build = info["CFBundleVersion"] as? String
        else { return "1.0 (1)" }
        return "\(version) (\(build))"
    }

    var body: some View {
        List {
            // اللغة
            Section("اللغة") {
                Picker("اللغة", selection: languageBinding) {
                    Text("العربية").tag(AppLanguage.arabic)
                    Text("English").tag(AppLanguage.english)
                }
                .pickerStyle(.segmented)
            }

            // المظهر: الوضع الداكن + السمة + أيقونة التطبيق
            Section("المظهر") {
                Toggle("وضع داكن", isOn: darkModeBinding) // dark_feed_toggle
                themePickerRow
                appIconPickerRow
            }

            // الإشعارات وطلبات المراسلة
            Section("الإشعارات والمراسلة") {
                Toggle("الإشعارات", isOn: notificationsBinding)
                Toggle("طلبات المراسلة", isOn: messageRequestsBinding)
            }

            // إعدادات Zero (#3–#41 من FEATURES.md) — كلها مجانية ومفتوحة
            Section("Zero") {
                Toggle("حفظ الصور", isOn: zeroBinding(\.saveImages)) // #3
                Toggle("نسخ النص", isOn: zeroBinding(\.copyText)) // #4
                Toggle("تأكيد الرد", isOn: zeroBinding(\.confirmReply)) // #5
                Toggle("تأكيد النشر", isOn: zeroBinding(\.confirmPost)) // #6
                Toggle("الرفع من المعرض", isOn: zeroBinding(\.uploadFromGallery)) // #7
                Toggle("تعطيل تنبيه لقطة الشاشة", isOn: zeroBinding(\.disableScreenshotAlert)) // #8
                Toggle("إيقاف التتبع", isOn: zeroBinding(\.stopTracking)) // #23
                Toggle("حماية التطبيق (Face ID)", isOn: zeroBinding(\.protectApp)) // #9
                if store.zero.protectApp {
                    Toggle("القفل عند كل فتح", isOn: zeroBinding(\.askEachTime))
                }
                Toggle("مغير الصوت", isOn: zeroBinding(\.voiceChanger)) // #10
                Toggle("لوحة الإيموجي السريعة", isOn: zeroBinding(\.quickEmoji)) // #11
                Toggle("سجل النسخ", isOn: zeroBinding(\.copyHistoryEnabled)) // #12
                Toggle("الاحتفاظ بالرسائل المحذوفة", isOn: zeroBinding(\.keepDeletedMessages)) // #21
                Toggle("تزييف الموقع", isOn: zeroBinding(\.locationSpoof)) // #15
                Text("تزييف الموقع هنا يعني تصفح مدن أخرى بشفافية من وضع المستكشف — لا يُرسل موقع مزيف إلى أي خادم.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Toggle("خطوط مخصصة", isOn: zeroBinding(\.customFonts)) // #14
                if store.zero.customFonts {
                    Picker("الخط", selection: fontBinding) {
                        ForEach(AppFontChoice.allCases, id: \.self) { choice in
                            Text(choice.displayName).tag(choice)
                        }
                    }
                }
                NavigationLink("مدير الحسابات") { AccountManagerView() } // #19
                NavigationLink("سجل النسخ") { CopyHistoryView() } // #12
                NavigationLink("المؤثرات الصوتية") { VoiceEffectsView() } // #10
                NavigationLink("الموقع") { LocationView() } // #15
                NavigationLink("تطبيقاتنا") { OurAppsView() } // #41
                NavigationLink("الاعتمادات") { CreditsView() } // #40
            }

            // المحظورون
            Section("المستخدمون المحظورون") {
                if store.profile.blockedTags.isEmpty {
                    Text("لا يوجد مستخدمون محظورون")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(store.profile.blockedTags, id: \.self) { tag in
                        HStack {
                            Image(systemName: "person.slash.fill")
                                .foregroundStyle(.secondary)
                            Text(tag)
                            Spacer()
                            Button("إلغاء الحظر") {
                                showingUnblockConfirmation = tag
                            }
                            .buttonStyle(.bordered)
                            .tint(jodelGreen)
                        }
                    }
                }
            }

            // الخصوصية — صادقة: بيانات محلية فقط، بلا تتبع
            Section("الخصوصية") {
                VStack(alignment: .leading, spacing: 8) {
                    Text("ما الذي يجمعه التطبيق؟")
                        .font(.headline)
                    Text("بياناتك محلية فقط على جهازك: منشوراتك وتصويتك وإعداداتك تُحفظ في ذاكرة الجهاز، ولا تُرسل إلى أي خادم في الوضع المحلي. لا تتبع، لا إعلانات، لا حسابات طرف ثالث، ولا مشاركة لموقعك الدقيق مع أي جهة.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Label("لا تتبع", systemImage: "eye.slash.fill")
                        .font(.subheadline)
                        .foregroundStyle(jodelGreen)
                    Label("لا إعلانات", systemImage: "nosign")
                        .font(.subheadline)
                        .foregroundStyle(jodelGreen)
                    Label("بياناتك على جهازك فقط", systemImage: "internaldrive.fill")
                        .font(.subheadline)
                        .foregroundStyle(jodelGreen)
                }
                .padding(.vertical, 4)
            }

            // الدعم والأسئلة الشائعة
            Section("الدعم") { // faq_settings_title = مركز الدعم
                NavigationLink("مركز الدعم") {
                    SupportView()
                }
                DisclosureGroup("كيف أكسب الكارما؟") {
                    Text("النشر +5، الرد +2، التصويت +1، وتلقي تصويت إيجابي +3. المكافأة اليومية +10.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                DisclosureGroup("هل اسمي ظاهر لأحد؟") {
                    Text("لا. تظهر فقط بوسم مجهول مثل «جار #1234»، ولا يرى أحد أي بيانات شخصية عنك.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                DisclosureGroup("كيف أغيّر مدينتي؟") {
                    Text("من وضع المستكشف في مزايا بلس يمكنك تصفح مدن أخرى بشفافية، دون تزييف موقعك.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }

            // الحساب
            Section("الحساب") {
                Button("إعادة تعيين إعدادات Zero") { // #34
                    store.resetZeroSettings()
                }
                Button(role: .destructive) {
                    showingEraseConfirmation = true
                } label: {
                    Text("مسح كل بيانات التطبيق") // #35
                }
                Button(role: .destructive) {
                    showingDeleteConfirmation = true
                } label: {
                    Text("حذف الحساب") // delete_acc_settings_title
                }
            }

            // الخادم — وضع الخادم افتراضياً؛ المحلي رجوع تلقائي عند سقوط الخادم
            Section("الخادم") {
                Button {
                    Task { @MainActor in
                        if store.backendMode == .server {
                            store.disableServerMode()
                        } else {
                            let ok = await store.enableServerMode()
                            if !ok { showingServerUnavailable = true }
                        }
                    }
                } label: {
                    HStack {
                        Text("وضع الخادم")
                        Spacer()
                        if store.backendMode == .server {
                            Image(systemName: "checkmark")
                        }
                    }
                }
                HStack {
                    Text("الحالة")
                    Spacer()
                    Text(serverStatusText)
                        .foregroundStyle(.secondary)
                }
                if store.serverBanned {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("رُفض الاتصال بالخادم (403) — قد يكون الحساب محظوراً.", systemImage: "exclamationmark.triangle.fill")
                            .foregroundStyle(.red)
                            .font(.subheadline)
                        Button("إنشاء حساب جديد") {
                            store.createFreshAccountAfterBan()
                        }
                        .buttonStyle(.bordered)
                    }
                }
                Text("وضع الخادم يزامن الخلاصة والقنوات والمحادثات مع خادمك الخاص. عند تعذر الاتصال يعود التطبيق تلقائياً للوضع المحلي.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            // عن التطبيق
            Section("عن التطبيق") {
                HStack {
                    Image(systemName: "square.grid.2x2.fill")
                        .foregroundStyle(jodelGreen)
                    Text("JodelZero")
                        .font(.custom("Gotham-Bold", size: 18, relativeTo: .headline))
                    Spacer()
                    Text("الإصدار \(appVersionText)")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                Text("شبكة اجتماعية محلية مجهولة — شارك ما يدور حولك مع جيرانك.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                HStack {
                    Text("Tweak Version") // #37
                    Spacer()
                    Text("Zero 1.0")
                        .foregroundStyle(.secondary)
                }
                HStack {
                    Text("App Version") // #37
                    Spacer()
                    Text(appVersionText)
                        .foregroundStyle(.secondary)
                }
                HStack {
                    Text("Bundle ID") // #37
                    Spacer()
                    Text(bundleIdText)
                        .foregroundStyle(.secondary)
                }
                HStack {
                    Text("الاشتراك") // #36
                    Spacer()
                    Text("مجاني — كل شيء مفتوح")
                        .foregroundStyle(.secondary)
                }
            }
        }
        .navigationTitle("الإعدادات") // general_settings
        .preferredColorScheme(store.profile.darkMode ? .dark : .light)
        .confirmationDialog(
            "تأكيد الحذف", // delete_acc_confirm_title
            isPresented: $showingDeleteConfirmation,
            titleVisibility: .visible
        ) {
            Button("حذف الحساب نهائياً", role: .destructive) {
                store.deleteAccount()
            }
            Button("إلغاء", role: .cancel) {}
        } message: {
            Text("سيتم مسح كل بياناتك المحلية (منشوراتك وتصويتك وإعداداتك) وإعادة التطبيق إلى حالته الأولى. لا يمكن التراجع عن هذا الإجراء.")
        }
        .confirmationDialog(
            "مسح كل البيانات", // #35
            isPresented: $showingEraseConfirmation,
            titleVisibility: .visible
        ) {
            Button("مسح كل شيء", role: .destructive) {
                store.eraseAllData()
            }
            Button("إلغاء", role: .cancel) {}
        } message: {
            Text("سيتم مسح كل الحسابات والمنشورات والمحادثات وإعدادات Zero نهائياً وإعادة التطبيق إلى حالته الأولى. لا يمكن التراجع عن هذا الإجراء.")
        }
        .alert("الخادم غير متاح", isPresented: $showingServerUnavailable) {
            Button("حسناً", role: .cancel) {}
        } message: {
            Text("تعذّر الاتصال بالخادم. بقي التطبيق في الوضع المحلي — تأكد أن خادمك يعمل ثم حاول مجدداً.")
        }
        // تنبيه الحظر (#20): يظهر فور اكتشاف الحظر (403) مع زر إنشاء حساب
        // جديد موصول بتدفق المسح + الإنشاء، لا زر ميت.
        .alert("تم حظر حسابك", isPresented: $showingBanAlert) {
            Button("إنشاء حساب جديد") {
                store.createFreshAccountAfterBan()
            }
            Button("لاحقاً", role: .cancel) {}
        } message: {
            Text("تم حظر حسابك. هل تريد إنشاء حساب جديد؟ سيتم مسح بيانات التطبيق الحالية.")
        }
        .onChange(of: store.serverBanned) { banned in
            if banned { showingBanAlert = true }
        }
        .confirmationDialog(
            "إلغاء الحظر",
            isPresented: Binding(
                get: { showingUnblockConfirmation != nil },
                set: { if !$0 { showingUnblockConfirmation = nil } }
            ),
            titleVisibility: .visible
        ) {
            Button("إلغاء الحظر", role: .destructive) {
                if let tag = showingUnblockConfirmation {
                    store.unblockUser(tag: tag)
                }
                showingUnblockConfirmation = nil
            }
            Button("إلغاء", role: .cancel) {
                showingUnblockConfirmation = nil
            }
        } message: {
            if let tag = showingUnblockConfirmation {
                Text("هل تريد إلغاء حظر \(tag)؟ سيتمكن من مراسلتك مجدداً.")
            }
        }
    }

    // MARK: - Bindings (عبر واجهة AppStore فقط)

    private var languageBinding: Binding<AppLanguage> {
        Binding(
            get: { store.profile.language },
            set: { store.setLanguage($0) }
        )
    }

    private var darkModeBinding: Binding<Bool> {
        Binding(
            get: { store.profile.darkMode },
            set: { store.setDarkMode($0) }
        )
    }

    private var notificationsBinding: Binding<Bool> {
        Binding(
            get: { store.profile.notificationsEnabled },
            set: { newValue in
                store.profile.notificationsEnabled = newValue
                store.save()
            }
        )
    }

    private var messageRequestsBinding: Binding<Bool> {
        Binding(
            get: { messageRequestsEnabled },
            set: { newValue in
                messageRequestsEnabled = newValue
                store.toggleMessageRequests(newValue)
            }
        )
    }

    /// ربط تبديل Zero — يقرأ من store.zero ويحفظ فوراً عند التغيير.
    private func zeroBinding(_ keyPath: WritableKeyPath<ZeroSettings, Bool>) -> Binding<Bool> {
        Binding(
            get: { store.zero[keyPath: keyPath] },
            set: { store.zero[keyPath: keyPath] = $0; store.saveZero() }
        )
    }

    /// ربط اختيار الخط المخصص (#14).
    private var fontBinding: Binding<AppFontChoice> {
        Binding(
            get: { store.zero.fontChoice },
            set: { store.setFontChoice($0) }
        )
    }

    /// حالة الخادم المعروضة (صادقة: «مفعّل» لا تعني «متصل الآن»).
    private var serverStatusText: String {
        if store.serverBanned { return "محظور (403)" }
        if store.serverOffline { return "غير متصل" }
        switch store.backendMode {
        case .server: return "وضع الخادم مفعّل"
        case .local: return "وضع محلي"
        }
    }

    /// معرّف الحزمة من الحزمة — قراءة آمنة بلا force unwrap.
    private var bundleIdText: String {
        Bundle.main.bundleIdentifier ?? "com.nebra.jodelzero"
    }

    // MARK: - منتقي السمة
    private var themePickerRow: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("السمة")
                .font(.headline)
            LazyVGrid(
                columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())],
                spacing: 8
            ) {
                ForEach(themes, id: \.self) { theme in
                    Button {
                        store.setTheme(theme)
                    } label: {
                        Text(theme)
                            .font(.subheadline.weight(.semibold))
                            .frame(maxWidth: .infinity, minHeight: 44)
                            .background(store.profile.selectedTheme == theme ? jodelGreen : Color(.secondarySystemBackground))
                            .foregroundStyle(store.profile.selectedTheme == theme ? .white : .primary)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .padding(.vertical, 4)
    }

    // MARK: - منتقي أيقونة التطبيق
    private var appIconPickerRow: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("أيقونة التطبيق") // iap_paywall_intro_more_icons
                .font(.headline)
            LazyVGrid(
                columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())],
                spacing: 8
            ) {
                ForEach(appIcons, id: \.self) { iconName in
                    Button {
                        store.setAppIcon(iconName)
                    } label: {
                        Image(iconName)
                            .resizable()
                            .scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(store.profile.selectedIcon == iconName ? jodelGreen : Color.clear, lineWidth: 2)
                            )
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("أيقونة \(iconName)")
                }
            }
            Text("الأيقونات مفتوحة مجاناً للجميع.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 4)
    }
}

// MARK: - SupportView (مركز الدعم — محلي، بلا روابط خارجية)

private struct SupportView: View {
    var body: some View {
        List {
            Section("الأسئلة الشائعة") {
                DisclosureGroup("كيف أبلّغ عن منشور مسيء؟") {
                    Text("افتح المنشور واختر «إبلاغ». تُراجع البلاغات وتُخفى المنشورات التي تصل نتيجتها إلى −5 بالتصويت.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                DisclosureGroup("نسيت أنني حظرت أحداً — أين أجده؟") {
                    Text("من الإعدادات ثم «المستخدمون المحظورون»، ويمكنك إلغاء الحظر من هناك.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                DisclosureGroup("هل يعمل التطبيق دون إنترنت؟") {
                    Text("نعم، الوضع المحلي يعمل بالكامل دون اتصال، وتُحفظ بياناتك على جهازك.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
            Section("تواصل معنا") {
                Text("الدعم داخل التطبيق فقط في هذا الإصدار — لا تُرسل أي بيانات شخصية.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("مركز الدعم") // faq_settings_title
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - AccountManagerView (مدير الحسابات #19 — حتى 3 حسابات محلية)

private struct AccountManagerView: View {
    @EnvironmentObject var store: AppStore
    @State private var newName = ""
    @State private var showingDelete: AccountSlot?

    var body: some View {
        List {
            Section("حساباتك") {
                ForEach(store.slots) { slot in
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(slot.name)
                            Text(slot.tag)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        if slot.id == store.activeSlotId {
                            Text("نشط")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        } else {
                            Button("تبديل") { store.switchAccount(to: slot) }
                                .buttonStyle(.bordered)
                        }
                    }
                    .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                        Button(role: .destructive) { showingDelete = slot } label: {
                            Label("حذف", systemImage: "trash")
                        }
                    }
                }
            }
            if store.slots.count < 3 {
                Section("حساب جديد") {
                    HStack {
                        TextField("اسم الحساب", text: $newName)
                        Button("إنشاء") {
                            _ = store.createAccount(name: newName)
                            newName = ""
                        }
                        .buttonStyle(.bordered)
                    }
                    Text("يُنشأ الحساب الجديد بوسم مجهول عشوائي، وبياناته مستقلة تماماً.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            } else {
                Section {
                    Text("بلغت الحد الأقصى: 3 حسابات.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .navigationTitle("مدير الحسابات")
        .navigationBarTitleDisplayMode(.inline)
        .confirmationDialog(
            "حذف الحساب",
            isPresented: Binding(
                get: { showingDelete != nil },
                set: { if !$0 { showingDelete = nil } }
            ),
            titleVisibility: .visible
        ) {
            Button("حذف نهائياً", role: .destructive) {
                if let slot = showingDelete { _ = store.deleteAccountSlot(slot) }
                showingDelete = nil
            }
            Button("إلغاء", role: .cancel) { showingDelete = nil }
        } message: {
            Text("سيتم مسح بيانات هذا الحساب نهائياً.")
        }
    }
}

// MARK: - CopyHistoryView (سجل النسخ #12 — آخر 50 نصاً)

private struct CopyHistoryView: View {
    @EnvironmentObject var store: AppStore

    var body: some View {
        List {
            if store.zero.copyHistory.isEmpty {
                Text("لا توجد نصوص منسوخة بعد. انسخ نصاً من أي منشور (بالضغطة المطوّلة) وسيظهر هنا.")
                    .foregroundStyle(.secondary)
            } else {
                ForEach(store.zero.copyHistory) { item in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(item.text)
                        Text(item.createdAt, style: .relative)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                        Button(role: .destructive) { store.deleteCopiedText(item) } label: {
                            Label("حذف", systemImage: "trash")
                        }
                    }
                }
            }
        }
        .navigationTitle("سجل النسخ")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if store.zero.copyHistory.isEmpty == false {
                Button("مسح الكل") { store.clearCopyHistory() }
            }
        }
    }
}

// MARK: - VoiceEffectsView (مغير الصوت #10 — لوحة مؤثرات صوتية)

private struct VoiceEffectsView: View {
    @EnvironmentObject var store: AppStore
    @State private var player: AVAudioPlayer?
    @State private var playingName: String?

    private let sounds: [(name: String, file: String)] = [
        ("بوق", "airhorn"), ("نشيد", "anthem"), ("أجراس", "bells"),
        ("عيد ميلاد", "birthday"), ("كلب", "dog"), ("جرس", "gong"),
        ("مرحباً", "hello"), ("قبلة", "kiss"), ("ضحك", "laugh"),
        ("شرطة", "police"), ("صفارة", "siren"), ("صافرة", "whistle")
    ]

    var body: some View {
        List {
            Section("المؤثرات") {
                LazyVGrid(
                    columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())],
                    spacing: 12
                ) {
                    ForEach(sounds, id: \.file) { sound in
                        Button {
                            play(sound.file)
                        } label: {
                            VStack(spacing: 6) {
                                Image(systemName: playingName == sound.file ? "speaker.wave.3.fill" : "speaker.wave.2.fill")
                                    .font(.title2)
                                Text(sound.name)
                                    .font(.caption)
                            }
                            .frame(maxWidth: .infinity, minHeight: 64)
                            .background(Color(.secondarySystemBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.vertical, 4)
            }
            Section("سرعة التشغيل") {
                HStack {
                    Text("×\(String(format: "%.1f", store.zero.soundPitch))")
                    Slider(value: pitchBinding, in: 0.5...2.0, step: 0.1)
                }
                Text("تؤثر السرعة على المؤثرات الصوتية في هذه اللوحة.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("المؤثرات الصوتية")
        .navigationBarTitleDisplayMode(.inline)
    }

    private var pitchBinding: Binding<Double> {
        Binding(
            get: { store.zero.soundPitch },
            set: { store.zero.soundPitch = $0; store.saveZero() }
        )
    }

    private func play(_ file: String) {
        guard let url = Bundle.main.url(forResource: file, withExtension: "wav", subdirectory: "Sounds") else { return }
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.enableRate = true
            player?.rate = Float(store.zero.soundPitch)
            player?.play()
            playingName = file
        } catch {
            playingName = nil
        }
    }
}

// MARK: - CreditsView (صفحة الاعتمادات #40)

private struct CreditsView: View {
    var body: some View {
        List {
            Section("Jodel Zero") {
                Text("بُني من الملفات المستخرجة من نسختك — بلا كود تفعيل، بلا دخول، بلا دفع.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            Section("الخطوط") {
                Text("Gotham وMonoton وTitan One وTradeWinds — من الأصول المستخرجة.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            Section("الأصوات") {
                Text("12 مؤثراً صوتياً من الأصول المستخرجة (funsound).")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            Section("الأيقونات") {
                Text("أيقونات التطبيقات الشقيقة من حزمة Zero الأصلية.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("الاعتمادات")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - OurAppsView (تطبيقاتنا #41 — أيقونات من حزمة Zero الأصلية)

private struct OurAppsView: View {
    private let apps: [(name: String, image: String)] = [
        ("Jodel", "appJodel"),
        ("TikTok", "appTikTok"),
        ("Instagram", "appInstagram"),
        ("Facebook", "appFacebook"),
        ("WhatsApp", "appWhatsApp"),
        ("WhatsApp Business", "appWhatsAppBusiness"),
        ("Snapchat", "appSnapchat"),
        ("Threads", "appThreads"),
        ("Twitch", "appTwitch"),
        ("X", "appX"),
        ("YouTube", "appYouTube")
    ]

    var body: some View {
        List {
            Section {
                Text("تطبيقات شقيقة من فريق Zero — الأيقونات فقط للعرض، ولا تفتح أي تطبيق آخر.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Section {
                LazyVGrid(
                    columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())],
                    spacing: 16
                ) {
                    ForEach(apps, id: \.image) { app in
                        VStack(spacing: 6) {
                            Image(app.image)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 64, height: 64)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                            Text(app.name)
                                .font(.caption)
                        }
                    }
                }
                .padding(.vertical, 8)
            }
        }
        .navigationTitle("تطبيقاتنا")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - LocationView (الموقع #15 — تصفح شفاف للمدن)

private struct LocationView: View {
    @EnvironmentObject var store: AppStore

    var body: some View {
        List {
            Section {
                Toggle("تزييف الموقع", isOn: Binding(
                    get: { store.zero.locationSpoof },
                    set: { store.zero.locationSpoof = $0; store.saveZero() }
                ))
                Text("عند الإيقاف: الخلاصة تعرض مدينتك فقط. عند التفعيل: يمكنك تصفح أي مدينة من وضع المستكشف — بشفافية كاملة، دون إرسال موقع مزيف لأي خادم.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Section("مدينتي") {
                if let hometown = store.cities.first(where: { $0.isHometown }) {
                    HStack {
                        Text(hometown.name)
                        Spacer()
                        Text("مدينتي")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            Section("كل المدن") {
                ForEach(store.cities) { city in
                    Button {
                        store.currentCity = city
                    } label: {
                        HStack {
                            Text(city.name)
                            Spacer()
                            if store.currentCity.id == city.id {
                                Image(systemName: "checkmark")
                            }
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .navigationTitle("الموقع")
        .navigationBarTitleDisplayMode(.inline)
    }
}
