import SwiftUI

// MARK: - SettingsView
// الإعدادات: اللغة، الإشعارات، الوضع الداكن، السمة، أيقونة التطبيق،
// طلبات المراسلة، المحظورون، الخصوصية، الحساب (حذف)، الدعم/الأسئلة الشائعة، عن التطبيق.

struct SettingsView: View {
    @EnvironmentObject var store: AppStore

    @State private var showingDeleteConfirmation = false
    @State private var showingUnblockConfirmation: String?
    // لا تكشف واجهة AppStore حالة طلبات المراسلة؛ تُحفظ الحالة محلياً هنا
    // وتُمرَّر كل تغييراتها إلى store.toggleMessageRequests.
    @State private var messageRequestsEnabled = true

    private var sahaGreen: Color { Color(red: 30 / 255, green: 122 / 255, blue: 76 / 255) }

    /// أسماء السمات الثماني — نفس القائمة في PlusView.
    private var themes: [String] {
        ["افتراضي", "غابة", "محيط", "غروب", "ليلكي", "ذهبي", "وردي", "فحمي"]
    }

    /// أيقونات التطبيق الخمس (premiumLogo1–5 من الأصول المستخرجة).
    private var appIcons: [String] {
        ["premiumLogo1", "premiumLogo2", "premiumLogo3", "premiumLogo4", "premiumLogo5"]
    }

    /// إصدار التطبيق من الحزمة — قراءة آمنة بلا force unwrap.
    private var appVersionText: String {
        guard let info = Bundle.main.infoDictionary,
              let version = info["CFBundleShortVersionString"] as? String,
              let build = info["CFBundleVersion"] as? String
        else { return "1.0 (1)" }
        return "\(version) (\(build))"
    }

    var body: some View {
        List {
            // اللغة
            Section("اللغة") {
                Picker("اللغة", selection: languageBinding) {
                    Text("العربية").tag(AppLanguage.arabic)
                    Text("English").tag(AppLanguage.english)
                }
                .pickerStyle(.segmented)
            }

            // المظهر: الوضع الداكن + السمة + أيقونة التطبيق
            Section("المظهر") {
                Toggle("وضع داكن", isOn: darkModeBinding) // dark_feed_toggle
                themePickerRow
                appIconPickerRow
            }

            // الإشعارات وطلبات المراسلة
            Section("الإشعارات والمراسلة") {
                Toggle("الإشعارات", isOn: notificationsBinding)
                Toggle("طلبات المراسلة", isOn: messageRequestsBinding)
            }

            // المحظورون
            Section("المستخدمون المحظورون") {
                if store.profile.blockedTags.isEmpty {
                    Text("لا يوجد مستخدمون محظورون")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(store.profile.blockedTags, id: \.self) { tag in
                        HStack {
                            Image(systemName: "person.slash.fill")
                                .foregroundStyle(.secondary)
                            Text(tag)
                            Spacer()
                            Button("إلغاء الحظر") {
                                showingUnblockConfirmation = tag
                            }
                            .buttonStyle(.bordered)
                            .tint(sahaGreen)
                        }
                    }
                }
            }

            // الخصوصية — صادقة: بيانات محلية فقط، بلا تتبع
            Section("الخصوصية") {
                VStack(alignment: .leading, spacing: 8) {
                    Text("ما الذي يجمعه التطبيق؟")
                        .font(.headline)
                    Text("بياناتك محلية فقط على جهازك: منشوراتك وتصويتك وإعداداتك تُحفظ في ذاكرة الجهاز، ولا تُرسل إلى أي خادم في الوضع المحلي. لا تتبع، لا إعلانات، لا حسابات طرف ثالث، ولا مشاركة لموقعك الدقيق مع أي جهة.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Label("لا تتبع", systemImage: "eye.slash.fill")
                        .font(.subheadline)
                        .foregroundStyle(sahaGreen)
                    Label("لا إعلانات", systemImage: "nosign")
                        .font(.subheadline)
                        .foregroundStyle(sahaGreen)
                    Label("بياناتك على جهازك فقط", systemImage: "internaldrive.fill")
                        .font(.subheadline)
                        .foregroundStyle(sahaGreen)
                }
                .padding(.vertical, 4)
            }

            // الدعم والأسئلة الشائعة
            Section("الدعم") { // faq_settings_title = مركز الدعم
                NavigationLink("مركز الدعم") {
                    SupportView()
                }
                DisclosureGroup("كيف أكسب الكارما؟") {
                    Text("النشر +5، الرد +2، التصويت +1، وتلقي تصويت إيجابي +3. المكافأة اليومية +10.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                DisclosureGroup("هل اسمي ظاهر لأحد؟") {
                    Text("لا. تظهر فقط بوسم مجهول مثل «جار #1234»، ولا يرى أحد أي بيانات شخصية عنك.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                DisclosureGroup("كيف أغيّر مدينتي؟") {
                    Text("من وضع المستكشف في مزايا بلس يمكنك تصفح مدن أخرى بشفافية، دون تزييف موقعك.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }

            // الحساب
            Section("الحساب") {
                Button(role: .destructive) {
                    showingDeleteConfirmation = true
                } label: {
                    Text("حذف الحساب") // delete_acc_settings_title
                }
            }

            // عن التطبيق
            Section("عن التطبيق") {
                HStack {
                    Image(systemName: "square.grid.2x2.fill")
                        .foregroundStyle(sahaGreen)
                    Text("ساحة")
                        .font(.custom("Gotham-Bold", size: 18, relativeTo: .headline))
                    Spacer()
                    Text("الإصدار \(appVersionText)")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                Text("شبكة اجتماعية محلية مجهولة — شارك ما يدور حولك مع جيرانك.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("الإعدادات") // general_settings
        .preferredColorScheme(store.profile.darkMode ? .dark : .light)
        .confirmationDialog(
            "تأكيد الحذف", // delete_acc_confirm_title
            isPresented: $showingDeleteConfirmation,
            titleVisibility: .visible
        ) {
            Button("حذف الحساب نهائياً", role: .destructive) {
                store.deleteAccount()
            }
            Button("إلغاء", role: .cancel) {}
        } message: {
            Text("سيتم مسح كل بياناتك المحلية (منشوراتك وتصويتك وإعداداتك) وإعادة التطبيق إلى حالته الأولى. لا يمكن التراجع عن هذا الإجراء.")
        }
        .confirmationDialog(
            "إلغاء الحظر",
            isPresented: Binding(
                get: { showingUnblockConfirmation != nil },
                set: { if !$0 { showingUnblockConfirmation = nil } }
            ),
            titleVisibility: .visible
        ) {
            Button("إلغاء الحظر", role: .destructive) {
                if let tag = showingUnblockConfirmation {
                    store.unblockUser(tag: tag)
                }
                showingUnblockConfirmation = nil
            }
            Button("إلغاء", role: .cancel) {
                showingUnblockConfirmation = nil
            }
        } message: {
            if let tag = showingUnblockConfirmation {
                Text("هل تريد إلغاء حظر \(tag)؟ سيتمكن من مراسلتك مجدداً.")
            }
        }
    }

    // MARK: - Bindings (عبر واجهة AppStore فقط)

    private var languageBinding: Binding<AppLanguage> {
        Binding(
            get: { store.profile.language },
            set: { store.setLanguage($0) }
        )
    }

    private var darkModeBinding: Binding<Bool> {
        Binding(
            get: { store.profile.darkMode },
            set: { store.setDarkMode($0) }
        )
    }

    private var notificationsBinding: Binding<Bool> {
        Binding(
            get: { store.profile.notificationsEnabled },
            set: { newValue in
                store.profile.notificationsEnabled = newValue
                store.save()
            }
        )
    }

    private var messageRequestsBinding: Binding<Bool> {
        Binding(
            get: { messageRequestsEnabled },
            set: { newValue in
                messageRequestsEnabled = newValue
                store.toggleMessageRequests(newValue)
            }
        )
    }

    // MARK: - منتقي السمة
    private var themePickerRow: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("السمة")
                .font(.headline)
            LazyVGrid(
                columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())],
                spacing: 8
            ) {
                ForEach(themes, id: \.self) { theme in
                    Button {
                        store.setTheme(theme)
                    } label: {
                        Text(theme)
                            .font(.subheadline.weight(.semibold))
                            .frame(maxWidth: .infinity, minHeight: 44)
                            .background(store.profile.selectedTheme == theme ? sahaGreen : Color(.secondarySystemBackground))
                            .foregroundStyle(store.profile.selectedTheme == theme ? .white : .primary)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .padding(.vertical, 4)
    }

    // MARK: - منتقي أيقونة التطبيق
    private var appIconPickerRow: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("أيقونة التطبيق") // iap_paywall_intro_more_icons
                .font(.headline)
            LazyVGrid(
                columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())],
                spacing: 8
            ) {
                ForEach(appIcons, id: \.self) { iconName in
                    Button {
                        store.setAppIcon(iconName)
                    } label: {
                        Image(iconName)
                            .resizable()
                            .scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(store.profile.selectedIcon == iconName ? sahaGreen : Color.clear, lineWidth: 2)
                            )
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("أيقونة \(iconName)")
                }
            }
            Text("الأيقونات مفتوحة مجاناً للجميع.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 4)
    }
}

// MARK: - SupportView (مركز الدعم — محلي، بلا روابط خارجية)

private struct SupportView: View {
    var body: some View {
        List {
            Section("الأسئلة الشائعة") {
                DisclosureGroup("كيف أبلّغ عن منشور مسيء؟") {
                    Text("افتح المنشور واختر «إبلاغ». تُراجع البلاغات وتُخفى المنشورات التي تصل نتيجتها إلى −5 بالتصويت.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                DisclosureGroup("نسيت أنني حظرت أحداً — أين أجده؟") {
                    Text("من الإعدادات ثم «المستخدمون المحظورون»، ويمكنك إلغاء الحظر من هناك.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                DisclosureGroup("هل يعمل التطبيق دون إنترنت؟") {
                    Text("نعم، الوضع المحلي يعمل بالكامل دون اتصال، وتُحفظ بياناتك على جهازك.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
            Section("تواصل معنا") {
                Text("الدعم داخل التطبيق فقط في هذا الإصدار — لا تُرسل أي بيانات شخصية.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("مركز الدعم") // faq_settings_title
        .navigationBarTitleDisplayMode(.inline)
    }
}
