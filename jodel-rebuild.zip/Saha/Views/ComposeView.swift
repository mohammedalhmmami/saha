// ساحة — ComposeView
// ورقة إنشاء منشور جديد: نص، رمز صورة، وسوم، قناة، مدينة، وتحذير «الأجواء»
// قبل النشر القاسي. الحد الأقصى 500 حرف.
// SwiftUI + Foundation فقط، iOS 16+، بلا اعتماديات خارجية.

import SwiftUI

struct ComposeView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss

    @State private var text = ""
    @State private var selectedImageSymbol: String?
    @State private var hashtagInput = ""
    @State private var hashtags: [String] = []
    @State private var selectedChannelId: UUID?
    @State private var showBadVibesWarning = false
    @State private var showImagePicker = false

    private let maxLength = 500

    /// كلمات قاسية تُطلق تحذير «الأجواء» قبل النشر (نص أصلي من المواصفة).
    private let harshWords = ["غبي", "أحمق", "قبيح", "كريه", "سخيف", "تافه", "مقرف", "حقير"]

    /// رموز SF Symbols المتاحة كصورة توضيحية للمنشور.
    private let imageSymbols = [
        "sun.max.fill", "moon.stars.fill", "cloud.fill", "bolt.fill", "flame.fill",
        "leaf.fill", "heart.fill", "star.fill", "gift.fill", "music.note",
        "camera.fill", "cup.and.saucer.fill", "book.fill", "soccerball",
        "gamecontroller.fill", "mountain.2.fill", "car.fill", "airplane"
    ]

    private var trimmedText: String {
        text.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var canPost: Bool { !trimmedText.isEmpty }

    private var containsHarshWords: Bool {
        harshWords.contains { trimmedText.contains($0) }
    }

    /// كل الوسوم: ما أُدخل في حقل الوسوم + ما كُتب داخل النص نفسه.
    private var allHashtags: [String] {
        let fromText = sahaHashtags(in: trimmedText)
        let combined = hashtags + fromText
        var seen = Set<String>()
        return combined.filter { seen.insert($0).inserted }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    textSection
                    imageSection
                    hashtagSection
                    channelSection
                    cityRow
                }
                .padding()
            }
            .navigationTitle("منشور جديد")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("إلغاء") {
                        dismiss()
                    }
                    .frame(minHeight: 44)
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("نشر") {
                        attemptPost()
                    }
                    .font(.custom("Gotham-Bold", size: 16))
                    .foregroundColor(canPost ? SahaPalette.forest : .secondary)
                    .frame(minHeight: 44)
                    .disabled(!canPost)
                    .accessibilityLabel("نشر المنشور")
                }
            }
            .alert("هل ترغب في إلقاء نظرة أخرى؟", isPresented: $showBadVibesWarning) {
                Button("قم بتعديل الردّ", role: .cancel) { }
                Button("تابع النشر", role: .destructive) {
                    submitPost()
                }
            } message: {
                Text("قد يبدو تعليقك قاسيًا أو يُفهم بطريقة غير مقصودة. تذكّر أن كل من في ساحة شخص حقيقي مثلك.")
            }
        }
    }

    // MARK: - النص وعدّاد الأحرف

    private var textSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            ZStack(alignment: .topLeading) {
                if text.isEmpty {
                    Text("وش عندك اليوم؟ شاركنا ✍️📸")
                        .font(.custom("Gotham-Book", size: 17))
                        .foregroundColor(.secondary)
                        .padding(.top, 8)
                        .padding(.leading, 4)
                }
                TextEditor(text: $text)
                    .font(.custom("Gotham-Book", size: 17))
                    .foregroundColor(Color(.label))
                    .frame(minHeight: 140)
                    .scrollContentBackground(.hidden)
                    .onChange(of: text) { newValue in
                        if newValue.count > maxLength {
                            text = String(newValue.prefix(maxLength))
                        }
                    }
            }
            HStack {
                Spacer()
                Text("\(text.count)/\(maxLength)")
                    .font(.custom("Gotham-Book", size: 13))
                    .foregroundColor(text.count >= maxLength ? SahaPalette.downvote : .secondary)
            }
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .cornerRadius(16)
    }

    // MARK: - رمز الصورة التوضيحية

    private var imageSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("أضف صورة توضيحية", systemImage: "photo")
                    .font(.custom("Gotham-Bold", size: 16))
                    .foregroundColor(Color(.label))
                Spacer()
                if selectedImageSymbol != nil {
                    Button("إزالة") {
                        selectedImageSymbol = nil
                    }
                    .font(.custom("Gotham-Medium", size: 14))
                    .foregroundColor(SahaPalette.downvote)
                    .frame(minHeight: 44)
                }
            }

            if let symbol = selectedImageSymbol {
                Image(systemName: symbol)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: .infinity)
                    .aspectRatio(16.0 / 9.0, contentMode: .fit)
                    .foregroundColor(SahaPalette.forest)
                    .padding()
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(16)
            }

            Button {
                withAnimation(.easeInOut(duration: 0.25)) {
                    showImagePicker.toggle()
                }
            } label: {
                Label(showImagePicker ? "إخفاء الرموز" : "اختر رمزاً", systemImage: "photo.on.rectangle.angled")
                    .font(.custom("Gotham-Medium", size: 15))
                    .foregroundColor(SahaPalette.forest)
                    .frame(maxWidth: .infinity, minHeight: 44)
                    .background(SahaPalette.forest.opacity(0.10))
                    .cornerRadius(12)
            }

            if showImagePicker {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 52), spacing: 8)], spacing: 8) {
                    ForEach(imageSymbols, id: \.self) { symbol in
                        Button {
                            sahaHaptic(.light)
                            selectedImageSymbol = symbol
                        } label: {
                            Image(systemName: symbol)
                                .font(.system(size: 22))
                                .foregroundColor(selectedImageSymbol == symbol ? .white : SahaPalette.forest)
                                .frame(minWidth: 52, minHeight: 52)
                                .background(selectedImageSymbol == symbol
                                            ? SahaPalette.forest
                                            : SahaPalette.forest.opacity(0.10))
                                .cornerRadius(12)
                        }
                        .accessibilityLabel("رمز \(symbol)")
                    }
                }
            }
        }
    }

    // MARK: - الوسوم

    private var hashtagSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("الوسوم", systemImage: "number")
                .font(.custom("Gotham-Bold", size: 16))
                .foregroundColor(Color(.label))

            HStack(spacing: 8) {
                TextField("#اضف_هاشتاڨ", text: $hashtagInput)
                    .font(.custom("Gotham-Book", size: 16))
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .frame(minHeight: 44)
                    .padding(.horizontal, 12)
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(12)
                    .onSubmit { addHashtag() }

                Button("إضافة") {
                    addHashtag()
                }
                .font(.custom("Gotham-Bold", size: 15))
                .foregroundColor(SahaPalette.forest)
                .frame(minHeight: 44)
                .disabled(hashtagInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }

            if !hashtags.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(hashtags, id: \.self) { tag in
                            Button {
                                hashtags.removeAll { $0 == tag }
                            } label: {
                                HStack(spacing: 4) {
                                    Text("#\(tag)")
                                    Image(systemName: "xmark.circle.fill")
                                        .font(.system(size: 12))
                                }
                            }
                            .font(.custom("Gotham-Medium", size: 14))
                            .foregroundColor(SahaPalette.forest)
                            .padding(.horizontal, 10)
                            .frame(minHeight: 44)
                            .background(SahaPalette.forest.opacity(0.10))
                            .cornerRadius(12)
                        }
                    }
                }
            }
        }
    }

    private func addHashtag() {
        var tag = hashtagInput.trimmingCharacters(in: .whitespacesAndNewlines)
        if tag.hasPrefix("#") { tag.removeFirst() }
        tag = tag.replacingOccurrences(of: " ", with: "")
        guard !tag.isEmpty, !hashtags.contains(tag) else { return }
        hashtags.append(tag)
        hashtagInput = ""
    }

    // MARK: - القناة والمدينة

    private var channelSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("أُنشر في... 📍", systemImage: "number.circle.fill")
                .font(.custom("Gotham-Bold", size: 16))
                .foregroundColor(Color(.label))

            Picker("القناة", selection: $selectedChannelId) {
                Text("الصفحة الرئيسيّة").tag(UUID?.none)
                ForEach(store.channels) { channel in
                    Text(channel.name).tag(UUID?.some(channel.id))
                }
            }
            .pickerStyle(.menu)
            .font(.custom("Gotham-Medium", size: 16))
            .frame(minHeight: 44)
        }
    }

    private var cityRow: some View {
        HStack(spacing: 8) {
            Image(systemName: "mappin.circle.fill")
                .foregroundColor(SahaPalette.forest)
            Text("سيظهر منشورك في مدينة: \(store.currentCity.name)")
                .font(.custom("Gotham-Book", size: 15))
                .foregroundColor(.secondary)
            Spacer()
        }
        .frame(minHeight: 44)
    }

    // MARK: - النشر

    private func attemptPost() {
        guard canPost else { return }
        if containsHarshWords {
            showBadVibesWarning = true
        } else {
            submitPost()
        }
    }

    private func submitPost() {
        _ = store.createPost(
            text: trimmedText,
            imageSymbol: selectedImageSymbol,
            hashtags: allHashtags,
            channelId: selectedChannelId
        )
        sahaHaptic(.medium)
        dismiss()
    }
}
