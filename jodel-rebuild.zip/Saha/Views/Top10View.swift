import SwiftUI

// MARK: - Top10View
// ترند: أعلى 10 منشورات حسب النتيجة، مع فلاتر زمنية وفرز.
// Local Gems = مدينتي الحالية (store.topPosts)، وNational Treasures = كل المدن.

struct Top10View: View {
    @EnvironmentObject var store: AppStore

    @State private var days: Int = 1
    @State private var sort: FeedSort = .top
    @State private var selectedPost: Post?

    // ألوان Jodel Zero (من المواصفة §4)
    private var jodelGreen: Color { Color(red: 30 / 255, green: 122 / 255, blue: 76 / 255) }
    private var jodelGold: Color { Color(red: 232 / 255, green: 163 / 255, blue: 61 / 255) }

    private var cutoffDate: Date {
        Calendar.current.date(byAdding: .day, value: -days, to: Date()) ?? Date.distantPast
    }

    /// منشورات مدينتي من المتجر، ثم يُطبَّق عليها الفرز المختار.
    private var localPosts: [Post] {
        let ranked = store.topPosts(days: days)
        return Array(applySort(to: ranked).prefix(10))
    }

    /// منشورات كل المدن (الكنوز الوطنية) — من كل المنشورات المحلية مباشرة.
    private var nationalPosts: [Post] {
        let recent = store.posts.filter { $0.createdAt >= cutoffDate }
        return Array(applySort(to: recent).prefix(10))
    }

    private func applySort(to posts: [Post]) -> [Post] {
        switch sort {
        case .newest:
            return posts.sorted { $0.createdAt > $1.createdAt }
        case .top:
            return posts.sorted { $0.score > $1.score }
        case .commented:
            return posts.sorted { $0.replyCount > $1.replyCount }
        }
    }

    private func sortTitle(_ sort: FeedSort) -> String {
        switch sort {
        case .newest: return "جديد"          // front_page_filters_newest
        case .top: return "تصويت"            // front_page_filters_voted
        case .commented: return "تعليقات"    // front_page_filters_commented
        }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                // العنوان
                Text("ترند") // front_page_slider_title
                    .font(.custom("Gotham-Bold", size: 28, relativeTo: .largeTitle))
                    .padding(.horizontal)
                    .padding(.top)

                // فلاتر زمنية: الـ24 ساعة الماضية / الأيام الـ7 الماضية
                Picker("الإطار الزمني", selection: $days) {
                    Text("الـ24 ساعة الماضية").tag(1)   // front_page_day_sorting
                    Text("الأيام الـ7 الماضية").tag(7)  // front_page_week_sorting
                }
                .pickerStyle(.segmented)
                .padding()

                // فلاتر الفرز: جديد / تصويت / تعليقات
                Text("اختر الإطار الزمني:") // front_page_filters_timing_by — عنوان مجموعة الفلاتر
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal)
                HStack(spacing: 8) {
                    ForEach(FeedSort.allCases, id: \.self) { option in
                        Button {
                            sort = option
                        } label: {
                            Text(sortTitle(option))
                                .font(.subheadline.weight(.semibold))
                                .padding(.horizontal)
                                .frame(minHeight: 44)
                                .background(sort == option ? jodelGreen : Color(.secondarySystemBackground))
                                .foregroundStyle(sort == option ? .white : .primary)
                                .clipShape(Capsule())
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal)
                .padding(.vertical, 8)

                // جواهر مدينتي
                sectionHeader(title: "رائج في مدينتك", subtitle: store.currentCity.name) // front_page_local_title
                if localPosts.isEmpty {
                    emptyState
                } else {
                    ForEach(Array(localPosts.enumerated()), id: \.element.id) { index, post in
                        CompactPostRow(rank: index + 1, post: post, accent: jodelGreen)
                            .onTapGesture { selectedPost = post }
                    }
                }

                // كنوز الوطن
                sectionHeader(
                    title: "أنشط 10 منشورات في بلدك اليوم", // front_page_national_title
                    subtitle: "من كل المدن"
                )
                if nationalPosts.isEmpty {
                    emptyState
                } else {
                    ForEach(Array(nationalPosts.enumerated()), id: \.element.id) { index, post in
                        CompactPostRow(rank: index + 1, post: post, accent: jodelGold)
                            .onTapGesture { selectedPost = post }
                    }
                }
            }
            .padding(.bottom)
        }
        .sheet(item: $selectedPost) { post in
            Top10PostDetailSheet(post: post)
        }
    }

    private func sectionHeader(title: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title)
                .font(.custom("Gotham-Bold", size: 20, relativeTo: .title2))
            Text(subtitle)
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .padding(.horizontal)
        .padding(.top)
        .padding(.bottom, 4)
    }

    private var emptyState: some View {
        VStack(spacing: 8) {
            Image(systemName: "flame")
                .font(.largeTitle)
                .foregroundStyle(.secondary)
            Text("لا توجد منشورات رائجة بعد في هذه الفترة")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding()
    }
}

// MARK: - CompactPostRow
// صف مضغوط لمنشور واحد: الترتيب، النص، الوسوم، النتيجة والتعليقات.

private struct CompactPostRow: View {
    let rank: Int
    let post: Post
    let accent: Color

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            // شارة الترتيب (حجمها من محتواها + حشوة — بلا أبعاد ثابتة)
            ZStack {
                Circle()
                    .fill(rank <= 3 ? accent : Color(.secondarySystemBackground))
                Text("\(rank)")
                    .font(.custom("Gotham-Bold", size: 16, relativeTo: .headline))
                    .foregroundStyle(rank <= 3 ? .white : .primary)
                    .padding(8)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(post.text)
                    .font(.body)
                    .lineLimit(2)
                if !post.hashtags.isEmpty {
                    Text(post.hashtags.map { "#\($0)" }.joined(separator: " "))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                HStack(spacing: 12) {
                    Label("\(post.authorTag)", systemImage: "person.circle")
                    Label("\(post.score)", systemImage: "arrow.up")
                    Label("\(post.replyCount)", systemImage: "text.bubble")
                    Text(post.city)
                    Text(post.createdAt, style: .relative)
                }
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(1)
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(Color(.systemBackground))
        .overlay(Divider(), alignment: .bottom)
    }
}

// MARK: - Top10PostDetailSheet
// عرض بسيط للمنشور المختار (دون الاعتماد على شاشات وكيل آخر).

private struct Top10PostDetailSheet: View {
    let post: Post
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Image(systemName: "person.circle.fill")
                            .font(.title2)
                            .foregroundStyle(.secondary)
                        VStack(alignment: .leading) {
                            Text(post.authorTag).font(.headline)
                            Text("\(post.city) • \(post.createdAt, style: .relative)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        if post.isBoosted {
                            Label("مُعزَّز", systemImage: "rocket.fill")
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(.orange)
                        }
                    }
                    Text(post.text).font(.body)
                    if !post.hashtags.isEmpty {
                        Text(post.hashtags.map { "#\($0)" }.joined(separator: " "))
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    HStack(spacing: 16) {
                        Label("\(post.upvotes)", systemImage: "arrow.up.circle.fill")
                            .foregroundStyle(.green)
                        Label("\(post.downvotes)", systemImage: "arrow.down.circle.fill")
                            .foregroundStyle(.red)
                        Label("\(post.replyCount) رد", systemImage: "text.bubble")
                    }
                    .font(.subheadline)
                }
                .padding()
            }
            .navigationTitle("المنشور")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("إغلاق") { dismiss() }
                }
            }
        }
    }
}
