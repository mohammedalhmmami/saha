import SwiftUI

// MARK: - PlusView
// مزايا «بلس» — كلها مفتوحة مجاناً للجميع: بلا جدار دفع، بلا اشتراك،
// بلا مشتريات، بلا أسعار، بلا أقفال. كل ميزة تحمل شارة «مفتوح مجاناً».

struct PlusView: View {
    @EnvironmentObject var store: AppStore

    private var jodelGreen: Color { Color(red: 30 / 255, green: 122 / 255, blue: 76 / 255) }
    private var jodelGold: Color { Color(red: 232 / 255, green: 163 / 255, blue: 61 / 255) }

    /// السمات الثماني — نفس القائمة في SettingsView.
    private var themes: [(name: String, color: Color)] {
        [
            ("افتراضي", Color(red: 30 / 255, green: 122 / 255, blue: 76 / 255)),
            ("غابة", .green),
            ("محيط", .blue),
            ("غروب", .orange),
            ("ليلكي", .purple),
            ("ذهبي", Color(red: 232 / 255, green: 163 / 255, blue: 61 / 255)),
            ("وردي", .pink),
            ("فحمي", .gray),
        ]
    }

    /// أيقونات التطبيق الخمس (premiumLogo1–5 من الأصول المستخرجة).
    private var appIcons: [String] {
        ["premiumLogo1", "premiumLogo2", "premiumLogo3", "premiumLogo4", "premiumLogo5"]
    }

    /// ألوان المنشورات الثماني (ألوان الكارما — المواصفة §4)، كلها مفتوحة.
    private var postColors: [(name: String, color: Color)] {
        [
            ("أخضر", .green),
            ("أزرق", .blue),
            ("بنفسجي", .purple),
            ("برتقالي", .orange),
            ("وردي", .pink),
            ("تركوازي", .teal),
            ("ذهبي", Color(red: 232 / 255, green: 163 / 255, blue: 61 / 255)),
            ("أحمر", .red),
        ]
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // الرأس
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Image(systemName: "sparkles")
                            .font(.title2)
                            .foregroundStyle(jodelGold)
                        Text("افتح أكثر من 12 ميزات إضافية!") // iap_paywall_intro_title_unlock
                            .font(.custom("Gotham-Bold", size: 22, relativeTo: .title2))
                    }
                    Text("كل المزايا هنا مفتوحة مجاناً للجميع — بلا اشتراك وبلا دفع وبلا أقفال.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    FreeBadge()
                }

                // المكافآت الأسبوعية: 3 من كل نوع كل أسبوع
                weeklyRewardsSection

                // السمات المخصصة (8)
                VStack(alignment: .leading, spacing: 8) {
                    sectionTitle("سمات مخصصة", icon: "paintbrush.fill")
                    LazyVGrid(
                        columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())],
                        spacing: 12
                    ) {
                        ForEach(themes, id: \.name) { theme in
                            Button {
                                store.setTheme(theme.name)
                            } label: {
                                VStack(spacing: 6) {
                                    Circle()
                                        .fill(theme.color)
                                        .aspectRatio(1, contentMode: .fit)
                                        .overlay(
                                            Circle()
                                                .stroke(store.profile.selectedTheme == theme.name ? Color.primary : Color.clear, lineWidth: 2)
                                        )
                                    Text(theme.name)
                                        .font(.caption.weight(.semibold))
                                        .foregroundStyle(.primary)
                                    Text("مفتوح مجاناً")
                                        .font(.caption2)
                                        .foregroundStyle(jodelGreen)
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }

                // أيقونات التطبيق المخصصة (5)
                VStack(alignment: .leading, spacing: 8) {
                    sectionTitle("أيقونات تطبيق مخصصة", icon: "app.fill") // iap_paywall_intro_more_icons
                    LazyVGrid(
                        columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())],
                        spacing: 12
                    ) {
                        ForEach(appIcons, id: \.self) { iconName in
                            Button {
                                store.setAppIcon(iconName)
                            } label: {
                                VStack(spacing: 6) {
                                    Image(iconName)
                                        .resizable()
                                        .scaledToFit()
                                        .clipShape(RoundedRectangle(cornerRadius: 12))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 12)
                                                .stroke(store.profile.selectedIcon == iconName ? jodelGreen : Color.clear, lineWidth: 2)
                                        )
                                    Text("مفتوح مجاناً")
                                        .font(.caption2)
                                        .foregroundStyle(jodelGreen)
                                }
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel("أيقونة \(iconName)")
                        }
                    }
                }

                // ألوان منشورات إضافية (8 ألوان كارما)
                VStack(alignment: .leading, spacing: 8) {
                    sectionTitle("ألوان منشورات مميزة", icon: "paintpalette.fill")
                    LazyVGrid(
                        columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())],
                        spacing: 12
                    ) {
                        ForEach(postColors, id: \.name) { item in
                            VStack(spacing: 6) {
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(item.color)
                                    .aspectRatio(1.6, contentMode: .fit)
                                    .overlay(
                                        Text("أ")
                                            .font(.custom("Gotham-Bold", size: 18, relativeTo: .headline))
                                            .foregroundStyle(.white)
                                    )
                                Text(item.name)
                                    .font(.caption.weight(.semibold))
                                Text("مفتوح مجاناً")
                                    .font(.caption2)
                                    .foregroundStyle(jodelGreen)
                            }
                        }
                    }
                }

                // الردود الصوتية ونشر الفيديو — شارتان مفتوحتان
                VStack(alignment: .leading, spacing: 8) {
                    sectionTitle("مزايا النشر", icon: "mic.fill")
                    PlusFeatureRow(
                        icon: "waveform",
                        title: "الصوت إلى رد", // iap_confirmation_premium_features_voice_to_replies
                        description: "أرسل ردوداً صوتية في المحادثات والمنشورات."
                    )
                    PlusFeatureRow(
                        icon: "video.fill",
                        title: "سجِّل وانشر مقاطع فيديو", // iap_paywall_intro_video
                        description: "سجّل مقاطع فيديو قصيرة وشاركها مع ساحتك."
                    )
                    PlusFeatureRow(
                        icon: "photo.fill",
                        title: "تحميلات الاستوديو",
                        description: "ارفع صوراً من استوديو هاتفك مباشرة في منشوراتك."
                    )
                    PlusFeatureRow(
                        icon: "nosign",
                        title: "بدون إعلانات",
                        description: "تجربة تصفح نظيفة — التطبيق بلا إعلانات أصلاً."
                    )
                }

                // وضع المستكشف — متصفح مدن شفاف
                exploreModeSection
            }
            .padding()
        }
        .navigationTitle("بلس")
    }

    // MARK: - المكافآت الأسبوعية
    private var weeklyRewardsSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            sectionTitle("مكافآت أسبوعية مجانية", icon: "gift.fill") // iap_confirmation_premium_rewards
            Text("تحصّل على 3 مجّانًا من كل نوع كلّ أسبوع – فقط تذكّر أنّها تُعاد إلى الصّفر إذا لم تُستخدم!")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            HStack(spacing: 12) {
                RewardCard(icon: "rocket.fill", title: "تعزيزات", count: store.profile.boostsAvailable, tint: .orange)
                RewardCard(icon: "gift.fill", title: "هدايا", count: store.profile.giftsAvailable, tint: .pink)
                RewardCard(icon: "paintpalette.fill", title: "ألوان", count: store.profile.premiumColorsAvailable, tint: .purple)
            }
            Text("يستمر التّعزيز الواحد لمدة 10 دقائق.") // boost_sheet_footer
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    // MARK: - وضع المستكشف

    /// المدن القابلة للتصفح: عند إيقاف «تزييف الموقع» تقتصر على مدينتك فقط (#15).
    private var browsableCities: [City] {
        store.zero.locationSpoof ? store.cities : store.cities.filter { $0.isHometown }
    }

    private var exploreModeSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            sectionTitle("وضع المستكشف", icon: "globe") // iap_confirmation_premium_features_explore_mode
            Text("تفاعل مع مجتمعات Jodel Zero من حول العالم") // iap_confirmation_premium_features_explore_mode_description (مقتبس)
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Text("تصفح شفاف: تختار مدينة وتتصفح منشوراتها كما هي، دون تزييف موقعك ودون إخفاء أنك زائر.")
                .font(.caption)
                .foregroundStyle(.secondary)
            if store.zero.locationSpoof == false {
                Text("«تزييف الموقع» متوقف في إعدادات Zero — يعرض وضع المستكشف مدينتك فقط. فعّله من الإعدادات لتصفح مدن أخرى.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            ForEach(browsableCities) { city in
                Button {
                    store.currentCity = city
                } label: {
                    HStack {
                        Image(systemName: city.isHometown ? "house.fill" : "mappin.circle.fill")
                            .foregroundStyle(jodelGreen)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(city.name)
                                .font(.headline)
                                .foregroundStyle(.primary)
                            Text(city.nameEn)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        if store.currentCity.id == city.id {
                            Label("الحالية", systemImage: "checkmark.circle.fill")
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(jodelGreen)
                        } else {
                            Text("مفتوح مجاناً")
                                .font(.caption2)
                                .foregroundStyle(jodelGreen)
                        }
                    }
                    .padding(.vertical, 6)
                }
                .buttonStyle(.plain)
            }
        }
    }

    private func sectionTitle(_ title: String, icon: String) -> some View {
        HStack(spacing: 6) {
            Image(systemName: icon)
                .foregroundStyle(jodelGold)
            Text(title)
                .font(.custom("Gotham-Bold", size: 20, relativeTo: .title2))
            Spacer()
            Text("مفتوح مجاناً")
                .font(.caption.weight(.semibold))
                .foregroundStyle(jodelGreen)
        }
    }
}

// MARK: - FreeBadge

private struct FreeBadge: View {
    var body: some View {
        Label("مفتوح مجاناً — بلا دفع", systemImage: "checkmark.seal.fill")
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(Color(red: 30 / 255, green: 122 / 255, blue: 76 / 255))
            .padding(.horizontal)
            .frame(minHeight: 44)
            .background(Color(red: 30 / 255, green: 122 / 255, blue: 76 / 255).opacity(0.12))
            .clipShape(Capsule())
    }
}

// MARK: - RewardCard

private struct RewardCard: View {
    let icon: String
    let title: String
    let count: Int
    let tint: Color

    var body: some View {
        VStack(spacing: 4) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundStyle(tint)
            Text("\(count)")
                .font(.custom("Gotham-Bold", size: 20, relativeTo: .title2))
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text("3 أسبوعياً")
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

// MARK: - PlusFeatureRow

private struct PlusFeatureRow: View {
    let icon: String
    let title: String
    let description: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            ZStack {
                Circle().fill(Color(.secondarySystemBackground))
                Image(systemName: icon)
                    .foregroundStyle(Color(red: 30 / 255, green: 122 / 255, blue: 76 / 255))
                    .padding(10)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.headline)
                Text(description)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Text("مفتوح مجاناً")
                .font(.caption.weight(.semibold))
                .foregroundStyle(Color(red: 30 / 255, green: 122 / 255, blue: 76 / 255))
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}
