import SwiftUI

// MARK: - ProfileView
// ملفي: الوسم المجهول، الكارما مع حلقة التقدم للمستوى التالي، منشوراتي،
// تصويتي، شبكة الإنجازات، المكافأة اليومية، وأرصدة التعزيزات/الهدايا/الألوان.
// ملاحظة: الإنجازات تُشتق محلياً من بيانات الملف (المنشورات والكارما والتصويت)
// لأن واجهة AppStore في المواصفة §3 لا تحوي قائمة إنجازات جاهزة.

struct ProfileView: View {
    @EnvironmentObject var store: AppStore

    @State private var justClaimedReward = false
    @State private var selectedPost: Post?

    private var sahaGreen: Color { Color(red: 30 / 255, green: 122 / 255, blue: 76 / 255) }
    private var sahaGold: Color { Color(red: 232 / 255, green: 163 / 255, blue: 61 / 255) }

    private var profile: UserProfile { store.profile }

    private var myPosts: [Post] {
        store.posts
            .filter { $0.isMine || profile.myPostIds.contains($0.id) }
            .sorted { $0.createdAt > $1.createdAt }
    }

    private var myVotedPosts: [Post] {
        store.posts
            .filter { $0.myVote != .none }
            .sorted { $0.createdAt > $1.createdAt }
    }

    /// التقدم نحو المستوى التالي: المستوى = karma / 100 + 1 (المواصفة §2).
    private var progressToNextLevel: Double {
        let remainder = max(0, profile.karma % 100)
        return Double(remainder) / 100.0
    }

    private var karmaToNextLevel: Int {
        100 - max(0, profile.karma % 100)
    }

    // MARK: - الإنجازات (مشتقة من بيانات الملف الفعلية)
    private var achievements: [Achievement] {
        let postCount = myPosts.count
        let karma = max(0, profile.karma)
        let votes = max(0, profile.myVoteCount)
        let repliesGiven = store.replies.values.flatMap { $0 }.filter { $0.isMine }.count
        return [
            Achievement(
                id: "first_post", title: "أول منشور",
                description: "انشر أول منشور لك في ساحتك",
                icon: "paperplane.fill",
                isUnlocked: postCount >= 1,
                progress: min(1, Double(postCount))
            ),
            Achievement(
                id: "ten_posts", title: "صوت الساحة",
                description: "انشر 10 منشورات",
                icon: "megaphone.fill",
                isUnlocked: postCount >= 10,
                progress: min(1, Double(postCount) / 10)
            ),
            Achievement(
                id: "karma_100", title: "كارما 100",
                description: "اجمع 100 نقطة كارما",
                icon: "star.fill",
                isUnlocked: karma >= 100,
                progress: min(1, Double(karma) / 100)
            ),
            Achievement(
                id: "karma_500", title: "نجم المجتمع",
                description: "اجمع 500 نقطة كارما",
                icon: "crown.fill",
                isUnlocked: karma >= 500,
                progress: min(1, Double(karma) / 500)
            ),
            Achievement(
                id: "ten_votes", title: "صوّت بعشرة",
                description: "صوّت على 10 منشورات",
                icon: "hand.thumbsup.fill",
                isUnlocked: votes >= 10,
                progress: min(1, Double(votes) / 10)
            ),
            Achievement(
                id: "fifty_votes", title: "قاضي الساحة",
                description: "صوّت على 50 منشوراً",
                icon: "scale.3d",
                isUnlocked: votes >= 50,
                progress: min(1, Double(votes) / 50)
            ),
            Achievement(
                id: "first_reply", title: "أول رد",
                description: "رد على منشور جارك",
                icon: "text.bubble.fill",
                isUnlocked: repliesGiven >= 1,
                progress: min(1, Double(repliesGiven))
            ),
            Achievement(
                id: "ten_replies", title: "جار طيب",
                description: "اكتب 10 ردود",
                icon: "heart.fill",
                isUnlocked: repliesGiven >= 10,
                progress: min(1, Double(repliesGiven) / 10)
            ),
        ]
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // الرأس: الوسم + حلقة الكارما
                karmaHeader

                // المكافأة اليومية
                dailyRewardCard

                // الأرصدة: تعزيزات / هدايا / ألوان مميزة
                balancesRow

                // الإنجازات
                VStack(alignment: .leading, spacing: 8) {
                    Text("إنجازاتي")
                        .font(.custom("Gotham-Bold", size: 20, relativeTo: .title2))
                    LazyVGrid(
                        columns: [GridItem(.flexible()), GridItem(.flexible())],
                        spacing: 12
                    ) {
                        ForEach(achievements) { achievement in
                            AchievementCard(achievement: achievement)
                        }
                    }
                }

                // منشوراتي
                profilePostsSection(title: "منشوراتي", posts: myPosts, emptyText: "لم تنشر أي منشور بعد")

                // تصويتي
                profilePostsSection(title: "تصويتي", posts: myVotedPosts, emptyText: "لم تصوّت على أي منشور بعد") // my_votes
            }
            .padding()
        }
        .navigationTitle("حسابي") // profile_settings_title
        .sheet(item: $selectedPost) { post in
            ProfilePostSheet(post: post)
        }
    }

    // MARK: - رأس الكارما
    // حلقة التقدم: قطرها من محتواها (نص الكارما + حشوة) — بلا أبعاد ثابتة.
    private var karmaHeader: some View {
        HStack(spacing: 16) {
            ZStack {
                Circle()
                    .stroke(Color(.tertiarySystemBackground), lineWidth: 10)
                Circle()
                    .trim(from: 0, to: progressToNextLevel)
                    .stroke(sahaGold, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                VStack(spacing: 0) {
                    Text("\(profile.karma)")
                        .font(.custom("Gotham-Bold", size: 22, relativeTo: .title2))
                    Text("كارما")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding()
            }
            .aspectRatio(1, contentMode: .fit)

            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 6) {
                    Image(systemName: "person.circle.fill")
                        .font(.title2)
                        .foregroundStyle(.secondary)
                    Text(profile.tag)
                        .font(.custom("Gotham-Bold", size: 20, relativeTo: .title2))
                        .lineLimit(1)
                }
                Text(profile.levelName)
                    .font(.headline)
                    .foregroundStyle(sahaGreen)
                Text("الكارما الخاصّة بي") // karma_info_title
                    .font(.subheadline)
                Text("تبقّى \(karmaToNextLevel) نقطة للمستوى التالي")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text("الكارما الخاصة بك تُظهر مساهمتك الإيجابية في مجتمعك.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    // MARK: - المكافأة اليومية
    private var dailyRewardCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "gift.fill")
                    .foregroundStyle(sahaGold)
                Text("المكافأة اليومية")
                    .font(.custom("Gotham-Bold", size: 18, relativeTo: .headline))
                Spacer()
                if justClaimedReward {
                    Text("+10 كارما")
                        .font(.headline)
                        .foregroundStyle(sahaGreen)
                }
            }
            Text("عُد كل يوم واحصل على 10 نقاط كارما.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Button {
                if store.claimDailyReward() {
                    justClaimedReward = true
                }
            } label: {
                Text(profile.dailyRewardsClaimed || justClaimedReward ? "تم استلام مكافأة اليوم" : "استلم مكافأتك اليومية")
                    .font(.headline)
                    .frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.borderedProminent)
            .tint(sahaGreen)
            .disabled(profile.dailyRewardsClaimed || justClaimedReward)
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    // MARK: - الأرصدة
    private var balancesRow: some View {
        HStack(spacing: 12) {
            BalanceCard(icon: "rocket.fill", title: "تعزيزات", count: profile.boostsAvailable, tint: .orange)
            BalanceCard(icon: "gift.fill", title: "هدايا", count: profile.giftsAvailable, tint: .pink)
            BalanceCard(icon: "paintpalette.fill", title: "ألوان مميزة", count: profile.premiumColorsAvailable, tint: .purple)
        }
    }

    private func profilePostsSection(title: String, posts: [Post], emptyText: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.custom("Gotham-Bold", size: 20, relativeTo: .title2))
            if posts.isEmpty {
                Text(emptyText)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.vertical, 4)
            } else {
                ForEach(posts) { post in
                    Button {
                        selectedPost = post
                    } label: {
                        ProfilePostRow(post: post)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

// MARK: - BalanceCard

private struct BalanceCard: View {
    let icon: String
    let title: String
    let count: Int
    let tint: Color

    var body: some View {
        VStack(spacing: 4) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundStyle(tint)
            Text("\(count)")
                .font(.custom("Gotham-Bold", size: 20, relativeTo: .title2))
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

// MARK: - AchievementCard

private struct AchievementCard: View {
    let achievement: Achievement

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                ZStack {
                    Circle()
                        .fill(achievement.isUnlocked ? Color(red: 232 / 255, green: 163 / 255, blue: 61 / 255).opacity(0.2) : Color(.tertiarySystemBackground))
                    Image(systemName: achievement.icon)
                        .foregroundStyle(achievement.isUnlocked ? Color(red: 232 / 255, green: 163 / 255, blue: 61 / 255) : .secondary)
                        .padding(10)
                }
                Spacer()
                if achievement.isUnlocked {
                    Image(systemName: "checkmark.seal.fill")
                        .foregroundStyle(Color(red: 30 / 255, green: 122 / 255, blue: 76 / 255))
                } else {
                    Image(systemName: "lock.fill")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            Text(achievement.title)
                .font(.headline)
            Text(achievement.description)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(2)
            ProgressView(value: achievement.progress)
                .tint(achievement.isUnlocked ? Color(red: 30 / 255, green: 122 / 255, blue: 76 / 255) : .gray)
            Text(achievement.isUnlocked ? "مفتوح" : "\(Int(achievement.progress * 100))٪")
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .opacity(achievement.isUnlocked ? 1 : 0.75)
    }
}

// MARK: - ProfilePostRow

private struct ProfilePostRow: View {
    let post: Post

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(post.text)
                    .font(.body)
                    .lineLimit(2)
                Spacer()
                if post.myVote != .none {
                    Image(systemName: post.myVote == .up ? "arrow.up.circle.fill" : "arrow.down.circle.fill")
                        .foregroundStyle(post.myVote == .up ? .green : .red)
                }
            }
            HStack(spacing: 12) {
                Label("\(post.score)", systemImage: "arrow.up")
                Label("\(post.replyCount)", systemImage: "text.bubble")
                Text(post.city)
                Text(post.createdAt, style: .relative)
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            .lineLimit(1)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

// MARK: - ProfilePostSheet

private struct ProfilePostSheet: View {
    let post: Post
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Image(systemName: "person.circle.fill")
                            .font(.title2)
                            .foregroundStyle(.secondary)
                        VStack(alignment: .leading) {
                            Text(post.authorTag).font(.headline)
                            Text("\(post.city) • \(post.createdAt, style: .relative)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    Text(post.text).font(.body)
                    if !post.hashtags.isEmpty {
                        Text(post.hashtags.map { "#\($0)" }.joined(separator: " "))
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    HStack(spacing: 16) {
                        Label("\(post.upvotes)", systemImage: "arrow.up.circle.fill")
                            .foregroundStyle(.green)
                        Label("\(post.downvotes)", systemImage: "arrow.down.circle.fill")
                            .foregroundStyle(.red)
                        Label("\(post.replyCount) رد", systemImage: "text.bubble")
                    }
                    .font(.subheadline)
                }
                .padding()
            }
            .navigationTitle("المنشور")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("إغلاق") { dismiss() }
                }
            }
        }
    }
}
