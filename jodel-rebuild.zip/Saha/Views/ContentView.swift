// ساحة (Saha) — ContentView.swift
// الشاشة الجذرية: شريط علوي + 5 تبويبات + زر نشر عائم.
// يفتح مباشرة على الخلاصة — بلا دخول، بلا كود تفعيل، بلا بوابة تمهيدية.
// الإعدادات تُفتح من ProfileView. SwiftUI فقط، iOS 16+، بلا اعتماديات خارجية.

import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var store: AppStore

    @State private var selectedTab = 0
    @State private var showCompose = false
    @State private var showSearch = false
    @State private var showPlus = false

    var body: some View {
        VStack(spacing: 0) {
            topBar

            ZStack(alignment: .bottomTrailing) {
                TabView(selection: $selectedTab) {
                    FeedView()
                        .tabItem {
                            Label("الصفحة الرئيسيّة", systemImage: "house.fill")
                        }
                        .tag(0)

                    Top10View()
                        .tabItem {
                            Label("ترند", systemImage: "flame.fill")
                        }
                        .tag(1)

                    ChannelsView()
                        .tabItem {
                            Label("القنوات", systemImage: "number.circle.fill")
                        }
                        .tag(2)

                    ChatListView()
                        .tabItem {
                            Label("محادثات خاصة", systemImage: "message.fill")
                        }
                        .tag(3)

                    ProfileView()
                        .tabItem {
                            Label("حسابي", systemImage: "person.crop.circle.fill")
                        }
                        .tag(4)
                }

                // زر النشر العائم — فوق شريط التبويبات، في الزاوية السفلية.
                Button {
                    sahaHaptic(.medium)
                    showCompose = true
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                        .frame(width: 56, height: 56)
                        .background(SahaPalette.forest)
                        .clipShape(Circle())
                        .shadow(color: Color.black.opacity(0.25), radius: 8, x: 0, y: 4)
                }
                .accessibilityLabel("إنشاء منشور جديد")
                .padding(.trailing, 20)
                .padding(.bottom, 88)
            }
        }
        .sheet(isPresented: $showCompose) {
            ComposeView()
        }
        .sheet(isPresented: $showSearch) {
            SearchView()
        }
        .sheet(isPresented: $showPlus) {
            PlusView()
        }
    }

    // MARK: الشريط العلوي — المدينة الحالية + بحث + بلس

    private var topBar: some View {
        HStack(spacing: 12) {
            // المدينة الحالية (تُدار من منتقي المدن في الخلاصة).
            Label {
                Text(store.currentCity.name)
                    .font(SahaTheme.titleFont(size: 17))
                    .foregroundColor(SahaTheme.text)
                    .lineLimit(1)
            } icon: {
                Image(systemName: "mappin.circle.fill")
                    .foregroundColor(SahaPalette.forest)
            }
            .accessibilityLabel("المدينة الحالية: \(store.currentCity.name)")

            Spacer()

            Button {
                sahaHaptic(.light)
                showSearch = true
            } label: {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(SahaTheme.text)
                    .frame(minWidth: 44, minHeight: 44)
                    .contentShape(Rectangle())
            }
            .accessibilityLabel("بحث")

            Button {
                sahaHaptic(.light)
                showPlus = true
            } label: {
                Text("بلس")
                    .font(SahaTheme.titleFont(size: 15))
                    .foregroundColor(.white)
                    .padding(.horizontal, 14)
                    .frame(minHeight: 44)
                    .background(SahaPalette.karmaGold)
                    .cornerRadius(22)
            }
            .accessibilityLabel("مزايا بلس — مجانية")
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 4)
        .background(SahaTheme.card)
    }
}
