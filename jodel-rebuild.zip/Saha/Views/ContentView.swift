// Jodel Zero — ContentView.swift
// الشاشة الجذرية: شريط علوي + 4 تبويبات + زر نشر عائم.
// يفتح مباشرة على الخلاصة — بلا دخول، بلا كود تفعيل، بلا بوابة تمهيدية.
// الإعدادات تُفتح من ProfileView. SwiftUI فقط، iOS 16+، بلا اعتماديات خارجية.

import LocalAuthentication
import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.scenePhase) private var scenePhase

    @State private var selectedTab = 0
    @State private var showCompose = false
    @State private var showSearch = false
    @State private var showPlus = false
    @State private var isLocked = false
    @State private var hasUnlockedThisLaunch = false

    var body: some View {
        VStack(spacing: 0) {
            topBar

            ZStack(alignment: .bottomTrailing) {
                TabView(selection: $selectedTab) {
                    FeedView()
                        .tabItem {
                            Label("الفيد", systemImage: "house.fill")
                        }
                        .tag(0)

                    ChannelsView()
                        .tabItem {
                            Label("القنوات", systemImage: "number.circle.fill")
                        }
                        .tag(1)

                    ChatListView()
                        .tabItem {
                            Label("المحادثات", systemImage: "message.fill")
                        }
                        .tag(2)

                    ProfileView()
                        .tabItem {
                            Label("حسابي", systemImage: "person.crop.circle.fill")
                        }
                        .tag(3)
                }

                // زر النشر العائم — فوق شريط التبويبات، في الزاوية السفلية.
                Button {
                    jodelHaptic(.medium)
                    showCompose = true
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                        .frame(width: 56, height: 56)
                        .background(JodelZeroPalette.forest)
                        .clipShape(Circle())
                        .shadow(color: Color.black.opacity(0.25), radius: 8, x: 0, y: 4)
                }
                .accessibilityLabel("إنشاء منشور جديد")
                .padding(.trailing, 20)
                .padding(.bottom, 88)
            }
        }
        .sheet(isPresented: $showCompose) {
            ComposeView()
        }
        .sheet(isPresented: $showSearch) {
            SearchView()
        }
        .sheet(isPresented: $showPlus) {
            PlusView()
        }
        .onAppear {
            lockIfNeeded()
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active {
                lockIfNeeded()
            }
        }
        .overlay {
            if isLocked {
                lockOverlay
            }
        }
    }

    // MARK: - قفل التطبيق (#9 — Face ID)

    /// يقفل التطبيق عند الحاجة: عند الإطلاق دائماً إن كانت الحماية
    /// مفعّلة؛ وعند كل عودة للمقدمة إن كان «القفل عند كل فتح» مفعّلاً.
    private func lockIfNeeded() {
        guard store.zero.protectApp else { return }
        if store.zero.askEachTime || hasUnlockedThisLaunch == false {
            isLocked = true
            authenticate()
        }
    }

    /// مصادقة Face ID مع رجوع لرمز الدخول.
    private func authenticate() {
        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            // الجهاز بلا Face ID/رمز — لا يمكن القفل؛ نفتح مباشرة.
            isLocked = false
            return
        }
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "افتح Jodel Zero") { success, _ in
            Task { @MainActor in
                if success {
                    isLocked = false
                    hasUnlockedThisLaunch = true
                }
            }
        }
    }

    /// شاشة القفل: تغطي التطبيق كاملاً حتى المصادقة.
    private var lockOverlay: some View {
        ZStack {
            Color(.systemBackground).ignoresSafeArea()
            VStack(spacing: 20) {
                Image(systemName: "square.grid.2x2.fill")
                    .font(.system(size: 56))
                    .foregroundStyle(JodelZeroPalette.forest)
                Text("Jodel Zero")
                    .font(.custom("Gotham-Bold", size: 28, relativeTo: .title))
                Text("التطبيق مقفل — تحقق من هويتك للمتابعة")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Button {
                    authenticate()
                } label: {
                    Label("فتح بـ Face ID", systemImage: "faceid")
                        .font(.custom("Gotham-Bold", size: 17))
                        .foregroundColor(.white)
                        .frame(maxWidth: 260, minHeight: 50)
                        .background(JodelZeroPalette.forest)
                        .cornerRadius(14)
                }
                .buttonStyle(.plain)
            }
            .padding()
        }
    }

    // MARK: الشريط العلوي — المدينة الحالية + بحث + بلس

    private var topBar: some View {
        HStack(spacing: 12) {
            // المدينة الحالية (تُدار من منتقي المدن في الخلاصة).
            Label {
                Text(store.currentCity.name)
                    .font(JodelZeroTheme.titleFont(size: 17))
                    .foregroundColor(JodelZeroTheme.text)
                    .lineLimit(1)
            } icon: {
                Image(systemName: "mappin.circle.fill")
                    .foregroundColor(JodelZeroPalette.forest)
            }
            .accessibilityLabel("المدينة الحالية: \(store.currentCity.name)")

            Spacer()

            Button {
                jodelHaptic(.light)
                showSearch = true
            } label: {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(JodelZeroTheme.text)
                    .frame(minWidth: 44, minHeight: 44)
                    .contentShape(Rectangle())
            }
            .accessibilityLabel("بحث")

            Button {
                jodelHaptic(.light)
                showPlus = true
            } label: {
                Text("بلس")
                    .font(JodelZeroTheme.titleFont(size: 15))
                    .foregroundColor(.white)
                    .padding(.horizontal, 14)
                    .frame(minHeight: 44)
                    .background(JodelZeroPalette.karmaGold)
                    .cornerRadius(22)
            }
            .accessibilityLabel("مزايا بلس — مجانية")
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 4)
        .background(JodelZeroTheme.card)
    }
}
