import SwiftUI

/// صفحة القناة: الترويسة (الأيقونة والاسم والوصف وعدد الأعضاء وزر الانضمام/المغادرة)،
/// ومنشورات القناة، وزر نشر فيها، وزر الإبلاغ.
/// النصوص العربية من `ar.lproj/Localizable.strings` حرفياً:
/// `channel_flag_title` = «الإبلاغ عن القناة»، `channel_flag_conf_title` = «تم الإبلاغ عن القناة»،
/// `channel_postto_title` = «أُنشر في... 📍».
struct ChannelDetailView: View {
    let channel: Channel

    @EnvironmentObject private var store: AppStore
    @State private var showComposeSheet = false
    @State private var showReportConfirmation = false
    @State private var showReportDone = false

    /// القناة الحية من المتجر حتى تنعكس حالة الانضمام فوراً.
    private var liveChannel: Channel {
        store.channels.first(where: { $0.id == channel.id }) ?? channel
    }

    private var channelPosts: [Post] {
        store.posts
            .filter { $0.channelId == channel.id }
            .sorted { $0.createdAt > $1.createdAt }
    }

    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 10) {
                    HStack(alignment: .top, spacing: 12) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 14)
                                .fill(ChannelColorHelper.color(named: liveChannel.color).opacity(0.18))
                                .frame(width: 56, height: 56)
                            Image(systemName: liveChannel.icon.isEmpty ? "number" : liveChannel.icon)
                                .font(.title2)
                                .foregroundStyle(ChannelColorHelper.color(named: liveChannel.color))
                        }
                        VStack(alignment: .leading, spacing: 4) {
                            Text(liveChannel.name)
                                .font(.custom("Gotham-Bold", size: 20, relativeTo: .title3))
                            Text(liveChannel.description)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    HStack(spacing: 16) {
                        Label("\(liveChannel.memberCount) عضو", systemImage: "person.2.fill")
                        Label("\(liveChannel.postCount) منشور", systemImage: "doc.text.fill")
                        if !liveChannel.category.isEmpty {
                            Label(liveChannel.category, systemImage: "tag.fill")
                        }
                    }
                    .font(.caption)
                    .foregroundStyle(.secondary)

                    HStack {
                        Button(liveChannel.isJoined ? "مغادرة القناة" : "انضمام إلى القناة") {
                            if liveChannel.isJoined {
                                store.leaveChannel(liveChannel)
                            } else {
                                store.joinChannel(liveChannel)
                            }
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(liveChannel.isJoined ? .secondary : .green)
                        Spacer()
                        Button("أُنشر في... 📍") {
                            showComposeSheet = true
                        }
                        .buttonStyle(.bordered)
                    }
                }
                .padding(.vertical, 4)
            }

            if channelPosts.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "tray")
                        .font(.largeTitle)
                        .foregroundStyle(.secondary)
                    Text("لا منشورات في هذه القناة بعد")
                        .font(.headline)
                    Text("كن أول من ينشر هنا.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding()
            } else {
                ForEach(channelPosts) { post in
                    ChannelPostRow(post: post)
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(liveChannel.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    showReportConfirmation = true
                } label: {
                    Label("الإبلاغ عن القناة", systemImage: "flag")
                }
            }
        }
        .confirmationDialog(
            "الإبلاغ عن القناة",
            isPresented: $showReportConfirmation,
            titleVisibility: .visible
        ) {
            Button("الإبلاغ عن القناة", role: .destructive) {
                store.reportChannel(liveChannel)
                showReportDone = true
            }
            Button("إلغاء", role: .cancel) {}
        } message: {
            Text("سيتم إخطار مديري المجتمع للتحقق من هذه القناة.")
        }
        .alert("تم الإبلاغ عن القناة", isPresented: $showReportDone) {
            Button("حسناً") {}
        } message: {
            Text("تم إخطار مديري المجتمع لدينا للتحقق من هذه القناة. شكرًا لك على الحفاظ على ساحة آمنة.")
        }
        .sheet(isPresented: $showComposeSheet) {
            ChannelComposeSheet(channel: liveChannel) { text in
                _ = store.createPost(
                    text: text,
                    imageSymbol: nil,
                    hashtags: [],
                    channelId: liveChannel.id
                )
            }
        }
    }
}

/// صف منشور داخل القناة: الوسم المجهول والنص والنتيجة وعدد الردود والوقت،
/// مع بطاقة الاستطلاع إن كان المنشور يحمل استطلاعاً.
/// (عرض مبسط محلي؛ بطاقة المنشور الكاملة في `PostCardView`.)
private struct ChannelPostRow: View {
    let post: Post

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(post.authorTag)
                    .font(.subheadline.weight(.semibold))
                Spacer()
                Text(post.createdAt, style: .relative)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Text(post.text)
                .font(.body)
            if let symbol = post.imageSymbol {
                Image(systemName: symbol)
                    .font(.largeTitle)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 4)
            }
            if !post.hashtags.isEmpty {
                Text(post.hashtags.map { "#\($0)" }.joined(separator: " "))
                    .font(.caption)
                    .foregroundStyle(.green)
            }
            if post.poll != nil {
                PollView(post: post)
            }
            HStack(spacing: 16) {
                Label("\(post.score)", systemImage: "arrow.up.arrow.down")
                Label("\(post.replyCount) رد", systemImage: "message")
                if post.isBoosted {
                    Label("معزز", systemImage: "bolt.fill")
                        .foregroundStyle(.orange)
                }
            }
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .padding(.vertical, 4)
    }
}

/// ورقة نشر سريع داخل القناة الحالية (النشر يذهب لهذه القناة فقط).
private struct ChannelComposeSheet: View {
    let channel: Channel
    var onPost: (_ text: String) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var text = ""

    private var canPost: Bool {
        !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("أُنشر في... 📍 \(channel.name)") {
                    TextField("وش عندك اليوم؟ شاركنا", text: $text, axis: .vertical)
                        .lineLimit(5...)
                }
                Section {
                    Text("سينشر هذا المنشور في قناة \(channel.name) فقط، وسيظهر باسمك المجهول.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("نشر في القناة")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("إلغاء") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("نشر") {
                        onPost(text.trimmingCharacters(in: .whitespacesAndNewlines))
                        dismiss()
                    }
                    .disabled(!canPost)
                }
            }
        }
    }
}
