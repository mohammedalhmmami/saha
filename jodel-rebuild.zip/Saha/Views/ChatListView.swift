import SwiftUI

/// قائمة المحادثات الخاصة («محادثات خاصة» — `chat_center` في `ar.lproj/Localizable.strings`).
/// أقسام: طلبات المراسلة (قابلة للقبول/الرفض)، ثم المحادثات.
/// مفتاح إيقاف طلبات المراسلة من النصوص حرفياً:
/// `chat_request_post_turn_off` = «قم بتعطيل طلبات المحادثات الخاصة 📭».
/// الحظر: `chat_block_button` = «🚫 أحظر المستخدم».
///
/// ملاحظة عن المواصفة: `AppStore` (القسم 3 من `ARCHITECTURE.md`) لا يعرّف
/// دالة لقبول/رفض طلب مراسلة، فتُحفظ قرارات القبول والرفض محلياً فقط
/// (UserDefaults عبر `HandledRequestsStore`) ولا تُرسل لأي خادم.
struct ChatListView: View {
    @EnvironmentObject private var store: AppStore

    /// مفتاح طلبات المراسلة — يُزامَن مع المتجر عبر `toggleMessageRequests`.
    @AppStorage("com.nebra.jodelzero.messageRequestsEnabled") private var requestsEnabled = true
    /// قرارات القبول/الرفض المحلية (معرّفات المحادثات بصيغة JSON).
    @AppStorage("com.nebra.jodelzero.acceptedRequests") private var acceptedData = ""
    @AppStorage("com.nebra.jodelzero.declinedRequests") private var declinedData = ""
    @State private var blockedNoticeTag: String?

    private var acceptedIDs: Set<UUID> { HandledRequestsStore.decode(acceptedData) }
    private var declinedIDs: Set<UUID> { HandledRequestsStore.decode(declinedData) }

    /// طلبات مراسلة واردة لم يُبتّ فيها بعد (وليست محظورة).
    private var pendingRequests: [Conversation] {
        store.conversations.filter {
            $0.isRequest && !$0.isBlocked
                && !acceptedIDs.contains($0.id)
                && !declinedIDs.contains($0.id)
        }
        .sorted { $0.lastAt > $1.lastAt }
    }

    /// المحادثات العادية + الطلبات المقبولة (وليست محظورة).
    private var mainConversations: [Conversation] {
        store.conversations.filter {
            !$0.isBlocked
                && (!$0.isRequest || acceptedIDs.contains($0.id))
                && !declinedIDs.contains($0.id)
        }
        .sorted { $0.lastAt > $1.lastAt }
    }

    /// المحادثات المحظورة (تظهر في قسم منفصل مع زر إلغاء الحظر).
    private var blockedConversations: [Conversation] {
        store.conversations.filter { $0.isBlocked }
            .sorted { $0.lastAt > $1.lastAt }
    }

    var body: some View {
        List {
            Section {
                Toggle(isOn: $requestsEnabled) {
                    Label("طلبات المحادثات الخاصة", systemImage: "envelope.open")
                }
                .onChange(of: requestsEnabled) { newValue in
                    store.toggleMessageRequests(newValue)
                }
                if !requestsEnabled {
                    Text("قم بتعطيل طلبات المحادثات الخاصة 📭 — لن تصلك طلبات مراسلة جديدة من أشخاص لا تعرفهم.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            if !pendingRequests.isEmpty {
                Section("طلبات المراسلة") {
                    ForEach(pendingRequests) { conversation in
                        VStack(alignment: .leading, spacing: 8) {
                            ChatRow(conversation: conversation)
                            HStack {
                                Button("قبول") {
                                    accept(conversation)
                                }
                                .buttonStyle(.borderedProminent)
                                .tint(.green)
                                Button("رفض") {
                                    decline(conversation)
                                }
                                .buttonStyle(.bordered)
                            }
                        }
                        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                            Button(role: .destructive) {
                                block(conversation)
                            } label: {
                                Label("حظر", systemImage: "nosign")
                            }
                        }
                    }
                }
            }

            if mainConversations.isEmpty && pendingRequests.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "message")
                        .font(.largeTitle)
                        .foregroundStyle(.secondary)
                    Text("لا محادثات بعد")
                        .font(.headline)
                    Text("عندما يراسلك أحد الجيران مجهولي الهوية ستظهر محادثته هنا.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding()
            } else {
                Section("المحادثات") {
                    ForEach(mainConversations) { conversation in
                        NavigationLink {
                            ChatView(conversation: conversation)
                        } label: {
                            ChatRow(conversation: conversation)
                        }
                        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                            Button(role: .destructive) {
                                block(conversation)
                            } label: {
                                Label("🚫 أحظر المستخدم", systemImage: "nosign")
                            }
                        }
                        .contextMenu {
                            Button(role: .destructive) {
                                block(conversation)
                            } label: {
                                Label("🚫 أحظر المستخدم", systemImage: "nosign")
                            }
                        }
                    }
                }
            }

            if !blockedConversations.isEmpty {
                Section("المحظورون") {
                    ForEach(blockedConversations) { conversation in
                        HStack {
                            ChatRow(conversation: conversation)
                            Spacer()
                            Button("إلغاء الحظر") {
                                store.unblockUser(tag: conversation.otherTag)
                            }
                            .buttonStyle(.bordered)
                            .controlSize(.small)
                        }
                        .contextMenu {
                            Button {
                                store.unblockUser(tag: conversation.otherTag)
                            } label: {
                                Label("إلغاء الحظر", systemImage: "checkmark.circle")
                            }
                        }
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("محادثات خاصة")
        .alert("تم حظر المستخدم", isPresented: Binding(
            get: { blockedNoticeTag != nil },
            set: { if !$0 { blockedNoticeTag = nil } }
        )) {
            Button("حسناً") { blockedNoticeTag = nil }
        } message: {
            Text("لن يتمكن هذا الشخص من بعث رسائل أو طلبات جديدة لك وسيتم حذف المحادثة آليا.")
        }
    }

    private func accept(_ conversation: Conversation) {
        var ids = acceptedIDs
        ids.insert(conversation.id)
        acceptedData = HandledRequestsStore.encode(ids)
    }

    private func decline(_ conversation: Conversation) {
        var ids = declinedIDs
        ids.insert(conversation.id)
        declinedData = HandledRequestsStore.encode(ids)
    }

    private func block(_ conversation: Conversation) {
        store.blockUser(tag: conversation.otherTag)
        blockedNoticeTag = conversation.otherTag
    }
}

/// صف محادثة: الوسم المجهول للطرف الآخر، إيموجي الفايب، آخر رسالة، الوقت، وشارة غير المقروء.
private struct ChatRow: View {
    let conversation: Conversation

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(Color.green.opacity(0.15))
                    .frame(width: 48, height: 48)
                Text(conversation.vibe.isEmpty ? "🙂" : conversation.vibe)
                    .font(.title2)
            }
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(conversation.otherTag)
                        .font(.headline)
                        .lineLimit(1)
                    Spacer()
                    Text(conversation.lastAt, style: .relative)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                HStack {
                    Text(conversation.lastMessage.isEmpty ? "…" : conversation.lastMessage)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    Spacer()
                    if conversation.unreadCount > 0 {
                        Text("\(conversation.unreadCount)")
                            .font(.caption2.weight(.bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 7)
                            .padding(.vertical, 3)
                            .background(Color.green)
                            .clipShape(Capsule())
                            .accessibilityLabel("\(conversation.unreadCount) رسائل غير مقروءة")
                    }
                }
            }
        }
        .padding(.vertical, 4)
    }
}

/// ترميز محلي خفيف لمجموعة معرّفات UUID في نص JSON (لقرارات قبول/رفض الطلبات).
/// لا فك قسري: أي بيانات تالفة تعني مجموعة فارغة.
private enum HandledRequestsStore {
    static func decode(_ data: String) -> Set<UUID> {
        guard let raw = data.data(using: .utf8),
              let ids = try? JSONDecoder().decode([UUID].self, from: raw) else {
            return []
        }
        return Set(ids)
    }

    static func encode(_ ids: Set<UUID>) -> String {
        guard let raw = try? JSONEncoder().encode(Array(ids)),
              let text = String(data: raw, encoding: .utf8) else {
            return ""
        }
        return text
    }
}
