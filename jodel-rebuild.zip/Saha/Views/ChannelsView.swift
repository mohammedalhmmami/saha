import SwiftUI

/// تصفح القنوات: بحث، فلتر «المنضم إليها»، انضمام/مغادرة، وإنشاء قناة جديدة.
/// حد المتابعة من `config.json`: `channels_follow_limit: 100`.
/// النصوص العربية من `ar.lproj/Localizable.strings` حرفياً:
/// `search_label_channel` = «قناة»، `channel_followed_toast` = «Channel followed».
struct ChannelsView: View {
    @EnvironmentObject private var store: AppStore

    @State private var query = ""
    @State private var showJoinedOnly = false
    @State private var showCreateSheet = false
    @State private var justFollowedName: String?

    /// عدد القنوات المنضم إليها حالياً (الحد الأقصى 100 من `config.json`).
    private var joinedCount: Int {
        store.channels.filter { $0.isJoined }.count
    }

    private var filteredChannels: [Channel] {
        var list = store.channels
        if showJoinedOnly {
            list = list.filter { $0.isJoined }
        }
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmed.isEmpty {
            list = list.filter {
                $0.name.localizedCaseInsensitiveContains(trimmed)
                    || $0.description.localizedCaseInsensitiveContains(trimmed)
                    || $0.category.localizedCaseInsensitiveContains(trimmed)
            }
        }
        return list.sorted { lhs, rhs in
            if lhs.isJoined != rhs.isJoined { return lhs.isJoined }
            return lhs.memberCount > rhs.memberCount
        }
    }

    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 6) {
                    Text("يمكنك متابعة حتى 100 قناة")
                        .font(.subheadline.weight(.semibold))
                    Text("أنت منضم الآن إلى \(joinedCount) من 100 قناة. عند بلوغ الحد لن تتمكن من الانضمام لقناة جديدة قبل مغادرة إحداها.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            if filteredChannels.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "magnifyingglass")
                        .font(.largeTitle)
                        .foregroundStyle(.secondary)
                    Text("لم يتم العثورعلى أية نتائج")
                        .font(.headline)
                    Text(showJoinedOnly ? "لم تنضم إلى أي قناة بعد." : "جرّب كلمة بحث مختلفة أو أنشئ قناة جديدة.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding()
            } else {
                ForEach(filteredChannels) { channel in
                    ChannelRow(
                        channel: channel,
                        joinDisabled: !channel.isJoined && joinedCount >= 100
                    ) {
                        if channel.isJoined {
                            store.leaveChannel(channel)
                        } else {
                            store.joinChannel(channel)
                            justFollowedName = channel.name
                        }
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("القنوات")
        .searchable(text: $query, prompt: "ابحث عن قناة…")
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Picker("العرض", selection: $showJoinedOnly) {
                    Text("الكل").tag(false)
                    Text("المنضم إليها").tag(true)
                }
                .pickerStyle(.segmented)
            }
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    showCreateSheet = true
                } label: {
                    Label("إنشاء قناة", systemImage: "plus")
                }
            }
        }
        .sheet(isPresented: $showCreateSheet) {
            CreateChannelSheet { name, description, icon, color, category in
                _ = store.createChannel(
                    name: name,
                    description: description,
                    icon: icon,
                    color: color,
                    category: category
                )
            }
        }
        .alert("Channel followed", isPresented: Binding(
            get: { justFollowedName != nil },
            set: { if !$0 { justFollowedName = nil } }
        )) {
            Button("حسناً") { justFollowedName = nil }
        } message: {
            if let name = justFollowedName {
                Text("انضممت إلى قناة \(name).")
            }
        }
    }
}

/// صف قناة واحدة: الأيقونة والاسم والوصف وعدد الأعضاء والمنشورات وزر انضمام/مغادرة.
private struct ChannelRow: View {
    let channel: Channel
    let joinDisabled: Bool
    let onJoinToggle: () -> Void

    var body: some View {
        NavigationLink {
            ChannelDetailView(channel: channel)
        } label: {
            HStack(alignment: .top, spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(ChannelColorHelper.color(named: channel.color).opacity(0.18))
                        .frame(width: 48, height: 48)
                    Image(systemName: channel.icon.isEmpty ? "number" : channel.icon)
                        .font(.title3)
                        .foregroundStyle(ChannelColorHelper.color(named: channel.color))
                }
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Text(channel.name)
                            .font(.headline)
                        if channel.isJoined {
                            Text("منضم")
                                .font(.caption2.weight(.semibold))
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(Color.green.opacity(0.15))
                                .foregroundStyle(.green)
                                .clipShape(Capsule())
                        }
                    }
                    Text(channel.description)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                    HStack(spacing: 12) {
                        Label("\(channel.memberCount) عضو", systemImage: "person.2.fill")
                        Label("\(channel.postCount) منشور", systemImage: "doc.text.fill")
                        if !channel.category.isEmpty {
                            Label(channel.category, systemImage: "tag.fill")
                        }
                    }
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    Button(channel.isJoined ? "مغادرة" : "انضمام") {
                        onJoinToggle()
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                    .disabled(joinDisabled)
                    .tint(channel.isJoined ? .secondary : .green)
                }
            }
            .padding(.vertical, 4)
        }
    }
}

/// ورقة إنشاء قناة جديدة: الاسم والوصف والأيقونة واللون والتصنيف.
private struct CreateChannelSheet: View {
    var onCreate: (_ name: String, _ description: String, _ icon: String, _ color: String, _ category: String) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var description = ""
    @State private var icon = "message"
    @State private var color = "أخضر"
    @State private var category = "عام"

    private let icons = [
        "message", "sportscourt", "fork.knife", "book", "music.note",
        "gamecontroller", "camera", "heart", "star", "globe", "car", "briefcase"
    ]
    private let colors = ["أخضر", "أزرق", "بنفسجي", "برتقالي", "وردي", "تركوازي", "ذهبي", "أحمر"]
    private let categories = ["عام", "رياضة", "طعام", "دراسة", "فن", "موسيقى", "ألعاب", "تقنية"]

    private var canCreate: Bool {
        !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("القناة") {
                    TextField("اسم القناة", text: $name)
                    TextField("وصف قصير عن القناة", text: $description, axis: .vertical)
                        .lineLimit(3...)
                }
                Section("الأيقونة") {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 44))], spacing: 12) {
                        ForEach(icons, id: \.self) { symbol in
                            Button {
                                icon = symbol
                            } label: {
                                Image(systemName: symbol)
                                    .font(.title3)
                                    .frame(minWidth: 44, minHeight: 44)
                                    .background(icon == symbol ? Color.green.opacity(0.15) : Color.clear)
                                    .foregroundStyle(icon == symbol ? .green : .primary)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                Section("اللون") {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 44))], spacing: 12) {
                        ForEach(colors, id: \.self) { colorName in
                            Button {
                                color = colorName
                            } label: {
                                Circle()
                                    .fill(ChannelColorHelper.color(named: colorName))
                                    .frame(minWidth: 32, minHeight: 32)
                                    .overlay(
                                        Circle()
                                            .strokeBorder(Color.primary, lineWidth: color == colorName ? 2 : 0)
                                    )
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel(colorName)
                        }
                    }
                }
                Section("التصنيف") {
                    Picker("التصنيف", selection: $category) {
                        ForEach(categories, id: \.self) { item in
                            Text(item).tag(item)
                        }
                    }
                    .pickerStyle(.segmented)
                }
                Section {
                    Text("القنوات في «ساحة» مجتمعات محلية مجهولة. بإنشائك قناة فأنت توافق على أن تبقى محادثاتها محترمة وآمنة للجميع.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("إنشاء قناة")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("إلغاء") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("إنشاء") {
                        onCreate(
                            name.trimmingCharacters(in: .whitespacesAndNewlines),
                            description.trimmingCharacters(in: .whitespacesAndNewlines),
                            icon,
                            color,
                            category
                        )
                        dismiss()
                    }
                    .disabled(!canCreate)
                }
            }
        }
    }
}

/// تحويل اسم لون القناة (من ألوان الكارما الثمانية في المواصفة) إلى `Color`.
/// الأسماء هي القيم المخزنة في `Channel.color`؛ لا علاقة لها بأي خادم خارجي.
enum ChannelColorHelper {
    static func color(named name: String) -> Color {
        switch name {
        case "أخضر", "green": return Color(red: 0x1E / 255, green: 0x7A / 255, blue: 0x4C / 255)
        case "أزرق", "blue": return .blue
        case "بنفسجي", "purple": return .purple
        case "برتقالي", "orange": return .orange
        case "وردي", "pink": return .pink
        case "تركوازي", "teal": return .teal
        case "ذهبي", "gold": return Color(red: 0xE8 / 255, green: 0xA3 / 255, blue: 0x3D / 255)
        case "أحمر", "red": return .red
        default: return .green
        }
    }
}
