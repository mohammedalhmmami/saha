import SwiftUI

// MARK: - SearchView
// بحث في القنوات (بالاسم) والوسوم (بالوسم) ونص المنشورات، مع تصفية لغة
// (عربي / إنجليزي) تُصفّي النتائج حسب لغة النص الفعلية.

struct SearchView: View {
    @EnvironmentObject var store: AppStore

    @State private var query: String = ""
    @State private var selectedLanguages: Set<AppLanguage> = [.arabic, .english]
    @State private var selectedChannel: Channel?
    @State private var selectedHashtag: HashtagSelection?
    @State private var selectedPost: Post?

    private var trimmedQuery: String {
        query.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var isSearching: Bool { !trimmedQuery.isEmpty }

    // MARK: - كشف لغة النص (وجود حروف عربية من عدمه)
    private func containsArabic(_ text: String) -> Bool {
        text.unicodeScalars.contains { scalar in
            (0x0600...0x06FF).contains(scalar.value)
                || (0x0750...0x077F).contains(scalar.value)
                || (0xFB50...0xFDFF).contains(scalar.value)
                || (0xFE70...0xFEFF).contains(scalar.value)
        }
    }

    private func matchesSelectedLanguages(_ text: String) -> Bool {
        // إن لم تُختر أي لغة، تُعرض كل النتائج.
        if selectedLanguages.isEmpty { return true }
        let isArabic = containsArabic(text)
        if isArabic && selectedLanguages.contains(.arabic) { return true }
        if !isArabic && selectedLanguages.contains(.english) { return true }
        return false
    }

    // MARK: - النتائج
    private var matchedChannels: [Channel] {
        guard isSearching else { return [] }
        return store.channels.filter { channel in
            let haystack = "\(channel.name) \(channel.description)"
            return haystack.localizedCaseInsensitiveContains(trimmedQuery)
                && matchesSelectedLanguages(haystack)
        }
    }

    private var matchedHashtags: [String] {
        guard isSearching else { return [] }
        let needle = trimmedQuery
            .trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        let tags = store.posts.flatMap { $0.hashtags }
        let unique = Array(Set(tags)).sorted()
        return unique.filter { tag in
            tag.localizedCaseInsensitiveContains(needle)
                && matchesSelectedLanguages(tag)
        }
    }

    private var matchedPosts: [Post] {
        guard isSearching else { return [] }
        return store.posts.filter { post in
            post.text.localizedCaseInsensitiveContains(trimmedQuery)
                && matchesSelectedLanguages(post.text)
        }
    }

    private var hasAnyResult: Bool {
        !matchedChannels.isEmpty || !matchedHashtags.isEmpty || !matchedPosts.isEmpty
    }

    /// وسوم شائعة للتصفح حين لا يوجد بحث.
    private var popularHashtags: [String] {
        let tags = store.posts.flatMap { $0.hashtags }
        var counts: [String: Int] = [:]
        for tag in tags { counts[tag, default: 0] += 1 }
        return counts.sorted { $0.value > $1.value }.prefix(10).map { $0.key }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // صف تصفية اللغة — يصفّي الخلاصة والنتائج باللغات المختارة
                languageFilterRow

                if isSearching {
                    if hasAnyResult {
                        List {
                            if !matchedChannels.isEmpty {
                                Section("قناة") { // search_label_channel
                                    ForEach(matchedChannels) { channel in
                                        Button {
                                            selectedChannel = channel
                                        } label: {
                                            channelRow(channel)
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                            }
                            if !matchedHashtags.isEmpty {
                                Section("هاشتاڨ") { // search_label_hashtag
                                    ForEach(matchedHashtags, id: \.self) { tag in
                                        Button {
                                            selectedHashtag = HashtagSelection(tag: tag)
                                        } label: {
                                            HStack {
                                                Image(systemName: "number")
                                                    .foregroundStyle(.secondary)
                                                Text("#\(tag)")
                                                Spacer()
                                                Image(systemName: "chevron.left")
                                                    .font(.caption)
                                                    .foregroundStyle(.tertiary)
                                            }
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                            }
                            if !matchedPosts.isEmpty {
                                Section("نص") { // search_label_text
                                    ForEach(matchedPosts) { post in
                                        Button {
                                            selectedPost = post
                                        } label: {
                                            SearchPostRow(post: post)
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                            }
                        }
                        .listStyle(.insetGrouped)
                    } else {
                        emptyResultsView
                    }
                } else {
                    // حالة ما قبل البحث: قنوات ووسوم للتصفح
                    List {
                        Section("القنوات") {
                            ForEach(store.channels) { channel in
                                Button {
                                    selectedChannel = channel
                                } label: {
                                    channelRow(channel)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        if !popularHashtags.isEmpty {
                            Section("وسوم رائجة") {
                                ForEach(popularHashtags, id: \.self) { tag in
                                    Button {
                                        selectedHashtag = HashtagSelection(tag: tag)
                                    } label: {
                                        HStack {
                                            Image(systemName: "number")
                                                .foregroundStyle(.secondary)
                                            Text("#\(tag)")
                                            Spacer()
                                            Image(systemName: "chevron.left")
                                                .font(.caption)
                                                .foregroundStyle(.tertiary)
                                        }
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                    }
                    .listStyle(.insetGrouped)
                }
            }
            .navigationTitle("بحث")
            .searchable(text: $query, prompt: "بحث") // hashtagsearch_placeholder
            .sheet(item: $selectedChannel) { channel in
                SearchChannelSheet(channel: channel)
            }
            .sheet(item: $selectedHashtag) { selection in
                SearchHashtagSheet(tag: selection.tag)
            }
            .sheet(item: $selectedPost) { post in
                SearchPostSheet(post: post)
            }
        }
    }

    // MARK: - صف تصفية اللغة
    private var languageFilterRow: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("تواصل مع أعضاء آخرين بنفس اللغة") // language_filter_popup_header (مقتبس المعنى)
                .font(.caption)
                .foregroundStyle(.secondary)
            HStack(spacing: 8) {
                languageChip(.arabic, title: "العربية")
                languageChip(.english, title: "English")
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(Color(.secondarySystemBackground))
    }

    private func languageChip(_ language: AppLanguage, title: String) -> some View {
        let isSelected = selectedLanguages.contains(language)
        return Button {
            if isSelected {
                selectedLanguages.remove(language)
            } else {
                selectedLanguages.insert(language)
            }
        } label: {
            HStack(spacing: 4) {
                Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                Text(title)
            }
            .font(.subheadline.weight(.semibold))
            .padding(.horizontal)
            .frame(minHeight: 44)
            .background(isSelected ? Color(red: 30 / 255, green: 122 / 255, blue: 76 / 255) : Color(.systemBackground))
            .foregroundStyle(isSelected ? .white : .primary)
            .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }

    private func channelRow(_ channel: Channel) -> some View {
        HStack(spacing: 12) {
            ZStack {
                Circle().fill(Color(.secondarySystemBackground))
                Image(systemName: channel.icon)
                    .foregroundStyle(.primary)
                    .padding(10)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(channel.name).font(.headline)
                Text(channel.description)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                Text("\(channel.memberCount) مشارك • \(channel.postCount) منشور")
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
            }
            Spacer()
            Image(systemName: "chevron.left")
                .font(.caption)
                .foregroundStyle(.tertiary)
        }
        .padding(.vertical, 4)
    }

    private var emptyResultsView: some View {
        VStack(spacing: 12) {
            Image(systemName: "magnifyingglass")
                .font(.largeTitle)
                .foregroundStyle(.secondary)
            Text("لم يتم العثور على أية نتائج") // textsearch_empty_result
                .font(.headline)
            Text("جرّب كلمة أخرى أو غيّر تصفية اللغة")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }
}

// MARK: - HashtagSelection
// غلاف Identifiable للوسم المختار (String وحدها لا تصلح لـ sheet(item:)).

private struct HashtagSelection: Identifiable {
    let tag: String
    var id: String { tag }
}

// MARK: - صف منشور في نتائج البحث

private struct SearchPostRow: View {
    let post: Post

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(post.text)
                .font(.body)
                .lineLimit(2)
            HStack(spacing: 12) {
                Text(post.authorTag)
                Label("\(post.score)", systemImage: "arrow.up")
                Label("\(post.replyCount)", systemImage: "text.bubble")
                Text(post.city)
                Text(post.createdAt, style: .relative)
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            .lineLimit(1)
        }
        .padding(.vertical, 4)
    }
}

// MARK: - أوراق التفاصيل (محلية — لا تعتمد على شاشات وكيل آخر)

private struct SearchChannelSheet: View {
    let channel: Channel
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss

    private var channelPosts: [Post] {
        store.posts.filter { $0.channelId == channel.id }
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack(spacing: 12) {
                        ZStack {
                            Circle().fill(Color(.secondarySystemBackground))
                            Image(systemName: channel.icon).font(.title2).padding()
                        }
                        VStack(alignment: .leading, spacing: 2) {
                            Text(channel.name)
                                .font(.custom("Gotham-Bold", size: 20, relativeTo: .title2))
                            Text("\(channel.memberCount) مشارك • \(channel.postCount) منشور")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    Text(channel.description).font(.body)
                    Text(channel.category)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Section("منشورات القناة") {
                    if channelPosts.isEmpty {
                        Text("لا توجد منشورات في هذه القناة بعد")
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(channelPosts) { post in
                            SearchPostRow(post: post)
                        }
                    }
                }
            }
            .navigationTitle(channel.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("إغلاق") { dismiss() }
                }
            }
        }
    }
}

private struct SearchHashtagSheet: View {
    let tag: String
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss

    private var taggedPosts: [Post] {
        store.posts.filter { $0.hashtags.contains(tag) }
    }

    var body: some View {
        NavigationStack {
            List {
                ForEach(taggedPosts) { post in
                    SearchPostRow(post: post)
                }
            }
            .navigationTitle("#\(tag)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("إغلاق") { dismiss() }
                }
            }
        }
    }
}

private struct SearchPostSheet: View {
    let post: Post
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Image(systemName: "person.circle.fill")
                            .font(.title2)
                            .foregroundStyle(.secondary)
                        VStack(alignment: .leading) {
                            Text(post.authorTag).font(.headline)
                            Text("\(post.city) • \(post.createdAt, style: .relative)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    Text(post.text).font(.body)
                    if !post.hashtags.isEmpty {
                        Text(post.hashtags.map { "#\($0)" }.joined(separator: " "))
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    HStack(spacing: 16) {
                        Label("\(post.upvotes)", systemImage: "arrow.up.circle.fill")
                            .foregroundStyle(.green)
                        Label("\(post.downvotes)", systemImage: "arrow.down.circle.fill")
                            .foregroundStyle(.red)
                        Label("\(post.replyCount) رد", systemImage: "text.bubble")
                    }
                    .font(.subheadline)
                }
                .padding()
            }
            .navigationTitle("المنشور")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("إغلاق") { dismiss() }
                }
            }
        }
    }
}
