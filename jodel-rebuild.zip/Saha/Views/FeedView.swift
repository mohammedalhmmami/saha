// Jodel Zero — FeedView
// الخلاصة الرئيسية: قائمة بطاقات، فرز، سحب للتحديث، منتقي مدن شفاف للتصفح،
 // حالات تحميل/فارغة، وقسم للمنشورات المعزَّزة.
// SwiftUI + Foundation فقط، iOS 16+، بلا اعتماديات خارجية.

import SwiftUI

struct FeedView: View {
    @EnvironmentObject private var store: AppStore

    @State private var showCityPicker = false
    @State private var showCompose = false
    @State private var selectedPost: Post?
    @State private var showDetail = false

    private var allPosts: [Post] { store.feedPosts() }
    private var boostedPosts: [Post] { allPosts.filter { $0.isBoosted } }
    private var regularPosts: [Post] { allPosts.filter { !$0.isBoosted } }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                sortPicker
                searchBanner
                content
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("JodelZero")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    cityButton
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        jodelHaptic(.light)
                        showCompose = true
                    } label: {
                        Image(systemName: "plus")
                            .font(.system(size: 17, weight: .semibold))
                            .frame(minWidth: 44, minHeight: 44)
                            .contentShape(Rectangle())
                    }
                    .accessibilityLabel("منشور جديد")
                }
            }
            .sheet(isPresented: $showCityPicker) {
                cityPickerSheet
            }
            .sheet(isPresented: $showCompose) {
                ComposeView()
            }
            .navigationDestination(isPresented: $showDetail) {
                if let post = selectedPost {
                    PostDetailView(post: post)
                }
            }
        }
    }

    // MARK: - زر المدينة (تصفّح — لا تزييف موقع)

    private var cityButton: some View {
        Button {
            jodelHaptic(.light)
            showCityPicker = true
        } label: {
            HStack(spacing: 4) {
                Image(systemName: "mappin.circle.fill")
                    .foregroundColor(JodelZeroPalette.forest)
                Text(store.currentCity.name)
                    .font(.custom("Gotham-Bold", size: 16))
                    .foregroundColor(Color(.label))
                    .lineLimit(1)
                Image(systemName: "chevron.down")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(.secondary)
            }
            .frame(minHeight: 44)
            .contentShape(Rectangle())
        }
        .accessibilityLabel("المدينة الحالية: \(store.currentCity.name) — تصفح مدن أخرى")
    }

    // MARK: - منتقي الفرز (الأحدث / الأعلى / الأكثر تعليقاً)

    private var sortPicker: some View {
        Picker("الفرز", selection: $store.feedSort) {
            Text("الأحدث").tag(FeedSort.newest)
            Text("الأعلى").tag(FeedSort.top)
            Text("الأكثر تعليقاً").tag(FeedSort.commented)
        }
        .pickerStyle(.segmented)
        .font(.custom("Gotham-Medium", size: 15))
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(Color(.systemBackground))
    }

    // MARK: - شريط نتائج البحث بالوسم

    @ViewBuilder
    private var searchBanner: some View {
        if !store.searchText.isEmpty {
            HStack {
                Label("نتائج عن \(store.searchText)", systemImage: "magnifyingglass")
                    .font(.custom("Gotham-Medium", size: 14))
                    .foregroundColor(JodelZeroPalette.forest)
                    .lineLimit(1)
                Spacer()
                Button("مسح") {
                    store.searchText = ""
                }
                .font(.custom("Gotham-Bold", size: 14))
                .foregroundColor(JodelZeroPalette.forest)
                .frame(minHeight: 44)
            }
            .padding(.horizontal)
            .background(JodelZeroPalette.forest.opacity(0.08))
        }
    }

    // MARK: - المحتوى: تحميل / فارغ / قائمة

    @ViewBuilder
    private var content: some View {
        if store.isLoading && allPosts.isEmpty {
            loadingState
        } else if allPosts.isEmpty {
            emptyState
        } else {
            postList
        }
    }

    private var loadingState: some View {
        VStack(spacing: 12) {
            ProgressView()
                .progressViewStyle(.circular)
            Text("جارٍ تحميل المنشورات…")
                .font(.custom("Gotham-Book", size: 15))
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var emptyState: some View {
        ScrollView {
            VStack(spacing: 16) {
                Image(systemName: "bubble.left.and.bubble.right.fill")
                    .font(.system(size: 52))
                    .foregroundColor(JodelZeroPalette.forest.opacity(0.6))
                    .padding(.top, 60)
                Text("لا توجد منشورات حولك بعد")
                    .font(.custom("Gotham-Bold", size: 19))
                    .foregroundColor(Color(.label))
                Text("اضغط على \"+\" لتكون الأول!")
                    .font(.custom("Gotham-Book", size: 16))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                Button("اكتب أول منشور") {
                    showCompose = true
                }
                .font(.custom("Gotham-Bold", size: 16))
                .foregroundColor(.white)
                .frame(minHeight: 44)
                .padding(.horizontal, 24)
                .background(JodelZeroPalette.forest)
                .cornerRadius(12)
            }
            .frame(maxWidth: .infinity)
            .padding(.horizontal)
        }
        .refreshable {
            store.refresh()
        }
    }

    private var postList: some View {
        List {
            // قسم المنشورات المعزَّزة أولاً عند وجودها
            if !boostedPosts.isEmpty {
                Section {
                    ForEach(boostedPosts) { post in
                        postRow(post)
                    }
                } header: {
                    boostedSectionHeader
                }
            }

            Section {
                ForEach(regularPosts) { post in
                    postRow(post)
                }
            } header: {
                if !boostedPosts.isEmpty {
                    Text("الصفحة الرئيسيّة")
                        .font(.custom("Gotham-Bold", size: 14))
                        .foregroundColor(.secondary)
                }
            }
        }
        .listStyle(.plain)
        .refreshable {
            store.refresh()
        }
    }

    private var boostedSectionHeader: some View {
        HStack(spacing: 6) {
            Image(systemName: "rocket.fill")
                .foregroundColor(JodelZeroPalette.karmaGold)
            Text("مشاركات معزّزة")
                .font(.custom("Gotham-Bold", size: 14))
                .foregroundColor(JodelZeroPalette.karmaGold)
        }
    }

    private func postRow(_ post: Post) -> some View {
        PostCardView(
            post: post,
            onReplyTap: {
                selectedPost = post
                showDetail = true
            },
            onHashtagTap: { tag in
                store.searchText = "#\(tag)"
            }
        )
        .listRowSeparator(.hidden)
        .listRowBackground(Color.clear)
        .listRowInsets(EdgeInsets(top: 6, leading: 12, bottom: 6, trailing: 12))
    }

    // MARK: - ورقة منتقي المدن (تصفح شفاف — موقعك الحقيقي لا يتغير)

    /// المدن القابلة للتصفح: عند إيقاف «تزييف الموقع» تقتصر على مدينتك فقط (#15).
    private var browsableCities: [City] {
        store.zero.locationSpoof ? store.cities : store.cities.filter { $0.isHometown }
    }

    private var cityPickerSheet: some View {
        NavigationStack {
            List {
                Section {
                    Text(store.zero.locationSpoof
                         ? "اختر مدينة لتصفح منشوراتها. هذا تصفّح فقط — موقعك الحقيقي لا يتغير، ولا يتم تزييف موقعك."
                         : "«تزييف الموقع» متوقف في إعدادات Zero — الخلاصة تعرض مدينتك فقط. فعّله من الإعدادات لتصفح مدن أخرى.")
                        .font(.custom("Gotham-Book", size: 14))
                        .foregroundColor(.secondary)
                }

                Section("المدن") {
                    ForEach(browsableCities) { city in
                        Button {
                            jodelHaptic(.light)
                            store.currentCity = city
                            showCityPicker = false
                        } label: {
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(city.name)
                                        .font(.custom("Gotham-Bold", size: 16))
                                        .foregroundColor(Color(.label))
                                    Text(city.nameEn)
                                        .font(.custom("Gotham-Book", size: 13))
                                        .foregroundColor(.secondary)
                                }
                                Spacer()
                                if city.isHometown {
                                    Label("المنشأ", systemImage: "house.fill")
                                        .font(.custom("Gotham-Medium", size: 12))
                                        .foregroundColor(JodelZeroPalette.forest)
                                }
                                if city.id == store.currentCity.id {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundColor(JodelZeroPalette.forest)
                                }
                            }
                            .frame(minHeight: 44)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .navigationTitle("تصفح مدينة أخرى")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("إغلاق") {
                        showCityPicker = false
                    }
                    .frame(minHeight: 44)
                }
            }
        }
    }
}
