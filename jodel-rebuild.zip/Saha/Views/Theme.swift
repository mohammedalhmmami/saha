// Jodel Zero — Theme.swift
// نظام التصميم فقط: الألوان والخطوط والبطاقات والأزرار.
// ملاحظة: لوحة الألوان الأساسية `JodelZeroPalette` معرّفة مرة واحدة في
// PostCardView.swift — هذا الملف يستخدمها ولا يعيد تعريفها.
// SwiftUI فقط، iOS 16+، بلا اعتماديات خارجية.

import SwiftUI

// MARK: - نظام التصميم (يستخدم JodelZeroPalette من PostCardView.swift)

enum JodelZeroTheme {
    /// خلفية التطبيق (تتبع الوضع الفاتح/الداكن عبر ألوان النظام).
    static var background: Color { Color(.systemGroupedBackground) }
    /// خلفية البطاقة.
    static var card: Color { Color(.systemBackground) }
    /// النص الأساسي.
    static var text: Color { Color(.label) }
    /// النص الثانوي.
    static var secondary: Color { Color(.secondaryLabel) }
    /// لون Jodel Zero الرئيسي — أخضر الغابة #1E7A4C.
    static var accent: Color { JodelZeroPalette.forest }
    /// ذهبي الكارما #E8A33D.
    static var gold: Color { JodelZeroPalette.karmaGold }
    /// خلفية فاتحة #F6F7F2 (للوضع الفاتح؛ الوضع الداكن يستخدم ألوان النظام).
    static var lightBackground: Color { JodelZeroPalette.lightBackground }

    /// أسماء ألوان المنشورات الثمانية (مكافآت الكارما — مفتوحة كلها مجاناً).
    /// التحويل إلى لون فعلي يتم عبر `jodelPostColor(named:)` في PostCardView.swift.
    static let postColorNames: [String] = [
        "green", "blue", "purple", "orange", "pink", "teal", "gold", "red"
    ]

    /// الأسماء العربية لألوان المنشورات، بنفس ترتيب `postColorNames`.
    static let postColorArabicNames: [String] = [
        "أخضر", "أزرق", "بنفسجي", "برتقالي", "وردي", "تركوازي", "ذهبي", "أحمر"
    ]

    /// لون منشور من اسمه المخزّن.
    static func postColor(named name: String) -> Color {
        jodelPostColor(named: name)
    }

    // MARK: الخطوط (Gotham المسجّلة في Info.plist — ترجع لخط النظام إن غابت)
    //
    // الخطوط المخصصة (#14): يضبطها AppStore.applyFontChoice() من
    // ZeroSettings.fontChoice. القيم nil = Gotham الافتراضي؛ وuseSystemFont
    // يعني خط النظام كاملاً.

    /// اسم الخط العريض المختار (nil = Gotham-Bold الافتراضي).
    static var customBoldFontName: String? = nil
    /// اسم الخط العادي المختار (nil = Gotham-Book الافتراضي).
    static var customBookFontName: String? = nil
    /// اسم الخط المتوسط المختار (nil = Gotham-Medium الافتراضي).
    static var customMediumFontName: String? = nil
    /// true = استخدام خط النظام بدل أي خط مخصص.
    static var useSystemFont: Bool = false

    /// خط العناوين العريض.
    static func titleFont(size: CGFloat) -> Font {
        if useSystemFont { return .system(size: size, weight: .bold) }
        return .custom(customBoldFontName ?? "Gotham-Bold", size: size)
    }

    /// خط النص العادي.
    static func bodyFont(size: CGFloat) -> Font {
        if useSystemFont { return .system(size: size) }
        return .custom(customBookFontName ?? "Gotham-Book", size: size)
    }

    /// خط متوسط الثقل (أزرار/وسوم).
    static func mediumFont(size: CGFloat) -> Font {
        if useSystemFont { return .system(size: size, weight: .medium) }
        return .custom(customMediumFontName ?? "Gotham-Medium", size: size)
    }

    /// خط الشعار المزخرف (Monoton — للشعارات والبطاقات).
    static func displayFont(size: CGFloat) -> Font {
        .custom("Monoton-Regular", size: size)
    }

    /// خط العرض الثاني (Titan One — للشعارات والبطاقات).
    static func headlineDisplayFont(size: CGFloat) -> Font {
        .custom("TitanOne-Regular", size: size)
    }

    /// خط العرض الثالث (TradeWinds — للشعارات والبطاقات).
    static func accentDisplayFont(size: CGFloat) -> Font {
        .custom("TradeWinds-Regular", size: size)
    }
}

// MARK: - معامل مشترك: بطاقة

/// بطاقة Jodel Zero القياسية: زوايا 16، ظل خفيف، مسافة 12 (المواصفة §4).
struct JodelZeroCardModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(12)
            .background(JodelZeroTheme.card)
            .cornerRadius(16)
            .shadow(color: Color.black.opacity(0.06), radius: 6, x: 0, y: 2)
    }
}

extension View {
    /// يطبّق بطاقة Jodel Zero القياسية على الشاشة.
    func jodelCard() -> some View {
        modifier(JodelZeroCardModifier())
    }
}

// MARK: - نمط مشترك: الزر الأساسي

/// زر Jodel Zero الأساسي: خلفية خضراء، نص أبيض، ارتفاع لمس 44pt كحد أدنى.
struct JodelZeroPrimaryButtonStyle: ButtonStyle {
    var isEnabled: Bool = true

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(JodelZeroTheme.titleFont(size: 16))
            .foregroundColor(.white)
            .frame(maxWidth: .infinity, minHeight: 44)
            .padding(.horizontal, 16)
            .background(isEnabled ? JodelZeroTheme.accent : JodelZeroTheme.accent.opacity(0.4))
            .cornerRadius(12)
            .opacity(configuration.isPressed ? 0.85 : 1.0)
    }
}

extension View {
    /// يطبّق زر Jodel Zero الأساسي على زر.
    func jodelPrimaryButton(isEnabled: Bool = true) -> some View {
        buttonStyle(JodelZeroPrimaryButtonStyle(isEnabled: isEnabled))
    }
}

// MARK: - معامل مشترك: زر ثانوي (حدّ أخضر)

/// زر ثانوي: حدّ بلون Jodel Zero ونص أخضر، ارتفاع لمس 44pt كحد أدنى.
struct JodelZeroSecondaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(JodelZeroTheme.mediumFont(size: 16))
            .foregroundColor(JodelZeroTheme.accent)
            .frame(maxWidth: .infinity, minHeight: 44)
            .padding(.horizontal, 16)
            .background(JodelZeroTheme.accent.opacity(0.10))
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(JodelZeroTheme.accent.opacity(0.4), lineWidth: 1)
            )
            .opacity(configuration.isPressed ? 0.85 : 1.0)
    }
}

extension View {
    /// يطبّق زر Jodel Zero الثانوي على زر.
    func jodelSecondaryButton() -> some View {
        buttonStyle(JodelZeroSecondaryButtonStyle())
    }
}
