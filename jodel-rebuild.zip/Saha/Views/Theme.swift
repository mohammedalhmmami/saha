// ساحة (Saha) — Theme.swift
// نظام التصميم فقط: الألوان والخطوط والبطاقات والأزرار.
// ملاحظة: لوحة الألوان الأساسية `SahaPalette` معرّفة مرة واحدة في
// PostCardView.swift — هذا الملف يستخدمها ولا يعيد تعريفها.
// SwiftUI فقط، iOS 16+، بلا اعتماديات خارجية.

import SwiftUI

// MARK: - نظام التصميم (يستخدم SahaPalette من PostCardView.swift)

enum SahaTheme {
    /// خلفية التطبيق (تتبع الوضع الفاتح/الداكن عبر ألوان النظام).
    static var background: Color { Color(.systemGroupedBackground) }
    /// خلفية البطاقة.
    static var card: Color { Color(.systemBackground) }
    /// النص الأساسي.
    static var text: Color { Color(.label) }
    /// النص الثانوي.
    static var secondary: Color { Color(.secondaryLabel) }
    /// لون الساحة الرئيسي — أخضر الغابة #1E7A4C.
    static var accent: Color { SahaPalette.forest }
    /// ذهبي الكارما #E8A33D.
    static var gold: Color { SahaPalette.karmaGold }
    /// خلفية فاتحة #F6F7F2 (للوضع الفاتح؛ الوضع الداكن يستخدم ألوان النظام).
    static var lightBackground: Color { SahaPalette.lightBackground }

    /// أسماء ألوان المنشورات الثمانية (مكافآت الكارما — مفتوحة كلها مجاناً).
    /// التحويل إلى لون فعلي يتم عبر `sahaPostColor(named:)` في PostCardView.swift.
    static let postColorNames: [String] = [
        "green", "blue", "purple", "orange", "pink", "teal", "gold", "red"
    ]

    /// الأسماء العربية لألوان المنشورات، بنفس ترتيب `postColorNames`.
    static let postColorArabicNames: [String] = [
        "أخضر", "أزرق", "بنفسجي", "برتقالي", "وردي", "تركوازي", "ذهبي", "أحمر"
    ]

    /// لون منشور من اسمه المخزّن.
    static func postColor(named name: String) -> Color {
        sahaPostColor(named: name)
    }

    // MARK: الخطوط (Gotham المسجّلة في Info.plist — ترجع لخط النظام إن غابت)

    /// خط العناوين العريض.
    static func titleFont(size: CGFloat) -> Font {
        .custom("Gotham-Bold", size: size)
    }

    /// خط النص العادي.
    static func bodyFont(size: CGFloat) -> Font {
        .custom("Gotham-Book", size: size)
    }

    /// خط متوسط الثقل (أزرار/وسوم).
    static func mediumFont(size: CGFloat) -> Font {
        .custom("Gotham-Medium", size: size)
    }

    /// خط الشعار المزخرف (Monoton — للشعارات والبطاقات).
    static func displayFont(size: CGFloat) -> Font {
        .custom("Monoton-Regular", size: size)
    }

    /// خط العرض الثاني (Titan One — للشعارات والبطاقات).
    static func headlineDisplayFont(size: CGFloat) -> Font {
        .custom("TitanOne-Regular", size: size)
    }

    /// خط العرض الثالث (TradeWinds — للشعارات والبطاقات).
    static func accentDisplayFont(size: CGFloat) -> Font {
        .custom("TradeWinds-Regular", size: size)
    }
}

// MARK: - معامل مشترك: بطاقة

/// بطاقة ساحة القياسية: زوايا 16، ظل خفيف، مسافة 12 (المواصفة §4).
struct SahaCardModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(12)
            .background(SahaTheme.card)
            .cornerRadius(16)
            .shadow(color: Color.black.opacity(0.06), radius: 6, x: 0, y: 2)
    }
}

extension View {
    /// يطبّق بطاقة ساحة القياسية على الشاشة.
    func sahaCard() -> some View {
        modifier(SahaCardModifier())
    }
}

// MARK: - نمط مشترك: الزر الأساسي

/// زر ساحة الأساسي: خلفية خضراء، نص أبيض، ارتفاع لمس 44pt كحد أدنى.
struct SahaPrimaryButtonStyle: ButtonStyle {
    var isEnabled: Bool = true

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(SahaTheme.titleFont(size: 16))
            .foregroundColor(.white)
            .frame(maxWidth: .infinity, minHeight: 44)
            .padding(.horizontal, 16)
            .background(isEnabled ? SahaTheme.accent : SahaTheme.accent.opacity(0.4))
            .cornerRadius(12)
            .opacity(configuration.isPressed ? 0.85 : 1.0)
    }
}

extension View {
    /// يطبّق زر ساحة الأساسي على زر.
    func sahaPrimaryButton(isEnabled: Bool = true) -> some View {
        buttonStyle(SahaPrimaryButtonStyle(isEnabled: isEnabled))
    }
}

// MARK: - معامل مشترك: زر ثانوي (حدّ أخضر)

/// زر ثانوي: حدّ بلون الساحة ونص أخضر، ارتفاع لمس 44pt كحد أدنى.
struct SahaSecondaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(SahaTheme.mediumFont(size: 16))
            .foregroundColor(SahaTheme.accent)
            .frame(maxWidth: .infinity, minHeight: 44)
            .padding(.horizontal, 16)
            .background(SahaTheme.accent.opacity(0.10))
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(SahaTheme.accent.opacity(0.4), lineWidth: 1)
            )
            .opacity(configuration.isPressed ? 0.85 : 1.0)
    }
}

extension View {
    /// يطبّق زر ساحة الثانوي على زر.
    func sahaSecondaryButton() -> some View {
        buttonStyle(SahaSecondaryButtonStyle())
    }
}
