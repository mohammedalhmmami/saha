import SwiftUI

/// بطاقة استطلاع: سؤال وخيارات قابلة للتصويت مع أشرطة نسب متحركة وعدّاد تنازلي 24 ساعة.
/// النصوص العربية من `ar.lproj/Localizable.strings` حرفياً:
/// `polls_taptovote_button` = «انقر للتصويت»، `polls_seeresults_button` = «اطلع على النتائج»،
/// `polls_duration_description` = «الإستبيان متاح لمدة 24 ساعة»،
/// `polls_rejected_main` = «لا يمكن مشاركة هذا الإستبيان في @الرئيسية».
/// الاستطلاعات لا تُنشر في الخلاصة الرئيسية — تظهر فقط داخل المنشورات والقنوات.
struct PollView: View {
    let post: Post

    @EnvironmentObject private var store: AppStore
    @State private var showResults = false

    /// المنشور الحي من المتجر حتى تنعكس نتيجة التصويت فوراً بعد `votePoll`.
    private var livePost: Post {
        store.posts.first(where: { $0.id == post.id }) ?? post
    }

    private var poll: Poll? { livePost.poll }

    /// تُعرض النتائج بعد التصويت، أو عند طلبها صراحةً بزر «اطلع على النتائج».
    private var resultsVisible: Bool {
        guard let poll else { return false }
        return poll.myChoice != nil || showResults
    }

    var body: some View {
        if let poll {
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .top) {
                    Image(systemName: "chart.bar.fill")
                        .foregroundStyle(jodelGreen)
                        .accessibilityHidden(true)
                    Text(poll.question)
                        .font(.custom("Gotham-Bold", size: 17, relativeTo: .headline))
                        .multilineTextAlignment(.leading)
                    Spacer()
                    countdownText(endsAt: poll.endsAt)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.trailing)
                }

                ForEach(poll.options) { option in
                    PollOptionRow(
                        option: option,
                        totalVotes: poll.totalVotes,
                        isChosen: poll.myChoice == option.id,
                        resultsVisible: resultsVisible,
                        isExpired: poll.endsAt <= Date()
                    ) {
                        guard poll.myChoice == nil, poll.endsAt > Date() else { return }
                        withAnimation(.easeInOut(duration: 0.35)) {
                            store.votePoll(livePost, optionId: option.id)
                        }
                    }
                }

                HStack {
                    if poll.myChoice == nil && !showResults {
                        Button("اطلع على النتائج") { showResults = true }
                            .buttonStyle(.bordered)
                    } else if poll.myChoice == nil {
                        Button("انقر للتصويت") { showResults = false }
                            .buttonStyle(.bordered)
                    } else {
                        Label("انقر للتصويت", systemImage: "checkmark.circle.fill")
                            .font(.caption)
                            .foregroundStyle(jodelGreen)
                    }
                    Spacer()
                    Text("الإستبيان متاح لمدة 24 ساعة")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text("• \(poll.totalVotes) صوت")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Text("لا يمكن مشاركة هذا الإستبيان في @الرئيسية")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            .padding()
            .background(Color(.secondarySystemBackground))
            .clipShape(RoundedRectangle(cornerRadius: 16))
        }
    }

    private var jodelGreen: Color {
        Color(red: 0x1E / 255, green: 0x7A / 255, blue: 0x4C / 255)
    }

    /// عدّاد تنازلي حي حتى `endsAt` (24 ساعة من إنشاء الاستطلاع).
    @ViewBuilder
    private func countdownText(endsAt: Date) -> some View {
        TimelineView(.periodic(from: .now, by: 1)) { context in
            Text(remainingText(endsAt: endsAt, now: context.date))
        }
    }

    private func remainingText(endsAt: Date, now: Date) -> String {
        let remaining = endsAt.timeIntervalSince(now)
        guard remaining > 0 else { return "انتهى الاستطلاع" }
        let totalSeconds = Int(remaining)
        let hours = totalSeconds / 3600
        let minutes = (totalSeconds % 3600) / 60
        let seconds = totalSeconds % 60
        if hours > 0 {
            return String(format: "%02d:%02d:%02d", hours, minutes, seconds)
        }
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

/// صف خيار واحد في الاستطلاع: شريط نسبة متحرك يملأ عرض الصف بنسبة الأصوات.
private struct PollOptionRow: View {
    let option: PollOption
    let totalVotes: Int
    let isChosen: Bool
    let resultsVisible: Bool
    let isExpired: Bool
    let onTap: () -> Void

    private var fraction: Double {
        guard totalVotes > 0 else { return 0 }
        return Double(option.votes) / Double(totalVotes)
    }

    private var percentText: String {
        guard totalVotes > 0 else { return "0%" }
        return "\(Int((fraction * 100).rounded()))%"
    }

    var body: some View {
        Button(action: onTap) {
            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color(.tertiarySystemBackground))
                    if resultsVisible {
                        RoundedRectangle(cornerRadius: 10)
                            .fill(barColor.opacity(0.35))
                            .frame(width: geometry.size.width * fraction)
                            .animation(.easeInOut(duration: 0.4), value: fraction)
                    }
                    HStack {
                        if isChosen {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(barColor)
                        } else if !resultsVisible {
                            Image(systemName: "circle")
                                .foregroundStyle(.secondary)
                        }
                        Text(option.text)
                            .font(.subheadline)
                            .foregroundStyle(Color.primary)
                            .multilineTextAlignment(.leading)
                        Spacer()
                        if resultsVisible {
                            Text(percentText)
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(Color.primary)
                            Text("\(option.votes)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.horizontal)
                }
            }
            .frame(minHeight: 44)
        }
        .buttonStyle(.plain)
        .disabled(isExpired)
        .opacity(isExpired && !resultsVisible ? 0.6 : 1)
        .accessibilityLabel("\(option.text)، \(percentText)")
    }

    private var barColor: Color {
        Color(red: 0x1E / 255, green: 0x7A / 255, blue: 0x4C / 255)
    }
}
