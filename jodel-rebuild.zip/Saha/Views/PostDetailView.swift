// ساحة — PostDetailView
// تفاصيل المنشور: البطاقة الكاملة، الاستطلاع، قائمة الردود مع التصويت،
// ومؤلف رد في الأسفل. سحب للتحديث.
// SwiftUI + Foundation فقط، iOS 16+، بلا اعتماديات خارجية.

import SwiftUI

struct PostDetailView: View {
    @EnvironmentObject private var store: AppStore

    let post: Post

    @State private var replyText = ""
    @State private var replyVoteScale: [UUID: CGFloat] = [:]

    /// المنشور الحي من المتجر (يعكس التصويت والردود فوراً).
    private var livePost: Post {
        store.posts.first(where: { $0.id == post.id }) ?? post
    }

    private var replies: [Reply] {
        store.replies[livePost.id] ?? []
    }

    private var trimmedReply: String {
        replyText.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 16) {
                PostCardView(post: livePost, isDetail: true)

                if livePost.poll != nil {
                    pollSection
                }

                repliesHeader

                if replies.isEmpty {
                    emptyReplies
                } else {
                    ForEach(replies) { reply in
                        ReplyRow(
                            reply: reply,
                            voteScale: replyVoteScale[reply.id] ?? 1.0,
                            onVote: { isUp in castReplyVote(reply, isUp: isUp) }
                        )
                    }
                }
            }
            .padding()
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("المنشور")
        .navigationBarTitleDisplayMode(.inline)
        .refreshable {
            store.refresh()
        }
        .safeAreaInset(edge: .bottom) {
            replyComposer
        }
    }

    // MARK: - الاستطلاع الكامل

    private var pollSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("استطلاع", systemImage: "chart.bar.fill")
                .font(.custom("Gotham-Bold", size: 15))
                .foregroundColor(SahaPalette.forest)
            PollView(post: livePost)
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(16)
        .shadow(color: Color.black.opacity(0.06), radius: 6, x: 0, y: 2)
    }

    // MARK: - رأس الردود

    private var repliesHeader: some View {
        HStack {
            Text("الردود")
                .font(.custom("Gotham-Bold", size: 18))
                .foregroundColor(Color(.label))
            Text("(\(livePost.replyCount))")
                .font(.custom("Gotham-Book", size: 15))
                .foregroundColor(.secondary)
            Spacer()
        }
    }

    private var emptyReplies: some View {
        VStack(spacing: 8) {
            Image(systemName: "bubble.left.and.bubble.right")
                .font(.system(size: 32))
                .foregroundColor(.secondary)
            Text("لا توجد ردود بعد — كن أول من يرد!")
                .font(.custom("Gotham-Book", size: 15))
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 24)
    }

    // MARK: - مؤلف الرد

    private var replyComposer: some View {
        HStack(spacing: 8) {
            TextField("رد بأسلوب الجار الطيب", text: $replyText, axis: .vertical)
                .font(.custom("Gotham-Book", size: 16))
                .lineLimit(1...4)
                .frame(minHeight: 44)
                .padding(.horizontal, 12)
                .background(Color(.secondarySystemBackground))
                .cornerRadius(22)
                .onSubmit { sendReply() }

            Button {
                sendReply()
            } label: {
                Image(systemName: "paperplane.fill")
                    .font(.system(size: 17))
                    .foregroundColor(.white)
                    .frame(minWidth: 44, minHeight: 44)
                    .background(trimmedReply.isEmpty ? Color.secondary : SahaPalette.forest)
                    .clipShape(Circle())
            }
            .disabled(trimmedReply.isEmpty)
            .accessibilityLabel("إرسال الرد")
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(Color(.systemBackground))
        .overlay(alignment: .top) {
            Divider()
        }
    }

    private func sendReply() {
        guard !trimmedReply.isEmpty else { return }
        store.addReply(to: livePost, text: trimmedReply)
        sahaHaptic(.medium)
        replyText = ""
    }

    // MARK: - التصويت على الردود

    private func castReplyVote(_ reply: Reply, isUp: Bool) {
        let target: Vote
        if isUp {
            target = reply.myVote == .up ? .none : .up
        } else {
            target = reply.myVote == .down ? .none : .down
        }
        sahaHaptic(target == .none ? .light : .medium)
        withAnimation(.spring(response: 0.25, dampingFraction: 0.5)) {
            replyVoteScale[reply.id] = 1.3
        }
        store.voteReply(reply, target)
        withAnimation(.spring(response: 0.35, dampingFraction: 0.6).delay(0.08)) {
            replyVoteScale[reply.id] = 1.0
        }
    }
}

// MARK: - صف الرد

private struct ReplyRow: View {
    let reply: Reply
    let voteScale: CGFloat
    let onVote: (Bool) -> Void

    private var score: Int { reply.upvotes - reply.downvotes }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                Image(systemName: "person.circle.fill")
                    .foregroundColor(SahaPalette.forest)
                Text(reply.authorTag)
                    .font(.custom("Gotham-Bold", size: 14))
                    .foregroundColor(Color(.label))
                    .lineLimit(1)
                Text("•")
                    .foregroundColor(.secondary)
                Text(sahaTimeAgo(from: reply.createdAt))
                    .font(.custom("Gotham-Book", size: 13))
                    .foregroundColor(.secondary)
                Spacer()
            }

            Text(reply.text)
                .font(.custom("Gotham-Book", size: 15))
                .foregroundColor(Color(.label))
                .frame(maxWidth: .infinity, alignment: .leading)
                .fixedSize(horizontal: false, vertical: true)

            HStack(spacing: 4) {
                Button {
                    onVote(true)
                } label: {
                    HStack(spacing: 4) {
                        Image(systemName: "arrow.up.circle.fill")
                            .font(.system(size: 20))
                        Text("\(reply.upvotes)")
                            .font(.custom("Gotham-Bold", size: 14))
                    }
                    .foregroundColor(reply.myVote == .up ? SahaPalette.upvote : .secondary)
                    .frame(minWidth: 44, minHeight: 44)
                    .contentShape(Rectangle())
                    .scaleEffect(reply.myVote == .up ? voteScale : 1.0)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("تصويت إيجابي على الرد — \(reply.upvotes)")

                Text("\(score)")
                    .font(.custom("Gotham-Bold", size: 14))
                    .foregroundColor(score > 0 ? SahaPalette.upvote : (score < 0 ? SahaPalette.downvote : .secondary))
                    .frame(minWidth: 28)

                Button {
                    onVote(false)
                } label: {
                    HStack(spacing: 4) {
                        Image(systemName: "arrow.down.circle.fill")
                            .font(.system(size: 20))
                        Text("\(reply.downvotes)")
                            .font(.custom("Gotham-Bold", size: 14))
                    }
                    .foregroundColor(reply.myVote == .down ? SahaPalette.downvote : .secondary)
                    .frame(minWidth: 44, minHeight: 44)
                    .contentShape(Rectangle())
                    .scaleEffect(reply.myVote == .down ? voteScale : 1.0)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("تصويت سلبي على الرد — \(reply.downvotes)")

                Spacer()
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(16)
        .shadow(color: Color.black.opacity(0.05), radius: 4, x: 0, y: 1)
    }
}
