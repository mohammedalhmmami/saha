// Jodel Zero — OnboardingView (#38 — صفحات التعريف)
// خمس صفحات تعريف عند أول تشغيل فقط: ترحيب، الفيد، النشر والتصويت،
// القنوات والمحادثات، جاهز للانطلاق. بُنيت من الصفر في SwiftUI
// (TabView بأسلوب صفحات) — لا نسخ كود، لا حقن إطار، لا كود تفعيل.
// علامة المشاهدة تُحفظ في UserDefaults ولا تُعرض الصفحات بعدها أبداً.

import SwiftUI

/// صفحة تعريف واحدة: أيقونة + عنوان + نص + شارة اختيارية.
private struct OnboardingPage: Identifiable {
    let id: Int
    let icon: String
    let title: String
    let body: String
    let badge: String?
}

struct OnboardingView: View {
    /// علامة انتهاء التعريف — تُحفظ في UserDefaults؛ عند true لا تُعرض الصفحات أبداً.
    @AppStorage("com.nebra.jodelzero.hasSeenOnboarding") private var hasSeenOnboarding = false

    @State private var page = 0

    private let pages: [OnboardingPage] = [
        OnboardingPage(
            id: 0,
            icon: "hand.wave.fill",
            title: "مرحباً بك في Jodel Zero",
            body: "أكثر من 41 ميزة حصرية — كلها مجانية ومفتوحة. بلا كود تفعيل، بلا دخول، بلا اشتراك.",
            badge: "جديد"
        ),
        OnboardingPage(
            id: 1,
            icon: "house.fill",
            title: "الفيد من حولك",
            body: "تصفّح منشورات مدينتك وجيرانك، ورتّبها بالأحدث أو الأكثر نقاشاً أو الأعلى تقييماً.",
            badge: nil
        ),
        OnboardingPage(
            id: 2,
            icon: "arrow.up.circle.fill",
            title: "انشر وصوّت واكسب كارما",
            body: "أنشئ منشوراً من زر +، وصوّت لمنشورات جيرانك، واكسب كارما وارتقِ بالمستويات.",
            badge: nil
        ),
        OnboardingPage(
            id: 3,
            icon: "message.fill",
            title: "قنوات ومحادثات",
            body: "انضم لقنوات مدينتك واهتماماتك، وراسل جيرانك في محادثات خاصة بموافقة متبادلة.",
            badge: nil
        ),
        OnboardingPage(
            id: 4,
            icon: "rocket.fill",
            title: "جاهز للانطلاق!",
            body: "كل شيء مفتوح أمامك. ابدأ أول منشور لك وشارك ما يدور حولك.",
            badge: nil
        ),
    ]

    private var isLastPage: Bool { page >= pages.count - 1 }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Spacer()
                Button("تخطي") { finishOnboarding() }
                    .font(.custom("Gotham-Bold", size: 15))
                    .foregroundColor(JodelZeroPalette.forest)
                    .frame(minWidth: 44, minHeight: 44)
            }
            .padding(.horizontal, 16)

            TabView(selection: $page) {
                ForEach(pages) { item in
                    VStack(spacing: 20) {
                        Spacer()
                        Image(systemName: item.icon)
                            .font(.system(size: 72))
                            .foregroundColor(JodelZeroPalette.forest)
                        if let badge = item.badge {
                            Text(badge)
                                .font(.custom("Gotham-Bold", size: 12))
                                .foregroundColor(.white)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 4)
                                .background(JodelZeroPalette.karmaGold)
                                .cornerRadius(10)
                        }
                        Text(item.title)
                            .font(.custom("Gotham-Bold", size: 26, relativeTo: .title))
                            .multilineTextAlignment(.center)
                        Text(item.body)
                            .font(.custom("Gotham-Book", size: 17))
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 32)
                        Spacer()
                    }
                    .tag(item.id)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .automatic))

            Button(isLastPage ? "ابدأ" : "التالي") {
                if isLastPage {
                    finishOnboarding()
                } else {
                    withAnimation { page += 1 }
                }
            }
            .font(.custom("Gotham-Bold", size: 17))
            .foregroundColor(.white)
            .frame(maxWidth: .infinity, minHeight: 52)
            .background(JodelZeroPalette.forest)
            .cornerRadius(14)
            .padding(.horizontal, 24)
            .padding(.bottom, 32)
        }
        .background(Color(.systemBackground))
    }

    /// يكتب علامة انتهاء التعريف في UserDefaults — بعدها لا تُعرض الصفحات أبداً.
    private func finishOnboarding() {
        hasSeenOnboarding = true
    }
}
