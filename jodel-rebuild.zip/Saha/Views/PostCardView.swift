// Jodel Zero — PostCardView
// بطاقة المنشور: التصويت، الكارما، الألوان، الوسوم، الاستطلاع، الإخفاء بالتصويت.
// SwiftUI + Foundation فقط، iOS 16+، بلا اعتماديات خارجية.

import SafariServices
import SwiftUI
import UIKit

// MARK: - لوحة ألوان Jodel Zero المشتركة (مواصفة ARCHITECTURE.md §4)

enum JodelZeroPalette {
    /// أخضر الغابة — اللون الرئيسي #1E7A4C
    static let forest = Color(red: 0.12, green: 0.48, blue: 0.30)
    /// ذهبي الكارما #E8A33D
    static let karmaGold = Color(red: 0.91, green: 0.64, blue: 0.24)
    /// خلفية فاتحة #F6F7F2 (تُستخدم فقط كخلفية فاتحة؛ الوضع الداكن يستخدم ألوان النظام)
    static let lightBackground = Color(red: 0.96, green: 0.97, blue: 0.95)
    /// نص داكن #1C1C1E
    static let darkText = Color(red: 0.11, green: 0.11, blue: 0.12)
    /// أخضر التصويت الإيجابي
    static let upvote = Color(red: 0.12, green: 0.48, blue: 0.30)
    /// أحمر التصويت السلبي
    static let downvote = Color(red: 0.85, green: 0.26, blue: 0.21)
}

// MARK: - لون المنشور من اسم لون الكارما (8 ألوان مجانية)

/// يحوّل اسم لون المنشور المخزّن في `Post.postColor` إلى لون فعلي.
/// يقبل الأسماء العربية والإنجليزية، ويعود للأخضر عند اسم غير معروف.
func jodelPostColor(named name: String) -> Color {
    switch name.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
    case "green", "أخضر", "اخضر":
        return Color(red: 0.12, green: 0.48, blue: 0.30)
    case "blue", "أزرق", "ازرق":
        return Color(red: 0.20, green: 0.45, blue: 0.85)
    case "purple", "بنفسجي":
        return Color(red: 0.55, green: 0.35, blue: 0.85)
    case "orange", "برتقالي":
        return Color(red: 0.95, green: 0.55, blue: 0.15)
    case "pink", "وردي":
        return Color(red: 0.90, green: 0.35, blue: 0.55)
    case "teal", "تركوازي", "فيروزي":
        return Color(red: 0.10, green: 0.65, blue: 0.65)
    case "gold", "ذهبي", "golden":
        return JodelZeroPalette.karmaGold
    case "red", "أحمر", "احمر":
        return Color(red: 0.85, green: 0.26, blue: 0.21)
    default:
        return JodelZeroPalette.forest
    }
}

// MARK: - وقت نسبي بالعربية

/// «منذ 5 دقائق»، «منذ ساعتين»، «أمس»، «منذ 3 أيام»… — بلا اعتماديات خارجية.
func jodelTimeAgo(from date: Date, now: Date = Date()) -> String {
    let seconds = max(0, Int(now.timeIntervalSince(date)))
    let minutes = seconds / 60
    let hours = minutes / 60
    let days = hours / 24
    if seconds < 60 { return "الآن" }
    if minutes < 60 {
        if minutes == 1 { return "منذ دقيقة" }
        if minutes == 2 { return "منذ دقيقتين" }
        if minutes <= 10 { return "منذ \(minutes) دقائق" }
        return "منذ \(minutes) دقيقة"
    }
    if hours < 24 {
        if hours == 1 { return "منذ ساعة" }
        if hours == 2 { return "منذ ساعتين" }
        if hours <= 10 { return "منذ \(hours) ساعات" }
        return "منذ \(hours) ساعة"
    }
    if days == 1 { return "أمس" }
    if days == 2 { return "منذ يومين" }
    if days <= 10 { return "منذ \(days) أيام" }
    if days < 30 { return "منذ \(days) يوماً" }
    let months = days / 30
    if months == 1 { return "منذ شهر" }
    if months == 2 { return "منذ شهرين" }
    return "منذ \(months) أشهر"
}

// MARK: - وسوم قابلة للنقر

/// نص المنشور كـ AttributedString مع تلوين الوسوم (#...) بلون Jodel Zero.
func jodelAttributedPostText(_ text: String) -> AttributedString {
    var result = AttributedString()
    let words = text.split(whereSeparator: { $0.isWhitespace })
    for (index, word) in words.enumerated() {
        var part = AttributedString(String(word))
        if word.hasPrefix("#") {
            part.foregroundColor = JodelZeroPalette.forest
            part.font = .custom("Gotham-Medium", size: 16)
        }
        result.append(part)
        if index < words.count - 1 {
            result.append(AttributedString(" "))
        }
    }
    return result
}

/// يستخرج الوسوم (#...) من نص منشور، بلا علامة #.
func jodelHashtags(in text: String) -> [String] {
    text.split(whereSeparator: { $0.isWhitespace })
        .filter { $0.hasPrefix("#") && $0.count > 1 }
        .map { String($0.dropFirst()) }
}

// MARK: - اهتزاز خفيف (Haptics)

func jodelHaptic(_ style: UIImpactFeedbackGenerator.FeedbackStyle = .light) {
    let generator = UIImpactFeedbackGenerator(style: style)
    generator.prepare()
    generator.impactOccurred()
}

// MARK: - انفجار جسيمات صغير عند التصويت الإيجابي (بديل SwiftUI أصلي لملف Lottie)

private struct VoteBurstView: View {
    @State private var animate = false

    var body: some View {
        ZStack {
            ForEach(0..<8, id: \.self) { index in
                Circle()
                    .fill(index % 2 == 0 ? JodelZeroPalette.karmaGold : JodelZeroPalette.forest)
                    .frame(width: 6, height: 6)
                    .offset(animate ? burstOffset(for: index) : .zero)
                    .opacity(animate ? 0 : 1)
            }
        }
        .allowsHitTesting(false)
        .onAppear {
            withAnimation(.easeOut(duration: 0.6)) {
                animate = true
            }
        }
    }

    private func burstOffset(for index: Int) -> CGSize {
        let angle = Double(index) * (Double.pi * 2.0 / 8.0)
        return CGSize(width: cos(angle) * 26, height: sin(angle) * 26)
    }
}

// MARK: - بطاقة المنشور

struct PostCardView: View {
    @EnvironmentObject private var store: AppStore

    let post: Post
    /// true عند العرض داخل PostDetailView (يُخفي زر الانتقال للردود).
    var isDetail: Bool = false
    /// يُستدعى عند الضغط على زر الردود (الانتقال للتفاصيل) — nil داخل التفاصيل.
    var onReplyTap: (() -> Void)? = nil
    /// يُستدعى عند الضغط على وسم — لتصفية الخلاصة به.
    var onHashtagTap: ((String) -> Void)? = nil

    @State private var showAnyway = false
    @State private var showReportConfirmation = false
    @State private var showBoostResult = false
    @State private var boostSucceeded = false
    @State private var burstID = 0
    @State private var voteScale: CGFloat = 1.0
    @State private var showExpandedMedia = false
    @State private var safariURL: URL?
    @State private var showCopiedConfirmation = false
    @State private var showSavedConfirmation = false
    @State private var showMediaURLCopied = false

    /// المنشور الحي من المتجر (يعكس التصويت فوراً)، أو النسخة الممرَّرة كاحتياطي.
    private var livePost: Post {
        store.posts.first(where: { $0.id == post.id }) ?? post
    }

    private var channelName: String? {
        guard let channelId = livePost.channelId else { return nil }
        return store.channels.first(where: { $0.id == channelId })?.name
    }

    private var isHiddenByVotes: Bool {
        livePost.score <= -5 && !showAnyway
    }

    var body: some View {
        if isHiddenByVotes {
            hiddenCard
        } else {
            fullCard
        }
    }

    // MARK: بطاقة «مُخفى بالتصويت» (المواصفة §2: يُخفى عند −5)

    private var hiddenCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                Image(systemName: "eye.slash.fill")
                    .foregroundColor(.secondary)
                Text("هذا المنشور مخفى بسبب التصويت السلبي")
                    .font(.custom("Gotham-Book", size: 15))
                    .foregroundColor(.secondary)
            }
            Text("وصلت نتيجة التصويت إلى \(livePost.score)")
                .font(.custom("Gotham-Book", size: 13))
                .foregroundColor(.secondary)
            Button("عرض على أي حال") {
                jodelHaptic(.light)
                withAnimation(.easeInOut(duration: 0.25)) {
                    showAnyway = true
                }
            }
            .font(.custom("Gotham-Bold", size: 15))
            .foregroundColor(JodelZeroPalette.forest)
            .frame(minHeight: 44)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color(.secondarySystemBackground))
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color(.separator), lineWidth: 1)
        )
    }

    // MARK: البطاقة الكاملة

    private var fullCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            headerRow

            // النص مع وسوم ملوّنة — الضغطة المطوّلة تنسخه (#4)
            Text(jodelAttributedPostText(livePost.text))
                .font(.custom("Gotham-Book", size: 16))
                .foregroundColor(Color(.label))
                .frame(maxWidth: .infinity, alignment: .leading)
                .fixedSize(horizontal: false, vertical: true)
                .onLongPressGesture {
                    copyPostText()
                }

            // رابط داخل النص — يُفتح في متصفح داخل التطبيق (#32)
            if let url = firstURL(in: livePost.text) {
                Button {
                    safariURL = url
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "link")
                        Text(url.absoluteString)
                            .lineLimit(1)
                    }
                    .font(.custom("Gotham-Book", size: 14))
                    .foregroundColor(JodelZeroPalette.forest)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .frame(minHeight: 44)
            }

            // الصورة: صورة حقيقية مرفقة (اضغط للتكبير #29) أو رمز توضيحي
            if let data = livePost.imageData, let uiImage = UIImage(data: data) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: .infinity)
                    .aspectRatio(16.0 / 9.0, contentMode: .fit)
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(16)
                    .onTapGesture { showExpandedMedia = true }
                    .accessibilityLabel("صورة المنشور — اضغط للتكبير")
            } else if let symbol = livePost.imageSymbol {
                Image(systemName: symbol)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: .infinity)
                    .aspectRatio(16.0 / 9.0, contentMode: .fit)
                    .foregroundColor(jodelPostColor(named: livePost.postColor))
                    .padding()
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(16)
                    .accessibilityLabel("صورة توضيحية")
            }

            // معاينة الاستطلاع المدمجة
            if livePost.poll != nil {
                PollView(post: livePost)
            }

            // وسوم قابلة للنقر
            let tags = jodelHashtags(in: livePost.text) + livePost.hashtags.filter { !$0.isEmpty }
            if !Set(tags).isEmpty {
                hashtagChips(tags: Array(Set(tags)).sorted())
            }

            Divider()

            footerRow
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(16)
        .shadow(color: Color.black.opacity(0.06), radius: 6, x: 0, y: 2)
        .overlay(alignment: .leading) {
            // شريط لون الكارما على الحافة
            RoundedRectangle(cornerRadius: 3)
                .fill(jodelPostColor(named: livePost.postColor))
                .frame(width: 5)
                .padding(.vertical, 12)
        }
        .alert("تم الإبلاغ عن المنشور", isPresented: $showReportConfirmation) {
            Button("حسناً", role: .cancel) { }
        } message: {
            Text("شكراً لك على الحفاظ على Jodel Zero آمناً.")
        }
        .alert(boostSucceeded ? "تم تعزيز المنشور" : "لا تتوفر تعزيزات", isPresented: $showBoostResult) {
            Button("حسناً", role: .cancel) { }
        } message: {
            Text(boostSucceeded
                 ? "سيشاهد المزيد من الأشخاص هذا المنشور ويتفاعلون معه أثناء التعزيز."
                 : "لا تملك رصيد تعزيز متبقٍّ. تُمنح التعزيزات مجاناً كل أسبوع.")
        }
        .alert("تم نسخ رابط الوسائط", isPresented: $showMediaURLCopied) {
            Button("حسناً", role: .cancel) { }
        } message: {
            Text("نُسخ رابط الوسائط إلى الحافظة.")
        }
        .alert("تم نسخ النص", isPresented: $showCopiedConfirmation) {
            Button("حسناً", role: .cancel) { }
        } message: {
            Text("نُسخ نص المنشور وسُجّل في سجل النسخ.")
        }
        .alert("تم حفظ الصورة", isPresented: $showSavedConfirmation) {
            Button("حسناً", role: .cancel) { }
        } message: {
            Text("حُفظت صورة المنشور في مكتبة صورك.")
        }
        .sheet(isPresented: $showExpandedMedia) {
            if let data = livePost.imageData, let uiImage = UIImage(data: data) {
                ExpandedMediaView(image: uiImage)
            }
        }
        .sheet(isPresented: Binding(
            get: { safariURL != nil },
            set: { if !$0 { safariURL = nil } }
        )) {
            if let url = safariURL {
                SafariView(url: url)
            }
        }
    }

    // MARK: صف الرأس

    private var headerRow: some View {
        HStack(spacing: 8) {
            // وسم الكاتب المجهول
            HStack(spacing: 6) {
                Image(systemName: "person.circle.fill")
                    .foregroundColor(jodelPostColor(named: livePost.postColor))
                Text(livePost.authorTag)
                    .font(.custom("Gotham-Bold", size: 14))
                    .foregroundColor(Color(.label))
                    .lineLimit(1)
            }

            // شارة «متابَع» (#31)
            if store.isFollowing(tag: livePost.authorTag) {
                Text("متابَع")
                    .font(.custom("Gotham-Bold", size: 11))
                    .foregroundColor(.white)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(JodelZeroPalette.forest)
                    .cornerRadius(8)
            }

            // اسم القناة إن وُجد — في معلومات الأعلى كما في الأصل
            if let channelName {
                Text("•")
                    .foregroundColor(.secondary)
                Label(channelName, systemImage: "number.circle.fill")
                    .font(.custom("Gotham-Book", size: 13))
                    .foregroundColor(.secondary)
                    .lineLimit(1)
            }

            Spacer()

            if livePost.isBoosted {
                boostBadge
            }

            // قائمة المشاركة / الإبلاغ / التعزيز
            Menu {
                ShareLink(item: "منشور من Jodel Zero:\n\(livePost.text)",
                          subject: Text("منشور من Jodel Zero")) {
                    Label("مشاركة", systemImage: "square.and.arrow.up")
                }
                // خيارات التنزيل (#28)
                Menu {
                    if livePost.imageData != nil {
                        Button {
                            savePostImage()
                        } label: {
                            Label("حفظ الصورة", systemImage: "photo.on.rectangle.angled")
                        }
                    }
                    // نسخ رابط الوسائط (#26 — المعادل العام): يظهر فقط عند
                    // وجود وسائط (صورة محلية أو رابط في النص).
                    if livePost.imageData != nil || firstURL(in: livePost.text) != nil {
                        Button {
                            copyMediaURL()
                        } label: {
                            Label("نسخ رابط الوسائط", systemImage: "link")
                        }
                    }
                    Button {
                        copyPostText()
                    } label: {
                        Label("نسخ النص", systemImage: "doc.on.doc")
                    }
                    if let url = firstURL(in: livePost.text) {
                        Button {
                            safariURL = url
                        } label: {
                            Label("فتح الرابط", systemImage: "safari")
                        }
                    }
                } label: {
                    Label("خيارات التنزيل", systemImage: "arrow.down.circle")
                }
                // المتابعة (#31) — لا يتابع المرء نفسه
                if livePost.isMine == false {
                    Button {
                        store.toggleFollow(tag: livePost.authorTag)
                        jodelHaptic(.light)
                    } label: {
                        Label(store.isFollowing(tag: livePost.authorTag) ? "إلغاء المتابعة" : "متابعة الكاتب", systemImage: "person.badge.plus")
                    }
                }
                if livePost.isMine {
                    Button {
                        boostSucceeded = store.boostPost(livePost)
                        showBoostResult = true
                        jodelHaptic(.medium)
                    } label: {
                        Label("تعزيز المنشور", systemImage: "rocket.fill")
                    }
                }
                Button(role: .destructive) {
                    showReportConfirmation = true
                } label: {
                    Label("الإبلاغ عن المنشور", systemImage: "flag.fill")
                }
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.secondary)
                    .frame(minWidth: 44, minHeight: 44)
                    .contentShape(Rectangle())
            }
            .accessibilityLabel("خيارات المنشور")
        }
    }

    private var boostBadge: some View {
        HStack(spacing: 4) {
            Image(systemName: "rocket.fill")
                .font(.system(size: 11))
            Text("معزَّز")
                .font(.custom("Gotham-Bold", size: 12))
        }
        .foregroundColor(.white)
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(JodelZeroPalette.karmaGold)
        .cornerRadius(10)
    }

    // MARK: رقائق الوسوم

    private func hashtagChips(tags: [String]) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(tags, id: \.self) { tag in
                    Button("#\(tag)") {
                        jodelHaptic(.light)
                        onHashtagTap?(tag)
                    }
                    .font(.custom("Gotham-Medium", size: 14))
                    .foregroundColor(JodelZeroPalette.forest)
                    .padding(.horizontal, 10)
                    .frame(minHeight: 44)
                    .background(JodelZeroPalette.forest.opacity(0.10))
                    .cornerRadius(12)
                }
            }
        }
    }

    // MARK: صف التصويت والردود

    private var footerRow: some View {
        HStack(spacing: 4) {
            // التصويت الإيجابي
            voteButton(
                isUp: true,
                count: livePost.upvotes,
                isActive: livePost.myVote == .up
            )
            .overlay(alignment: .center) {
                if burstID > 0 {
                    VoteBurstView()
                        .id(burstID)
                }
            }

            Text("\(livePost.score)")
                .font(.custom("Gotham-Bold", size: 16))
                .foregroundColor(scoreColor)
                .frame(minWidth: 36)
                .accessibilityLabel("نتيجة التصويت \(livePost.score)")

            // التصويت السلبي
            voteButton(
                isUp: false,
                count: livePost.downvotes,
                isActive: livePost.myVote == .down
            )

            Spacer()

            // زر الردود (ينتقل للتفاصيل من الخلاصة)
            if isDetail {
                Label("\(livePost.replyCount)", systemImage: "bubble.left.fill")
                    .font(.custom("Gotham-Medium", size: 15))
                    .foregroundColor(.secondary)
                    .frame(minHeight: 44)
            } else {
                Button {
                    jodelHaptic(.light)
                    onReplyTap?()
                } label: {
                    Label("\(livePost.replyCount)", systemImage: "bubble.left.fill")
                        .font(.custom("Gotham-Medium", size: 15))
                        .foregroundColor(.secondary)
                }
                .frame(minHeight: 44)
                .accessibilityLabel("\(livePost.replyCount) ردود — عرض التفاصيل")
            }

            // الوقت والموقع — في صف المعلومات السفلي كما في الأصل
            Text("•")
                .foregroundColor(.secondary)
            Text(jodelTimeAgo(from: livePost.createdAt))
                .font(.custom("Gotham-Book", size: 13))
                .foregroundColor(.secondary)
            Text("•")
                .foregroundColor(.secondary)
            HStack(spacing: 4) {
                Image(systemName: "mappin.circle.fill")
                    .font(.system(size: 12))
                Text(livePost.city)
                    .font(.custom("Gotham-Book", size: 13))
            }
            .foregroundColor(.secondary)
        }
    }

    private var scoreColor: Color {
        if livePost.score > 0 { return JodelZeroPalette.upvote }
        if livePost.score < 0 { return JodelZeroPalette.downvote }
        return .secondary
    }

    private func voteButton(isUp: Bool, count: Int, isActive: Bool) -> some View {
        Button {
            castVote(isUp: isUp)
        } label: {
            HStack(spacing: 4) {
                Image(systemName: isUp ? "arrow.up.circle.fill" : "arrow.down.circle.fill")
                    .font(.system(size: 22))
                Text("\(count)")
                    .font(.custom("Gotham-Bold", size: 15))
            }
            .foregroundColor(isActive
                             ? (isUp ? JodelZeroPalette.upvote : JodelZeroPalette.downvote)
                             : .secondary)
            .frame(minWidth: 44, minHeight: 44)
            .contentShape(Rectangle())
            .scaleEffect(isActive ? voteScale : 1.0)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(isUp ? "تصويت إيجابي — \(count)" : "تصويت سلبي — \(count)")
    }

    private func castVote(isUp: Bool) {
        let target: Vote
        if isUp {
            target = livePost.myVote == .up ? .none : .up
        } else {
            target = livePost.myVote == .down ? .none : .down
        }
        jodelHaptic(target == .none ? .light : .medium)
        withAnimation(.spring(response: 0.25, dampingFraction: 0.5)) {
            voteScale = 1.35
        }
        if target == .up {
            burstID += 1
        }
        store.votePost(livePost, target)
        withAnimation(.spring(response: 0.35, dampingFraction: 0.6).delay(0.08)) {
            voteScale = 1.0
        }
    }

    // MARK: - Zero: النسخ والحفظ والروابط (#4، #3، #22، #32)

    /// نسخ نص المنشور (#4) — يعمل فقط عند تفعيل «نسخ النص»، ويُسجَّل في
    /// سجل النسخ (#12).
    private func copyPostText() {
        guard store.zero.copyText else { return }
        UIPasteboard.general.string = livePost.text
        store.addCopiedText(livePost.text)
        jodelHaptic(.light)
        showCopiedConfirmation = true
    }

    /// حفظ صورة المنشور في مكتبة الصور (#3، #22) — فقط عند تفعيل «حفظ الصور».
    private func savePostImage() {
        guard store.zero.saveImages,
              let data = livePost.imageData,
              let uiImage = UIImage(data: data) else { return }
        UIImageWriteToSavedPhotosAlbum(uiImage, nil, nil, nil)
        jodelHaptic(.medium)
        showSavedConfirmation = true
    }

    /// نسخ رابط الوسائط (#26 — المعادل العام): رابط من نص المنشور إن وُجد،
    /// وإلا رابط ملف الصورة المحلية بعد كتابتها في مجلد مؤقت.
    private func copyMediaURL() {
        guard let url = mediaURL() else { return }
        UIPasteboard.general.string = url.absoluteString
        jodelHaptic(.light)
        showMediaURLCopied = true
    }

    /// رابط الوسائط: أول رابط في النص، أو ملف مؤقت لصورة المنشور المحلية.
    private func mediaURL() -> URL? {
        if let url = firstURL(in: livePost.text) { return url }
        guard let data = livePost.imageData else { return nil }
        let fileURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("JodelZero-media-\(livePost.id.uuidString).jpg")
        do {
            try data.write(to: fileURL)
            return fileURL
        } catch {
            return nil
        }
    }

    /// أول رابط http(s) في النص — nil إن لم يوجد.
    private func firstURL(in text: String) -> URL? {
        guard let detector = try? NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue) else { return nil }
        let range = NSRange(text.startIndex..., in: text)
        guard let match = detector.firstMatch(in: text, options: [], range: range),
              let url = match.url else { return nil }
        return url
    }
}

// MARK: - ExpandedMediaView (وسائط موسّعة #29 — ملء الشاشة)

private struct ExpandedMediaView: View {
    let image: UIImage
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            Image(uiImage: image)
                .resizable()
                .scaledToFit()
                .ignoresSafeArea()
            VStack {
                HStack {
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 28))
                            .foregroundColor(.white.opacity(0.85))
                    }
                    .frame(minWidth: 44, minHeight: 44)
                    .padding()
                }
                Spacer()
            }
        }
    }
}

// MARK: - SafariView (متصفح داخل التطبيق #32)

private struct SafariView: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> SFSafariViewController {
        SFSafariViewController(url: url)
    }

    func updateUIViewController(_ uiViewController: SFSafariViewController, context: Context) {}
}
