// Models.swift
// Jodel Zero — Data models
// Original code for the Jodel Zero app. SwiftUI + Foundation only, iOS 16, Swift 5.
// No third-party dependencies. No login gate, no activation code, no paywall.

import Foundation

// MARK: - Enums

/// Current user's vote on a post or reply.
enum Vote: String, Codable {
    case none
    case up
    case down
}

/// Feed ordering chosen by the user.
enum FeedSort: String, Codable, CaseIterable {
    case newest
    case top
    case commented
}

/// App display language.
enum AppLanguage: String, Codable, CaseIterable {
    case arabic = "ar"
    case english = "en"
}

/// Where the store reads and writes data: on-device only, or the Jodel Zero server.
enum BackendMode: String, Codable {
    case local
    case server
}

// MARK: - Post

struct Post: Identifiable, Codable, Equatable {
    var id: UUID
    var authorTag: String        // مثل «جار #1234» — مجهول
    var text: String
    var imageSymbol: String?     // اسم رمز SF Symbol للصورة التوضيحية (لا صور خارجية)
    var hashtags: [String]
    var channelId: UUID?
    var city: String
    var createdAt: Date
    var upvotes: Int
    var downvotes: Int
    var myVote: Vote
    var replyCount: Int
    var poll: Poll?
    var postColor: String        // اسم لون المنشور (من ألوان الكارما)
    var isBoosted: Bool
    var isMine: Bool
    /// صورة حقيقية مرفقة بالمنشور (JPEG مضغوط، من المعرض) — nil للمنشورات
    /// التي تستخدم رمز SF Symbol فقط. اختياري ليبقى فك ترميز البيانات
    /// المحفوظة قديماً سليماً.
    var imageData: Data? = nil

    var score: Int { upvotes - downvotes }

    /// A post is hidden (replaced by a "hidden by voting" card) when its score reaches -5.
    var isHiddenByVotes: Bool { score <= -5 }
}

// MARK: - Reply

struct Reply: Identifiable, Codable, Equatable {
    var id: UUID
    var postId: UUID
    var authorTag: String
    var text: String
    var createdAt: Date
    var upvotes: Int
    var downvotes: Int
    var myVote: Vote
    var isMine: Bool

    var score: Int { upvotes - downvotes }
}

// MARK: - Poll

struct Poll: Identifiable, Codable, Equatable {
    var id: UUID
    var question: String
    var options: [PollOption]
    var endsAt: Date
    var myChoice: UUID?

    var totalVotes: Int { options.reduce(0) { $0 + $1.votes } }

    /// Polls are active for 24h.
    var isActive: Bool { Date() < endsAt }
}

struct PollOption: Identifiable, Codable, Equatable {
    var id: UUID
    var text: String
    var votes: Int
}

// MARK: - Channel

struct Channel: Identifiable, Codable, Equatable {
    var id: UUID
    var name: String
    var description: String
    var icon: String
    var color: String
    var category: String
    var memberCount: Int
    var isJoined: Bool
    var postCount: Int
}

// MARK: - Chat

struct Conversation: Identifiable, Codable, Equatable {
    var id: UUID
    var otherTag: String
    var vibe: String   // إيموجي المزاج
    var lastMessage: String
    var lastAt: Date
    var unreadCount: Int
    var isRequest: Bool
    var isBlocked: Bool
    var messages: [ChatMessage]
}

struct ChatMessage: Identifiable, Codable, Equatable {
    var id: UUID
    var text: String
    var isMine: Bool
    var createdAt: Date
    var isMedia: Bool
    var mediaConsented: Bool
    /// رسالة محذوفة أُبقيت ظاهرة (ميزة «الاحتفاظ بالرسائل المحذوفة») —
    /// تُعرض كـ «رسالة محذوفة» بدل إزالتها.
    var isDeleted: Bool = false
    /// اسم ملف صوتي مرسَل من الملفات (داخل مجلد Documents/audio) — nil
    /// للرسائل النصية ووسائط الرموز.
    var audioFileName: String? = nil
}

// MARK: - Achievement

struct Achievement: Identifiable, Codable, Equatable {
    var id: String
    var title: String
    var description: String
    var icon: String
    var isUnlocked: Bool
    var progress: Double // 0...1
}

// MARK: - UserProfile

struct UserProfile: Codable, Equatable {
    var tag: String
    var karma: Int
    var level: Int
    var dailyRewardsClaimed: Bool
    var lastRewardDate: Date?
    var boostsAvailable: Int
    var giftsAvailable: Int
    var premiumColorsAvailable: Int
    var language: AppLanguage
    var notificationsEnabled: Bool
    var darkMode: Bool
    var selectedTheme: String
    var selectedIcon: String
    var blockedTags: [String]
    var myPostIds: [UUID]
    var myVoteCount: Int

    var levelName: String { "مستوى \(level)" }
}

// MARK: - City

struct City: Identifiable, Codable, Equatable {
    var id: String
    var name: String
    var nameEn: String
    var isHometown: Bool
}

// MARK: - Karma rules (fixed by spec)
//
// نشر منشور +5، رد +2، تصويت +1، تلقي تصويت إيجابي +3،
// تلقي تصويت سلبي −2، مكافأة يومية +10، تعزيز منشور يكلف 1 تعزيز.
// المستوى = karma / 100 + 1 (الحد الأدنى 1).
// المنشور يُخفى إن وصلت نتيجته إلى −5.

enum KarmaRules {
    static let postCreated = 5
    static let replyCreated = 2
    static let voteCast = 1
    static let receivedUpvote = 3
    static let receivedDownvote = -2
    static let dailyReward = 10
    static let boostCost = 1
    static let hiddenScoreThreshold = -5

    static func level(forKarma karma: Int) -> Int {
        max(1, karma / 100 + 1)
    }
}

// MARK: - Zero settings (إعدادات أداة Zero — من FEATURES.md)
//
// كل مفتاح هنا يقابل إضافة مسماة في النسخة الأصلية. الميزات التي لا
// يوجد لها مقابل حقيقي في بناء جديد من الصفر (إزالة التمويه، إزالة
// الإعلانات، مسجل اللمس، ZeroStudio، M3U8، تفريغ الكلاسات، القصص)
// ليست هنا — فهي غير قابلة للتطبيق ومذكورة كذلك في BUILD_REPORT.md.
// تُحفظ هذه الإعدادات في مفتاح UserDefaults مستقل عن حالة المنشورات.

/// اختيار خط التطبيق (ميزة «خطوط مخصصة» #14).
enum AppFontChoice: String, Codable, CaseIterable {
    case system = "system"      // خط النظام
    case gotham = "gotham"      // Gotham (الافتراضي)
    case monoton = "monoton"    // Monoton
    case titanOne = "titanOne"  // Titan One
    case tradeWinds = "tradeWinds" // TradeWinds

    /// اسم الخط للعناوين العريضة (nil = خط النظام).
    var boldName: String? {
        switch self {
        case .system: return nil
        case .gotham: return "Gotham-Bold"
        case .monoton: return "Monoton-Regular"
        case .titanOne: return "TitanOne-Regular"
        case .tradeWinds: return "TradeWinds-Regular"
        }
    }

    /// اسم الخط للنص العادي (nil = خط النظام).
    var bookName: String? {
        switch self {
        case .system: return nil
        case .gotham: return "Gotham-Book"
        case .monoton: return "Monoton-Regular"
        case .titanOne: return "TitanOne-Regular"
        case .tradeWinds: return "TradeWinds-Regular"
        }
    }

    /// اسم الخط المتوسط (nil = خط النظام).
    var mediumName: String? {
        switch self {
        case .system: return nil
        case .gotham: return "Gotham-Medium"
        case .monoton: return "Monoton-Regular"
        case .titanOne: return "TitanOne-Regular"
        case .tradeWinds: return "TradeWinds-Regular"
        }
    }

    var displayName: String {
        switch self {
        case .system: return "خط النظام"
        case .gotham: return "Gotham"
        case .monoton: return "Monoton"
        case .titanOne: return "Titan One"
        case .tradeWinds: return "TradeWinds"
        }
    }
}

/// نص منسوخ محفوظ في «سجل النسخ» (#12).
struct CopiedText: Identifiable, Codable, Equatable {
    var id: UUID
    var text: String
    var createdAt: Date
}

/// إعدادات أداة Zero — كل المفاتيح لها قيم افتراضية ليبقى فك الترميز
/// آمناً عند إضافة مفاتيح جديدة لاحقاً.
struct ZeroSettings: Codable, Equatable {
    // إعدادات الفيد (#3 حفظ الصور، #4 نسخ النص)
    var saveImages: Bool = true
    var copyText: Bool = true
    // إعدادات النشر والمحادثات (#5 تأكيد الرد، #6 تأكيد النشر)
    var confirmReply: Bool = false
    var confirmPost: Bool = false
    // إعدادات الرفع (#7 الرفع من المعرض)
    var uploadFromGallery: Bool = true
    // إعدادات الخصوصية (#8 تعطيل إشعار لقطة الشاشة، #23 إيقاف التتبع)
    var disableScreenshotAlert: Bool = true
    var stopTracking: Bool = true
    // إعدادات الأمان (#9 حماية التطبيق)
    var protectApp: Bool = false
    var askEachTime: Bool = true
    // مزايا Zero (#10 مغير الصوت، #11 لوحة الإيموجي السريعة، #12 سجل النسخ)
    var voiceChanger: Bool = true
    var quickEmoji: Bool = true
    var copyHistoryEnabled: Bool = true
    // خطوط مخصصة (#14) — اختيار الخط
    var customFonts: Bool = false
    var fontChoice: AppFontChoice = .gotham
    // الموقع (#15 تزييف الموقع — المعادل المحلي: تصفح مدن أخرى بشفافية)
    var locationSpoof: Bool = true
    // الاحتفاظ بالرسائل المحذوفة (#21)
    var keepDeletedMessages: Bool = true
    // سرعة/طبقة تشغيل المؤثرات الصوتية في مغير الصوت (0.5...2.0)
    var soundPitch: Double = 1.0
    // المتابَعون (حالة المتابعة #31 — أنا أتابعهم)
    var followedTags: [String] = []
    // سجل النسخ (#12) — آخر 50 نصاً كحد أقصى
    var copyHistory: [CopiedText] = []
}

// MARK: - Account Manager (إدارة الحسابات #19 — حد 3 حسابات محلية)

/// حساب محلي واحد (ملف تعريف + حالة منشورات مستقلة).
struct AccountSlot: Identifiable, Codable, Equatable {
    var id: UUID
    var name: String
    var tag: String
    var storageKey: String
}

/// قائمة الحسابات + الحساب النشط — تُحفظ في مفتاح UserDefaults مستقل.
struct AccountStore: Codable, Equatable {
    var slots: [AccountSlot]
    var activeSlotId: UUID
}
