// Models.swift
// ساحة (Saha) — Data models
// Original code for the Saha app. SwiftUI + Foundation only, iOS 16, Swift 5.
// No third-party dependencies. No login gate, no activation code, no paywall.

import Foundation

// MARK: - Enums

/// Current user's vote on a post or reply.
enum Vote: String, Codable {
    case none
    case up
    case down
}

/// Feed ordering chosen by the user.
enum FeedSort: String, Codable, CaseIterable {
    case newest
    case top
    case commented
}

/// App display language.
enum AppLanguage: String, Codable, CaseIterable {
    case arabic = "ar"
    case english = "en"
}

/// Where the store reads and writes data: on-device only, or the Saha server.
enum BackendMode: String, Codable {
    case local
    case server
}

// MARK: - Post

struct Post: Identifiable, Codable, Equatable {
    var id: UUID
    var authorTag: String        // مثل «جار #1234» — مجهول
    var text: String
    var imageSymbol: String?     // اسم رمز SF Symbol للصورة التوضيحية (لا صور خارجية)
    var hashtags: [String]
    var channelId: UUID?
    var city: String
    var createdAt: Date
    var upvotes: Int
    var downvotes: Int
    var myVote: Vote
    var replyCount: Int
    var poll: Poll?
    var postColor: String        // اسم لون المنشور (من ألوان الكارما)
    var isBoosted: Bool
    var isMine: Bool

    var score: Int { upvotes - downvotes }

    /// A post is hidden (replaced by a "hidden by voting" card) when its score reaches -5.
    var isHiddenByVotes: Bool { score <= -5 }
}

// MARK: - Reply

struct Reply: Identifiable, Codable, Equatable {
    var id: UUID
    var postId: UUID
    var authorTag: String
    var text: String
    var createdAt: Date
    var upvotes: Int
    var downvotes: Int
    var myVote: Vote
    var isMine: Bool

    var score: Int { upvotes - downvotes }
}

// MARK: - Poll

struct Poll: Identifiable, Codable, Equatable {
    var id: UUID
    var question: String
    var options: [PollOption]
    var endsAt: Date
    var myChoice: UUID?

    var totalVotes: Int { options.reduce(0) { $0 + $1.votes } }

    /// Polls are active for 24h.
    var isActive: Bool { Date() < endsAt }
}

struct PollOption: Identifiable, Codable, Equatable {
    var id: UUID
    var text: String
    var votes: Int
}

// MARK: - Channel

struct Channel: Identifiable, Codable, Equatable {
    var id: UUID
    var name: String
    var description: String
    var icon: String
    var color: String
    var category: String
    var memberCount: Int
    var isJoined: Bool
    var postCount: Int
}

// MARK: - Chat

struct Conversation: Identifiable, Codable, Equatable {
    var id: UUID
    var otherTag: String
    var vibe: String   // إيموجي المزاج
    var lastMessage: String
    var lastAt: Date
    var unreadCount: Int
    var isRequest: Bool
    var isBlocked: Bool
    var messages: [ChatMessage]
}

struct ChatMessage: Identifiable, Codable, Equatable {
    var id: UUID
    var text: String
    var isMine: Bool
    var createdAt: Date
    var isMedia: Bool
    var mediaConsented: Bool
}

// MARK: - Achievement

struct Achievement: Identifiable, Codable, Equatable {
    var id: String
    var title: String
    var description: String
    var icon: String
    var isUnlocked: Bool
    var progress: Double // 0...1
}

// MARK: - UserProfile

struct UserProfile: Codable, Equatable {
    var tag: String
    var karma: Int
    var level: Int
    var dailyRewardsClaimed: Bool
    var lastRewardDate: Date?
    var boostsAvailable: Int
    var giftsAvailable: Int
    var premiumColorsAvailable: Int
    var language: AppLanguage
    var notificationsEnabled: Bool
    var darkMode: Bool
    var selectedTheme: String
    var selectedIcon: String
    var blockedTags: [String]
    var myPostIds: [UUID]
    var myVoteCount: Int

    var levelName: String { "مستوى \(level)" }
}

// MARK: - City

struct City: Identifiable, Codable, Equatable {
    var id: String
    var name: String
    var nameEn: String
    var isHometown: Bool
}

// MARK: - Karma rules (fixed by spec)
//
// نشر منشور +5، رد +2، تصويت +1، تلقي تصويت إيجابي +3،
// تلقي تصويت سلبي −2، مكافأة يومية +10، تعزيز منشور يكلف 1 تعزيز.
// المستوى = karma / 100 + 1 (الحد الأدنى 1).
// المنشور يُخفى إن وصلت نتيجته إلى −5.

enum KarmaRules {
    static let postCreated = 5
    static let replyCreated = 2
    static let voteCast = 1
    static let receivedUpvote = 3
    static let receivedDownvote = -2
    static let dailyReward = 10
    static let boostCost = 1
    static let hiddenScoreThreshold = -5

    static func level(forKarma karma: Int) -> Int {
        max(1, karma / 100 + 1)
    }
}
