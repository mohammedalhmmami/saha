// SeedData.swift
// Jodel Zero — Structure only: cities, channels, achievements, default profile.
// NO demo content: there are no pre-written posts, replies, polls or
// conversations anywhere. The feed and chat start empty and fill only from
// the live server (or from posts the user creates). UI wording follows the
// Arabic phrasing of the original strings where it fits.

import Foundation

enum SeedData {

    // MARK: - Helpers

    /// Deterministic UUIDs so channels can be referenced by id.
    private static func uid(_ n: Int) -> UUID {
        UUID(uuidString: String(format: "00000000-0000-0000-0000-%012d", n)) ?? UUID()
    }

    // MARK: - Cities (6)

    static let cities: [City] = [
        City(id: "riyadh", name: "الرياض", nameEn: "Riyadh", isHometown: true),
        City(id: "jeddah", name: "جدة", nameEn: "Jeddah", isHometown: false),
        City(id: "dammam", name: "الدمام", nameEn: "Dammam", isHometown: false),
        City(id: "mecca", name: "مكة المكرمة", nameEn: "Mecca", isHometown: false),
        City(id: "medina", name: "المدينة المنورة", nameEn: "Medina", isHometown: false),
        City(id: "khobar", name: "الخبر", nameEn: "Khobar", isHometown: false)
    ]

    // MARK: - Channels (10)

    static func channels() -> [Channel] {
        [
            Channel(id: uid(1), name: "الرئيسية", description: "المشاركات التي لا تتناسب مع أي قناة أخرى", icon: "house.fill", color: "green", category: "عام", memberCount: 48210, isJoined: true, postCount: 3120),
            Channel(id: uid(2), name: "تعارف", description: "لاقي نصك الثاني", icon: "heart.fill", color: "pink", category: "تعارف وصداقة", memberCount: 21480, isJoined: true, postCount: 1840),
            Channel(id: uid(3), name: "دراسة", description: "اسأل. ساعد. اشكر. كرر", icon: "book.fill", color: "blue", category: "دراسة", memberCount: 15830, isJoined: true, postCount: 1210),
            Channel(id: uid(4), name: "رياضة", description: "ناقش آخر أخبار الرياضة مع جيرانك", icon: "soccerball", color: "orange", category: "رياضة", memberCount: 30120, isJoined: false, postCount: 2560),
            Channel(id: uid(5), name: "أكل", description: "لعشاق الأكل والمطاعم وتجارب المذاق", icon: "fork.knife", color: "gold", category: "طعام", memberCount: 18940, isJoined: true, postCount: 1490),
            Channel(id: uid(6), name: "تقنية", description: "كل ما يخص التقنية والجوالات والبرمجة", icon: "cpu", color: "purple", category: "تقنية", memberCount: 12760, isJoined: false, postCount: 980),
            Channel(id: uid(7), name: "سيارات", description: "أخبار السيارات ونصائح الصيانة والقيادة", icon: "car.fill", color: "red", category: "سيارات", memberCount: 11230, isJoined: false, postCount: 870),
            Channel(id: uid(8), name: "ضحك", description: "قصص مضحكة ومواقف من الحياة اليومية", icon: "face.smiling.fill", color: "teal", category: "ضحك", memberCount: 27650, isJoined: true, postCount: 2210),
            Channel(id: uid(9), name: "أخبار مدينتك", description: "شارك فعاليات مدينتك وأخبار حيّك", icon: "newspaper.fill", color: "blue", category: "أخبار محلية", memberCount: 9840, isJoined: false, postCount: 640),
            Channel(id: uid(10), name: "قيمنق", description: "للاعبين: أخبار الألعاب وتجمعات اللعب", icon: "gamecontroller.fill", color: "purple", category: "ألعاب", memberCount: 14370, isJoined: false, postCount: 1130)
        ]
    }

    // MARK: - Content: none (live only)

    /// No pre-written posts. The feed starts empty and fills from the server.
    static func posts() -> [Post] { [] }

    /// No pre-written replies.
    static func replies() -> [UUID: [Reply]] { [:] }

    /// No pre-written polls.
    static func polls() -> [Poll] { [] }

    /// No pre-written conversations. Chat starts empty and fills from the server.
    static func conversations() -> [Conversation] { [] }

    // MARK: - Achievements (8 — all locked for a fresh user)

    static let achievements: [Achievement] = [
        Achievement(id: "first_post", title: "أول منشور", description: "انشر أول منشور لك في Jodel Zero", icon: "square.and.pencil", isUnlocked: false, progress: 0.0),
        Achievement(id: "first_reply", title: "جار طيب", description: "رد على منشور بأسلوب الجار الطيب", icon: "text.bubble.fill", isUnlocked: false, progress: 0.0),
        Achievement(id: "voter_10", title: "صوتك يفرق", description: "صوّت على 10 منشورات", icon: "hand.thumbsup.fill", isUnlocked: false, progress: 0.0),
        Achievement(id: "karma_100", title: "كارما 100", description: "اجمع 100 نقطة كارما", icon: "star.fill", isUnlocked: false, progress: 0.0),
        Achievement(id: "karma_500", title: "نجم Jodel Zero", description: "اجمع 500 نقطة كارما", icon: "sparkles", isUnlocked: false, progress: 0.0),
        Achievement(id: "top10", title: "ترند", description: "وصل أحد منشوراتك إلى ترند المدينة", icon: "flame.fill", isUnlocked: false, progress: 0.0),
        Achievement(id: "chat_7", title: "اجتماعي", description: "ابدأ 7 محادثات خاصة", icon: "message.fill", isUnlocked: false, progress: 0.0),
        Achievement(id: "daily_7", title: "مواظب", description: "اطلب المكافأة اليومية 7 أيام متتالية", icon: "calendar.badge.checkmark", isUnlocked: false, progress: 0.0)
    ]

    // MARK: - Default profile (fresh user: no karma, no posts, no votes)

    static func defaultProfile() -> UserProfile {
        UserProfile(
            tag: "جار #4821",
            karma: 0,
            level: 1,
            dailyRewardsClaimed: false,
            lastRewardDate: nil,
            boostsAvailable: 3,
            giftsAvailable: 3,
            premiumColorsAvailable: 8,
            language: .arabic,
            notificationsEnabled: true,
            darkMode: false,
            selectedTheme: "green",
            selectedIcon: "default",
            blockedTags: [],
            myPostIds: [],
            myVoteCount: 0
        )
    }
}
