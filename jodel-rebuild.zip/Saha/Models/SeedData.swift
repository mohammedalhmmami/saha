// SeedData.swift
// ساحة (Saha) — Realistic Arabic demo seed data
// Original content written for the Saha app. UI wording follows the Arabic
// phrasing of the original strings where it fits (e.g. «وش عندك اليوم؟ شاركنا»،
// «رد بأسلوب الجار الطيب»، «الكارما الخاصّة بي»، «الإستبيان متاح لمدة 24 ساعة»).
// All authors are anonymous («جار #…»). No real people, no copied text.

import Foundation

enum SeedData {

    // MARK: - Helpers

    /// Deterministic UUIDs so posts, channels, polls and replies can reference each other.
    private static func uid(_ n: Int) -> UUID {
        UUID(uuidString: String(format: "00000000-0000-0000-0000-%012d", n)) ?? UUID()
    }

    private static func minutesAgo(_ minutes: Double) -> Date {
        Date().addingTimeInterval(-minutes * 60)
    }

    private static func hoursAgo(_ hours: Double) -> Date {
        minutesAgo(hours * 60)
    }

    // MARK: - Cities (6)

    static let cities: [City] = [
        City(id: "riyadh", name: "الرياض", nameEn: "Riyadh", isHometown: true),
        City(id: "jeddah", name: "جدة", nameEn: "Jeddah", isHometown: false),
        City(id: "dammam", name: "الدمام", nameEn: "Dammam", isHometown: false),
        City(id: "mecca", name: "مكة المكرمة", nameEn: "Mecca", isHometown: false),
        City(id: "medina", name: "المدينة المنورة", nameEn: "Medina", isHometown: false),
        City(id: "khobar", name: "الخبر", nameEn: "Khobar", isHometown: false)
    ]

    // MARK: - Channels (10)

    static func channels() -> [Channel] {
        [
            Channel(id: uid(1), name: "الرئيسية", description: "المشاركات التي لا تتناسب مع أي قناة أخرى", icon: "house.fill", color: "green", category: "عام", memberCount: 48210, isJoined: true, postCount: 3120),
            Channel(id: uid(2), name: "تعارف", description: "لاقي نصك الثاني", icon: "heart.fill", color: "pink", category: "تعارف وصداقة", memberCount: 21480, isJoined: true, postCount: 1840),
            Channel(id: uid(3), name: "دراسة", description: "اسأل. ساعد. اشكر. كرر", icon: "book.fill", color: "blue", category: "دراسة", memberCount: 15830, isJoined: true, postCount: 1210),
            Channel(id: uid(4), name: "رياضة", description: "ناقش آخر أخبار الرياضة مع جيرانك", icon: "soccerball", color: "orange", category: "رياضة", memberCount: 30120, isJoined: false, postCount: 2560),
            Channel(id: uid(5), name: "أكل", description: "لعشاق الأكل والمطاعم وتجارب المذاق", icon: "fork.knife", color: "gold", category: "طعام", memberCount: 18940, isJoined: true, postCount: 1490),
            Channel(id: uid(6), name: "تقنية", description: "كل ما يخص التقنية والجوالات والبرمجة", icon: "cpu", color: "purple", category: "تقنية", memberCount: 12760, isJoined: false, postCount: 980),
            Channel(id: uid(7), name: "سيارات", description: "أخبار السيارات ونصائح الصيانة والقيادة", icon: "car.fill", color: "red", category: "سيارات", memberCount: 11230, isJoined: false, postCount: 870),
            Channel(id: uid(8), name: "ضحك", description: "قصص مضحكة ومواقف من الحياة اليومية", icon: "face.smiling.fill", color: "teal", category: "ضحك", memberCount: 27650, isJoined: true, postCount: 2210),
            Channel(id: uid(9), name: "أخبار مدينتك", description: "شارك فعاليات مدينتك وأخبار حيّك", icon: "newspaper.fill", color: "blue", category: "أخبار محلية", memberCount: 9840, isJoined: false, postCount: 640),
            Channel(id: uid(10), name: "قيمنق", description: "للاعبين: أخبار الألعاب وتجمعات اللعب", icon: "gamecontroller.fill", color: "purple", category: "ألعاب", memberCount: 14370, isJoined: false, postCount: 1130)
        ]
    }

    // MARK: - Polls (3, active 24h)

    /// The three seeded polls (each lives inside one of the seeded posts).
    static func polls() -> [Poll] {
        posts().compactMap { $0.poll }
    }

    private static func pollFootball() -> Poll {
        Poll(
            id: uid(201),
            question: "من يفوز في مباراة القمة الليلة؟",
            options: [
                PollOption(id: uid(211), text: "الهلال", votes: 148),
                PollOption(id: uid(212), text: "النصر", votes: 132),
                PollOption(id: uid(213), text: "تعادل", votes: 41)
            ],
            endsAt: Date().addingTimeInterval(24 * 3600),
            myChoice: nil
        )
    }

    private static func pollCoffee() -> Poll {
        Poll(
            id: uid(202),
            question: "وش أفضل وقت للقهوة عندك؟",
            options: [
                PollOption(id: uid(221), text: "الصباح بدري", votes: 96),
                PollOption(id: uid(222), text: "بعد العصر", votes: 121),
                PollOption(id: uid(223), text: "بعد العشاء", votes: 58),
                PollOption(id: uid(224), text: "أي وقت يمشي", votes: 84)
            ],
            endsAt: Date().addingTimeInterval(24 * 3600),
            myChoice: nil
        )
    }

    private static func pollWeekend() -> Poll {
        Poll(
            id: uid(203),
            question: "وش خطتك لعطلة نهاية الأسبوع؟",
            options: [
                PollOption(id: uid(231), text: "طلعة بر مع الأهل", votes: 77),
                PollOption(id: uid(232), text: "كافيه ومطعم", votes: 103),
                PollOption(id: uid(233), text: "نوم وراحة بالبيت", votes: 129)
            ],
            endsAt: Date().addingTimeInterval(24 * 3600),
            myChoice: nil
        )
    }

    // MARK: - Posts (24)

    static func posts() -> [Post] {
        [
            Post(id: uid(101), authorTag: "جار #1234", text: "وش عندك اليوم؟ شاركنا ✍️📸\nالجو اليوم في الرياض رائع، الغيوم مغطية السماء والهواء بارد. أفضل وقت للمشي بعد العصر.", imageSymbol: "cloud.sun.fill", hashtags: ["الرياض", "الجو_اليوم"], channelId: uid(1), city: "الرياض", createdAt: minutesAgo(12), upvotes: 84, downvotes: 3, myVote: .none, replyCount: 9, poll: nil, postColor: "green", isBoosted: false, isMine: false),
            Post(id: uid(102), authorTag: "جار #5678", text: "من يفوز في مباراة القمة الليلة؟ توقعاتكم يا جماعة، المباراة نار من أول دقيقة. انقر للتصويت 👇", imageSymbol: nil, hashtags: ["دوري_روشن", "كرة"], channelId: uid(4), city: "الرياض", createdAt: minutesAgo(25), upvotes: 156, downvotes: 11, myVote: .none, replyCount: 23, poll: pollFootball(), postColor: "orange", isBoosted: true, isMine: false),
            Post(id: uid(103), authorTag: "جار #9012", text: "جرّبت مطعم جديد في جدة أمس، الكبسة عندهم شي ثاني! الأسعار معقولة والجلسة عائلية مريحة. أنصح فيه بقوة.", imageSymbol: "fork.knife", hashtags: ["جدة", "مطاعم"], channelId: uid(5), city: "جدة", createdAt: minutesAgo(40), upvotes: 67, downvotes: 2, myVote: .up, replyCount: 12, poll: nil, postColor: "gold", isBoosted: false, isMine: false),
            Post(id: uid(104), authorTag: "جار #3456", text: "يا جماعة، أحد يعرف أفضل مكان لصيانة السيارة في الدمام؟ أبي ورشة ثقة وأسعارها واضحة قبل ما أروح.", imageSymbol: "car.fill", hashtags: ["الدمام", "سيارات"], channelId: uid(7), city: "الدمام", createdAt: hoursAgo(1), upvotes: 45, downvotes: 1, myVote: .none, replyCount: 18, poll: nil, postColor: "red", isBoosted: false, isMine: false),
            Post(id: uid(105), authorTag: "جار #7890", text: "وش أفضل وقت للقهوة عندك؟ أنا ما يضبط يومي إلا فنجان الصباح بدري مع الهدوء.", imageSymbol: "cup.and.saucer.fill", hashtags: ["قهوة", "صباح"], channelId: uid(1), city: "الرياض", createdAt: hoursAgo(1.5), upvotes: 92, downvotes: 4, myVote: .none, replyCount: 15, poll: pollCoffee(), postColor: "blue", isBoosted: false, isMine: false),
            Post(id: uid(106), authorTag: "جار #2468", text: "نصيحة لطلاب الجامعة: لا تذاكرون ليلة الاختبار بس، قسموا المادة على أيام وخذوا ملخصاتكم بأيديكم. اسأل. ساعد. اشكر. كرر.", imageSymbol: "book.fill", hashtags: ["دراسة", "جامعة"], channelId: uid(3), city: "الرياض", createdAt: hoursAgo(2), upvotes: 118, downvotes: 5, myVote: .up, replyCount: 21, poll: nil, postColor: "blue", isBoosted: false, isMine: false),
            Post(id: uid(107), authorTag: "جار #1357", text: "الموقف اللي صار لي اليوم في السوبرماركت 😂\nوصلت الكاشير واكتشفت إني نسيت المحفظة بالبيت، واللي وراي دفع عني وقال: الدنيا بخير. فيه ناس طيبة والله.", imageSymbol: nil, hashtags: ["ضحك", "مواقف"], channelId: uid(8), city: "جدة", createdAt: hoursAgo(2.5), upvotes: 203, downvotes: 6, myVote: .none, replyCount: 31, poll: nil, postColor: "teal", isBoosted: false, isMine: false),
            Post(id: uid(108), authorTag: "جار #4821", text: "أول منشور لي في ساحة! أهلاً بالجيران، متحمس أشارك معكم أخبار حينا وكل شي يصير حولنا. وش عندكم اليوم؟", imageSymbol: nil, hashtags: ["أهلا", "ساحة"], channelId: uid(1), city: "الرياض", createdAt: hoursAgo(3), upvotes: 38, downvotes: 0, myVote: .none, replyCount: 7, poll: nil, postColor: "green", isBoosted: false, isMine: true),
            Post(id: uid(109), authorTag: "جار #8642", text: "وش خطتك لعطلة نهاية الأسبوع؟ أنا محتار بين طلعة البر والراحة بالبيت. صوتوا وقولوا لي وش تسوون عادة.", imageSymbol: nil, hashtags: ["عطلة", "ويكند"], channelId: uid(1), city: "مكة المكرمة", createdAt: hoursAgo(3.5), upvotes: 54, downvotes: 2, myVote: .none, replyCount: 11, poll: pollWeekend(), postColor: "purple", isBoosted: false, isMine: false),
            Post(id: uid(110), authorTag: "جار #9753", text: "أحد جرب تحديث الآيفون الجديد؟ البطارية صارت أفضل عندي ولا بس إحساسي؟ شاركونا تجاربكم.", imageSymbol: "iphone", hashtags: ["تقنية", "آيفون"], channelId: uid(6), city: "الرياض", createdAt: hoursAgo(4), upvotes: 76, downvotes: 8, myVote: .none, replyCount: 19, poll: nil, postColor: "purple", isBoosted: false, isMine: false),
            Post(id: uid(111), authorTag: "جار #1122", text: "غروب اليوم على كورنيش الخبر شي يشرح الصدر. اللي يقدر يطلع يشوفه لا يفوته، الألوان خيالية.", imageSymbol: "sunset.fill", hashtags: ["الخبر", "غروب"], channelId: uid(9), city: "الخبر", createdAt: hoursAgo(5), upvotes: 141, downvotes: 3, myVote: .up, replyCount: 14, poll: nil, postColor: "gold", isBoosted: false, isMine: false),
            Post(id: uid(112), authorTag: "جار #3344", text: "فعالية عائلية يوم الجمعة في حديقة الملك عبدالله بالمدينة، فيه ألعاب للأطفال وأكشاك أكل. من بيروح؟", imageSymbol: "party.popper.fill", hashtags: ["المدينة", "فعاليات"], channelId: uid(9), city: "المدينة المنورة", createdAt: hoursAgo(6), upvotes: 89, downvotes: 2, myVote: .none, replyCount: 10, poll: nil, postColor: "green", isBoosted: false, isMine: false),
            Post(id: uid(113), authorTag: "جار #5566", text: "ليش كل ما أقول ببدأ دايت يطلع لي إعلان مطعم؟ الخوارزميات تعرفني أكثر من نفسي 😅", imageSymbol: nil, hashtags: ["ضحك", "دايت"], channelId: uid(8), city: "الرياض", createdAt: hoursAgo(7), upvotes: 167, downvotes: 4, myVote: .none, replyCount: 26, poll: nil, postColor: "pink", isBoosted: false, isMine: false),
            Post(id: uid(114), authorTag: "جار #7788", text: "أدور على رفيق لعب للعبة الجديدة، مستواي متوسط وألعب بالليل عادة. اللي مهتم يراسلني، الجو حلو والفريق ناقصه واحد.", imageSymbol: "gamecontroller.fill", hashtags: ["قيمنق", "ألعاب"], channelId: uid(10), city: "جدة", createdAt: hoursAgo(8), upvotes: 61, downvotes: 3, myVote: .none, replyCount: 13, poll: nil, postColor: "purple", isBoosted: false, isMine: false),
            Post(id: uid(115), authorTag: "جار #9900", text: "زحمة طريق الملك فهد اليوم غير طبيعية، اللي طالع الحين يحسب حسابه ويطلع بدري. الله يعين الجميع.", imageSymbol: "car.fill", hashtags: ["الرياض", "زحمة"], channelId: uid(9), city: "الرياض", createdAt: hoursAgo(9), upvotes: 73, downvotes: 5, myVote: .none, replyCount: 16, poll: nil, postColor: "red", isBoosted: false, isMine: false),
            Post(id: uid(116), authorTag: "جار #1212", text: "لاقي نصك الثاني؟ مو شرط يكون حب، أحياناً الصداقة الحقيقية تبدأ بكلمة بسيطة من جار ما تعرفه. قولوا لنا قصص صداقاتكم.", imageSymbol: "heart.fill", hashtags: ["تعارف", "صداقة"], channelId: uid(2), city: "الدمام", createdAt: hoursAgo(10), upvotes: 98, downvotes: 7, myVote: .none, replyCount: 22, poll: nil, postColor: "pink", isBoosted: false, isMine: false),
            Post(id: uid(117), authorTag: "جار #3434", text: "اللي يبي يتعلم البرمجة من الصفر: ابدأ بلغة وحدة والتزم فيها 3 شهور، ولا تقفز بين الدورات. من عنده مصادر مجربة يفيدنا؟", imageSymbol: "laptopcomputer", hashtags: ["تقنية", "برمجة"], channelId: uid(6), city: "الرياض", createdAt: hoursAgo(12), upvotes: 134, downvotes: 2, myVote: .none, replyCount: 28, poll: nil, postColor: "blue", isBoosted: false, isMine: false),
            Post(id: uid(118), authorTag: "جار #5656", text: "أفضل كبسة ذقتها بحياتي كانت في بيت جدتي الله يحفظها، لا مطعم ولا شي يوصل لمستواها. مين يتفق؟", imageSymbol: nil, hashtags: ["أكل", "ذكريات"], channelId: uid(5), city: "مكة المكرمة", createdAt: hoursAgo(14), upvotes: 187, downvotes: 9, myVote: .up, replyCount: 33, poll: nil, postColor: "gold", isBoosted: false, isMine: false),
            Post(id: uid(119), authorTag: "جار #7878", text: "النجوم الليلة واضحة بشكل مو طبيعي، اللي في البر يشوفها أحسن. صوروا لنا إذا طلعتوا.", imageSymbol: "moon.stars.fill", hashtags: ["البر", "نجوم"], channelId: uid(1), city: "المدينة المنورة", createdAt: hoursAgo(16), upvotes: 112, downvotes: 1, myVote: .none, replyCount: 8, poll: nil, postColor: "purple", isBoosted: false, isMine: false),
            Post(id: uid(120), authorTag: "جار #9090", text: "سؤال للطلاب: وش أصعب مادة عندكم هذا الترم؟ عندي الفيزياء مأخذة كل وقتي وما أدري وش أسوي.", imageSymbol: "graduationcap.fill", hashtags: ["دراسة", "جامعة"], channelId: uid(3), city: "جدة", createdAt: hoursAgo(18), upvotes: 69, downvotes: 4, myVote: .none, replyCount: 24, poll: nil, postColor: "blue", isBoosted: false, isMine: false),
            Post(id: uid(121), authorTag: "جار #2020", text: "هذا المنشور تجريبي للتصويت السلبي، لا أحد يتفاعل معه بجدية. محتواه ما يستاهل البقاء في الخلاصة.", imageSymbol: nil, hashtags: ["تجربة"], channelId: uid(1), city: "الرياض", createdAt: hoursAgo(20), upvotes: 2, downvotes: 8, myVote: .none, replyCount: 1, poll: nil, postColor: "red", isBoosted: false, isMine: false),
            Post(id: uid(122), authorTag: "جار #4040", text: "الهدف الذهبي في الدقيقة الأخيرة! المباراة انقلبت رأساً على عقب، وش رايكم في الحكم اليوم؟", imageSymbol: "soccerball", hashtags: ["كرة", "دوري_روشن"], channelId: uid(4), city: "الرياض", createdAt: hoursAgo(22), upvotes: 221, downvotes: 14, myVote: .none, replyCount: 41, poll: nil, postColor: "orange", isBoosted: false, isMine: false),
            Post(id: uid(123), authorTag: "جار #6060", text: "أمس جربت كافيه جديد في حي النرجس، قهوتهم المختصة ممتازة والمكان هادي للمذاكرة. فيه واي فاي سريع وجلسات مريحة.", imageSymbol: "cup.and.saucer.fill", hashtags: ["الرياض", "كافيهات"], channelId: uid(5), city: "الرياض", createdAt: hoursAgo(26), upvotes: 95, downvotes: 3, myVote: .none, replyCount: 17, poll: nil, postColor: "teal", isBoosted: false, isMine: false),
            Post(id: uid(124), authorTag: "جار #8080", text: "يا أهل الخبر، وش أفضل شاطئ للعوائل هالأيام؟ أبي مكان نظيف وهادي للعيال يوم الجمعة.", imageSymbol: "beach.umbrella.fill", hashtags: ["الخبر", "عوائل"], channelId: uid(9), city: "الخبر", createdAt: hoursAgo(30), upvotes: 58, downvotes: 2, myVote: .none, replyCount: 9, poll: nil, postColor: "teal", isBoosted: false, isMine: false)
        ]
    }

    // MARK: - Replies

    static func replies() -> [UUID: [Reply]] {
        [
            uid(101): [
                Reply(id: uid(301), postId: uid(101), authorTag: "جار #2222", text: "صدقت، الجو اليوم يفتح النفس. طلعت أمشي بعد العصر والهواء بارد.", createdAt: minutesAgo(10), upvotes: 12, downvotes: 0, myVote: .none, isMine: false),
                Reply(id: uid(302), postId: uid(101), authorTag: "جار #3333", text: "رد بأسلوب الجار الطيب: استمتعوا بالجو يا جماعة، بس انتبهوا من الغبار آخر الليل.", createdAt: minutesAgo(8), upvotes: 9, downvotes: 0, myVote: .none, isMine: false)
            ],
            uid(102): [
                Reply(id: uid(303), postId: uid(102), authorTag: "جار #4444", text: "أتوقعها تعادل، الفريقين مستواهم متقارب هالموسم.", createdAt: minutesAgo(20), upvotes: 21, downvotes: 1, myVote: .none, isMine: false),
                Reply(id: uid(304), postId: uid(102), authorTag: "جار #5555", text: "الهلال يفوز بهدفين إن شاء الله، هجومهم قوي هالفترة.", createdAt: minutesAgo(15), upvotes: 18, downvotes: 2, myVote: .none, isMine: false)
            ],
            uid(103): [
                Reply(id: uid(305), postId: uid(103), authorTag: "جار #6666", text: "وين مكانه بالضبط؟ أبي أجربه نهاية الأسبوع.", createdAt: minutesAgo(30), upvotes: 7, downvotes: 0, myVote: .none, isMine: false),
                Reply(id: uid(306), postId: uid(103), authorTag: "جار #9012", text: "على طريق الكورنيش، بجانب المول الجديد. بالعافية مقدماً.", createdAt: minutesAgo(22), upvotes: 11, downvotes: 0, myVote: .none, isMine: false)
            ],
            uid(104): [
                Reply(id: uid(307), postId: uid(104), authorTag: "جار #7777", text: "فيه ورشة ممتازة في الصناعية الثانية، شغلهم نظيف وأسعارهم ثابتة.", createdAt: minutesAgo(45), upvotes: 15, downvotes: 0, myVote: .none, isMine: false)
            ],
            uid(106): [
                Reply(id: uid(308), postId: uid(106), authorTag: "جار #8888", text: "أفضل نصيحة سمعتها هالترم، التقسيم على أيام يفرق كثير فعلاً.", createdAt: hoursAgo(1), upvotes: 19, downvotes: 0, myVote: .none, isMine: false)
            ],
            uid(107): [
                Reply(id: uid(309), postId: uid(107), authorTag: "جار #9999", text: "هههههه موقف يضحك، والله الدنيا لسه بخير وفيه ناس طيبة.", createdAt: hoursAgo(2), upvotes: 26, downvotes: 0, myVote: .none, isMine: false),
                Reply(id: uid(310), postId: uid(107), authorTag: "جار #1010", text: "صارت لي نفس السالفة قبل شهر، والكاشير نفسه ساعدني. ناس محترمة.", createdAt: hoursAgo(1.5), upvotes: 14, downvotes: 0, myVote: .none, isMine: false)
            ],
            uid(117): [
                Reply(id: uid(311), postId: uid(117), authorTag: "جار #1111", text: "ابدأ ببايثون، مصادرها كثيرة والمجتمع يساعد. وبعدها انتقل للغة ثانية إذا حبيت.", createdAt: hoursAgo(11), upvotes: 23, downvotes: 0, myVote: .none, isMine: false)
            ],
            uid(118): [
                Reply(id: uid(312), postId: uid(118), authorTag: "جار #1212", text: "أتفق مية بالمية، أكل البيت له طعم ثاني ما يتعوض.", createdAt: hoursAgo(13), upvotes: 31, downvotes: 0, myVote: .none, isMine: false)
            ]
        ]
    }

    // MARK: - Conversations (6)

    static func conversations() -> [Conversation] {
        [
            Conversation(
                id: uid(401), otherTag: "جار #2468", vibe: "🌙",
                lastMessage: "وش جوّك؟ أنا الليلة جوّي هدوء وقهوة وكتاب.",
                lastAt: minutesAgo(18), unreadCount: 2, isRequest: false, isBlocked: false,
                messages: [
                    ChatMessage(id: uid(411), text: "هلا! شفت منشورك عن الدراسة، نصايحك عجبتني.", isMine: false, createdAt: hoursAgo(2), isMedia: false, mediaConsented: false),
                    ChatMessage(id: uid(412), text: "هلا فيك، تسلم. أنت بأي تخصص؟", isMine: true, createdAt: hoursAgo(1.8), isMedia: false, mediaConsented: false),
                    ChatMessage(id: uid(413), text: "هندسة، والفيزياء ذابحتني هالترم 😅", isMine: false, createdAt: hoursAgo(1.5), isMedia: false, mediaConsented: false),
                    ChatMessage(id: uid(414), text: "وش جوّك؟ أنا الليلة جوّي هدوء وقهوة وكتاب.", isMine: false, createdAt: minutesAgo(18), isMedia: false, mediaConsented: false)
                ]
            ),
            Conversation(
                id: uid(402), otherTag: "جار #1357", vibe: "☕",
                lastMessage: "يا سلام، توافق سلس 💫 نفس جوّ القهوة الصباحية!",
                lastAt: minutesAgo(45), unreadCount: 0, isRequest: false, isBlocked: false,
                messages: [
                    ChatMessage(id: uid(421), text: "وش جوّك؟", isMine: false, createdAt: hoursAgo(3), isMedia: false, mediaConsented: false),
                    ChatMessage(id: uid(422), text: "قهوة صباحية وهدوء، وأنت؟", isMine: true, createdAt: hoursAgo(3), isMedia: false, mediaConsented: false),
                    ChatMessage(id: uid(423), text: "يا سلام، توافق سلس 💫 نفس جوّ القهوة الصباحية!", isMine: false, createdAt: minutesAgo(45), isMedia: false, mediaConsented: false)
                ]
            ),
            Conversation(
                id: uid(403), otherTag: "جار #7788", vibe: "⚽",
                lastMessage: "المباراة الليلة بتكون نار، تتوقع كم النتيجة؟",
                lastAt: hoursAgo(1.2), unreadCount: 1, isRequest: false, isBlocked: false,
                messages: [
                    ChatMessage(id: uid(431), text: "هلا، شفتك في قناة الرياضة. تشجع مين؟", isMine: false, createdAt: hoursAgo(5), isMedia: false, mediaConsented: false),
                    ChatMessage(id: uid(432), text: "أشجع الهلال من زمان، وأنت؟", isMine: true, createdAt: hoursAgo(4), isMedia: false, mediaConsented: false),
                    ChatMessage(id: uid(433), text: "المباراة الليلة بتكون نار، تتوقع كم النتيجة؟", isMine: false, createdAt: hoursAgo(1.2), isMedia: false, mediaConsented: false)
                ]
            ),
            Conversation(
                id: uid(404), otherTag: "جار #1122", vibe: "🎮",
                lastMessage: "يريد جار #1122 البدء في مشاركة محتوى مرئي ومسموع في محادثتكما الخاصّة",
                lastAt: hoursAgo(2.5), unreadCount: 0, isRequest: true, isBlocked: false,
                messages: [
                    ChatMessage(id: uid(441), text: "هلا! أدور رفيق لعب، شفت منشورك في قناة القيمنق.", isMine: false, createdAt: hoursAgo(6), isMedia: false, mediaConsented: false),
                    ChatMessage(id: uid(442), text: "هلا فيك، وش تلعب عادة؟", isMine: true, createdAt: hoursAgo(5), isMedia: false, mediaConsented: false),
                    ChatMessage(id: uid(443), text: "يريد جار #1122 البدء في مشاركة محتوى مرئي ومسموع في محادثتكما الخاصّة", isMine: false, createdAt: hoursAgo(2.5), isMedia: false, mediaConsented: false)
                ]
            ),
            Conversation(
                id: uid(405), otherTag: "جار #3344", vibe: "📚",
                lastMessage: "أرسلت لك ملخص المحاضرة، بالتوفيق في الاختبار!",
                lastAt: hoursAgo(7), unreadCount: 0, isRequest: false, isBlocked: false,
                messages: [
                    ChatMessage(id: uid(451), text: "هلا، عندك ملخص محاضرة أمس؟ فاتتني.", isMine: true, createdAt: hoursAgo(8), isMedia: false, mediaConsented: false),
                    ChatMessage(id: uid(452), text: "هلا، إيه عندي. دقيقة وأرسله لك.", isMine: false, createdAt: hoursAgo(7.5), isMedia: false, mediaConsented: false),
                    ChatMessage(id: uid(453), text: "أرسلت لك ملخص المحاضرة، بالتوفيق في الاختبار!", isMine: false, createdAt: hoursAgo(7), isMedia: false, mediaConsented: false)
                ]
            ),
            Conversation(
                id: uid(406), otherTag: "جار #5566", vibe: "🎵",
                lastMessage: "أهلاً، أنا جديد هنا. وش الأجواء عندكم في الحي؟",
                lastAt: hoursAgo(9), unreadCount: 0, isRequest: true, isBlocked: false,
                messages: [
                    ChatMessage(id: uid(461), text: "أهلاً، أنا جديد هنا. وش الأجواء عندكم في الحي؟", isMine: false, createdAt: hoursAgo(9), isMedia: false, mediaConsented: false)
                ]
            )
        ]
    }

    // MARK: - Achievements (8)

    static let achievements: [Achievement] = [
        Achievement(id: "first_post", title: "أول منشور", description: "انشر أول منشور لك في ساحة", icon: "square.and.pencil", isUnlocked: true, progress: 1.0),
        Achievement(id: "first_reply", title: "جار طيب", description: "رد على منشور بأسلوب الجار الطيب", icon: "text.bubble.fill", isUnlocked: true, progress: 1.0),
        Achievement(id: "voter_10", title: "صوتك يفرق", description: "صوّت على 10 منشورات", icon: "hand.thumbsup.fill", isUnlocked: false, progress: 0.6),
        Achievement(id: "karma_100", title: "كارما 100", description: "اجمع 100 نقطة كارما", icon: "star.fill", isUnlocked: false, progress: 0.87),
        Achievement(id: "karma_500", title: "نجم الساحة", description: "اجمع 500 نقطة كارما", icon: "sparkles", isUnlocked: false, progress: 0.17),
        Achievement(id: "top10", title: "ترند", description: "وصل أحد منشوراتك إلى ترند المدينة", icon: "flame.fill", isUnlocked: false, progress: 0.4),
        Achievement(id: "chat_7", title: "اجتماعي", description: "ابدأ 7 محادثات خاصة", icon: "message.fill", isUnlocked: false, progress: 0.28),
        Achievement(id: "daily_7", title: "مواظب", description: "اطلب المكافأة اليومية 7 أيام متتالية", icon: "calendar.badge.checkmark", isUnlocked: false, progress: 0.14)
    ]

    // MARK: - Default profile

    static func defaultProfile() -> UserProfile {
        UserProfile(
            tag: "جار #4821",
            karma: 87,
            level: 1,
            dailyRewardsClaimed: false,
            lastRewardDate: nil,
            boostsAvailable: 3,
            giftsAvailable: 3,
            premiumColorsAvailable: 8,
            language: .arabic,
            notificationsEnabled: true,
            darkMode: false,
            selectedTheme: "green",
            selectedIcon: "default",
            blockedTags: [],
            myPostIds: [uid(108)],
            myVoteCount: 4
        )
    }
}
