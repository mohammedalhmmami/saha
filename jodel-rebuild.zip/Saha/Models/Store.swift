// Store.swift
// Jodel Zero — AppStore: local-first store + ServerClient
// Original code for the Jodel Zero app. SwiftUI + Foundation only, iOS 16, Swift 5.
// Local mode is the default and always works. The server is optional and
// never breaks local mode. No external backend is ever called.

import Foundation
import SwiftUI

// MARK: - Server errors

enum ServerError: Error, LocalizedError {
    case invalidURL
    case requestFailed(String)
    case badStatus(Int)
    case decodingFailed

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "عنوان الخادم غير صحيح."
        case .requestFailed(let message):
            return "تعذّر الاتصال بالخادم: \(message)"
        case .badStatus(let code):
            return "أعاد الخادم رمز الحالة \(code)."
        case .decodingFailed:
            return "تعذّر فهم رد الخادم."
        }
    }
}

// MARK: - Server DTOs (أشكال JSON الفعلية للخادم)
//
// الخادم يرسل snake_case ومعرّفات int وتواريخ ISO8601؛ نماذج التطبيق
// تستخدم camelCase ومعرّفات UUID. هذه الأنواع تطابق JSON حرفياً ثم
// تُحوَّل إلى نماذج التطبيق المحلية. لا تُفكّ نماذج التطبيق مباشرة
// من الخادم أبداً (كانت تفشل بصمت: معرّف int مقابل UUID وحقول ناقصة).

/// يحوّل معرّف خادم int إلى UUID محلي ثابت (نفس المعرّف يعطي نفس UUID
/// دائماً) ليتوافق مع نماذج التطبيق التي تستخدم UUID.
enum ServerIDs {
    /// kind: 0 منشور، 1 قناة، 2 رد، 3 محادثة، 4 رسالة شات، 5 استطلاع، 6 خيار استطلاع.
    static func uuid(kind: Int, id: Int) -> UUID {
        let suffix = String(format: "%02d%010d", kind, id)
        return UUID(uuidString: "00000000-0000-4000-8000-\(suffix)") ?? UUID()
    }

    /// يستخرج معرّف الخادم int من UUID مشتق — nil إن لم يكن UUID خادم.
    static func serverId(from uuid: UUID, kind: Int) -> Int? {
        let text = uuid.uuidString.lowercased()
        guard text.hasPrefix("00000000-0000-4000-8000-") else { return nil }
        let suffix = String(text.suffix(12))
        guard suffix.hasPrefix(String(format: "%02d", kind)) else { return nil }
        return Int(suffix.dropFirst(2))
    }
}

struct ServerPost: Decodable {
    var id: Int
    var text: String
    var imageSymbol: String
    var hashtags: [String]
    var channelId: Int?
    var city: String
    var authorTag: String
    var score: Int
    var upvotes: Int
    var downvotes: Int
    var replyCount: Int
    var createdAt: Date

    func toLocal(myTag: String) -> Post {
        Post(
            id: ServerIDs.uuid(kind: 0, id: id),
            authorTag: authorTag,
            text: text,
            imageSymbol: imageSymbol.isEmpty ? nil : imageSymbol,
            hashtags: hashtags,
            channelId: channelId.map { ServerIDs.uuid(kind: 1, id: $0) },
            city: city.isEmpty ? "الرياض" : city,
            createdAt: createdAt,
            upvotes: upvotes,
            downvotes: downvotes,
            myVote: .none,
            replyCount: replyCount,
            poll: nil,
            postColor: "green",
            isBoosted: false,
            isMine: authorTag == myTag
        )
    }
}

struct ServerChannel: Decodable {
    var id: Int
    var name: String
    var description: String
    var icon: String
    var color: String
    var category: String
    var memberCount: Int
    var postCount: Int
    var createdAt: Date

    func toLocal(isJoined: Bool) -> Channel {
        Channel(
            id: ServerIDs.uuid(kind: 1, id: id),
            name: name,
            description: description,
            icon: ServerChannel.symbolName(from: icon),
            color: ServerChannel.colorName(from: color),
            category: category,
            memberCount: memberCount,
            isJoined: isJoined,
            postCount: postCount
        )
    }

    /// أيقونة الخادم إيموجي؛ التطبيق يعرض أسماء SF Symbols — فإن لم يكن
    /// الاسم اسم رمز صالح نستخدم "number".
    static func symbolName(from icon: String) -> String {
        let trimmed = icon.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return "number" }
        let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-")
        return trimmed.unicodeScalars.allSatisfy { allowed.contains($0) } ? trimmed : "number"
    }

    /// لون الخادم HEX؛ التطبيق يستخدم أسماء ألوان — نطابق الألوان المعروفة
    /// ونعود للأخضر لغيرها.
    static func colorName(from hex: String) -> String {
        switch hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased() {
        case "#0984E3": return "blue"
        case "#00B894": return "teal"
        case "#6C5CE7": return "purple"
        case "#E17055": return "orange"
        case "#E84393": return "pink"
        case "#FDCB6E", "#E8A33D": return "gold"
        case "#D63031": return "red"
        default: return "green"
        }
    }
}

struct ServerReply: Decodable {
    var id: Int
    var postId: Int
    var text: String
    var authorTag: String
    var createdAt: Date

    func toLocal(myTag: String) -> Reply {
        Reply(
            id: ServerIDs.uuid(kind: 2, id: id),
            postId: ServerIDs.uuid(kind: 0, id: postId),
            authorTag: authorTag,
            text: text,
            createdAt: createdAt,
            upvotes: 0,
            downvotes: 0,
            myVote: .none,
            isMine: authorTag == myTag
        )
    }
}

struct ServerChat: Decodable {
    var id: Int
    var otherTag: String
    var createdAt: Date
    var lastMessage: LastMessage?

    struct LastMessage: Decodable {
        var text: String
        var authorTag: String
        var createdAt: Date
    }
}

struct ServerChatMessage: Decodable {
    var id: Int
    var conversationId: Int
    var text: String
    var isMedia: Bool
    var authorTag: String
    var createdAt: Date

    func toLocal(myTag: String) -> ChatMessage {
        ChatMessage(
            id: ServerIDs.uuid(kind: 4, id: id),
            text: text,
            isMine: authorTag == myTag,
            createdAt: createdAt,
            isMedia: isMedia,
            mediaConsented: isMedia ? false : true
        )
    }
}

struct ServerPollOption: Decodable {
    var id: Int
    var text: String
    var votes: Int
}

struct ServerPoll: Decodable {
    var id: Int
    var question: String
    var authorTag: String
    var channelId: Int?
    var options: [ServerPollOption]
    var totalVotes: Int
    var createdAt: Date
}

struct ServerProfile: Decodable {
    var tag: String
    var karma: Int
    var posts: Int
    var replies: Int
    var totalScore: Int
}

struct ServerKarmaClaimResult: Decodable {
    var tag: String
    var claimed: Bool
    var karma: Int
    var reward: Int?
    var reason: String?
}

struct ServerHealth: Decodable {
    var status: String
    var service: String
    var version: String
}

// MARK: - Server request bodies (تُرسل snake_case عبر JSONEncoder)

struct ServerPostCreate: Encodable {
    var text: String
    var imageSymbol: String
    var hashtags: [String]
    var channelId: Int?
    var city: String
    var authorTag: String
}

struct ServerVoteCreate: Encodable {
    var vote: String
    var voterTag: String
}

struct ServerReplyCreate: Encodable {
    var text: String
    var authorTag: String
}

struct ServerChannelCreate: Encodable {
    var name: String
    var description: String
    var icon: String
    var color: String
    var category: String
}

struct ServerTagBody: Encodable {
    var tag: String
}

struct ServerChatCreate: Encodable {
    var tagA: String
    var tagB: String
}

struct ServerChatMessageCreate: Encodable {
    var text: String
    var isMedia: Bool
    var authorTag: String
}

struct ServerPollCreate: Encodable {
    var question: String
    var options: [String]
    var authorTag: String
    var channelId: Int?
}

struct ServerPollVoteCreate: Encodable {
    var optionId: Int
    var voterTag: String
}

struct ServerKarmaClaim: Encodable {
    var tag: String
}

// MARK: - ServerClient

/// Minimal async client for the Jodel Zero server. Local mode never depends on it.
/// All paths are /api/v1/... (matching backend/server.py) and all payloads use
/// the server DTOs above — the local models (UUID ids, camelCase) are NOT
/// decoded directly from the server.
struct ServerClient {
    var baseURL: URL
    var session: URLSession

    init(baseURLString: String = "http://192.3.239.105:8081") {
        if let url = URL(string: baseURLString) {
            self.baseURL = url
        } else {
            self.baseURL = URL(string: "http://192.3.239.105:8081") ?? URL(fileURLWithPath: "/")
        }
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 10
        config.timeoutIntervalForResource = 10
        self.session = URLSession(configuration: config)
    }

    /// مفسّر JSON للخادم: snake_case + تواريخ ISO8601 (مع كسور الثانية أو بدونها).
    private static func decoder() -> JSONDecoder {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        decoder.dateDecodingStrategy = .custom { decoder in
            let container = try decoder.singleValueContainer()
            let text = try container.decode(String.self)
            let withFraction = ISO8601DateFormatter()
            withFraction.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            if let date = withFraction.date(from: text) { return date }
            let plain = ISO8601DateFormatter()
            plain.formatOptions = [.withInternetDateTime]
            if let date = plain.date(from: text) { return date }
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "تاريخ غير صالح: \(text)")
        }
        return decoder
    }

    private static func encoder() -> JSONEncoder {
        let encoder = JSONEncoder()
        encoder.keyEncodingStrategy = .convertToSnakeCase
        return encoder
    }

    private func request(path: String, method: String = "GET", body: Data? = nil) -> URLRequest? {
        guard let url = URL(string: path, relativeTo: baseURL) else { return nil }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = body
        return request
    }

    private func perform<T: Decodable>(_ request: URLRequest) async throws -> T {
        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await session.data(for: request)
        } catch let error {
            throw ServerError.requestFailed(error.localizedDescription)
        }
        guard let http = response as? HTTPURLResponse else {
            throw ServerError.requestFailed("رد غير صالح من الخادم.")
        }
        guard (200..<300).contains(http.statusCode) else {
            throw ServerError.badStatus(http.statusCode)
        }
        guard let decoded = try? Self.decoder().decode(T.self, from: data) else {
            throw ServerError.decodingFailed
        }
        return decoded
    }

    private func encodeBody<T: Encodable>(_ value: T) throws -> Data {
        guard let data = try? Self.encoder().encode(value) else {
            throw ServerError.decodingFailed
        }
        return data
    }

    private func queryEncoded(_ value: String) -> String {
        value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
    }

    /// Quick liveness check. Returns false on any failure instead of throwing.
    func health() async -> Bool {
        guard let request = request(path: "/health") else { return false }
        do {
            let result: ServerHealth = try await perform(request)
            return result.status == "ok"
        } catch {
            return false
        }
    }

    // MARK: Feed & posts

    func fetchPosts(city: String = "", sort: String = "newest") async throws -> [ServerPost] {
        let path = "/api/v1/feed?city=\(queryEncoded(city))&sort=\(queryEncoded(sort))&limit=50"
        guard let request = request(path: path) else { throw ServerError.invalidURL }
        return try await perform(request)
    }

    func sendPost(_ body: ServerPostCreate) async throws -> ServerPost {
        let data = try encodeBody(body)
        guard let request = request(path: "/api/v1/posts", method: "POST", body: data) else {
            throw ServerError.invalidURL
        }
        return try await perform(request)
    }

    func votePost(serverId: Int, vote: Vote, voterTag: String) async throws -> ServerPost {
        let value: String
        switch vote {
        case .up: value = "up"
        case .down: value = "down"
        case .none: value = "none"
        }
        let body = ServerVoteCreate(vote: value, voterTag: voterTag)
        let data = try encodeBody(body)
        guard let request = request(path: "/api/v1/posts/\(serverId)/vote", method: "POST", body: data) else {
            throw ServerError.invalidURL
        }
        return try await perform(request)
    }

    func fetchReplies(postServerId: Int) async throws -> [ServerReply] {
        guard let request = request(path: "/api/v1/posts/\(postServerId)/replies") else { throw ServerError.invalidURL }
        return try await perform(request)
    }

    func sendReply(postServerId: Int, body: ServerReplyCreate) async throws -> ServerReply {
        let data = try encodeBody(body)
        guard let request = request(path: "/api/v1/posts/\(postServerId)/replies", method: "POST", body: data) else {
            throw ServerError.invalidURL
        }
        return try await perform(request)
    }

    // MARK: Channels

    func fetchChannels() async throws -> [ServerChannel] {
        guard let request = request(path: "/api/v1/channels") else { throw ServerError.invalidURL }
        return try await perform(request)
    }

    func createChannel(_ body: ServerChannelCreate) async throws -> ServerChannel {
        let data = try encodeBody(body)
        guard let request = request(path: "/api/v1/channels", method: "POST", body: data) else {
            throw ServerError.invalidURL
        }
        return try await perform(request)
    }

    func joinChannel(serverId: Int, tag: String) async throws {
        let data = try encodeBody(ServerTagBody(tag: tag))
        guard let request = request(path: "/api/v1/channels/\(serverId)/join", method: "POST", body: data) else {
            throw ServerError.invalidURL
        }
        let _: EmptyResponse = try await perform(request)
    }

    func leaveChannel(serverId: Int, tag: String) async throws {
        let data = try encodeBody(ServerTagBody(tag: tag))
        guard let request = request(path: "/api/v1/channels/\(serverId)/leave", method: "POST", body: data) else {
            throw ServerError.invalidURL
        }
        let _: EmptyResponse = try await perform(request)
    }

    func fetchChannelPosts(serverId: Int) async throws -> [ServerPost] {
        guard let request = request(path: "/api/v1/channels/\(serverId)/posts") else { throw ServerError.invalidURL }
        return try await perform(request)
    }

    // MARK: Chat

    func fetchChats(tag: String) async throws -> [ServerChat] {
        guard let request = request(path: "/api/v1/chat?tag=\(queryEncoded(tag))") else { throw ServerError.invalidURL }
        return try await perform(request)
    }

    func fetchChatMessages(conversationServerId: Int) async throws -> [ServerChatMessage] {
        guard let request = request(path: "/api/v1/chat/\(conversationServerId)/messages") else { throw ServerError.invalidURL }
        return try await perform(request)
    }

    func sendChatMessage(conversationServerId: Int, body: ServerChatMessageCreate) async throws -> ServerChatMessage {
        let data = try encodeBody(body)
        guard let request = request(path: "/api/v1/chat/\(conversationServerId)/messages", method: "POST", body: data) else {
            throw ServerError.invalidURL
        }
        return try await perform(request)
    }

    // MARK: Polls

    func fetchPolls() async throws -> [ServerPoll] {
        guard let request = request(path: "/api/v1/polls") else { throw ServerError.invalidURL }
        return try await perform(request)
    }

    func votePoll(pollServerId: Int, optionServerId: Int, voterTag: String) async throws -> ServerPoll {
        let body = ServerPollVoteCreate(optionId: optionServerId, voterTag: voterTag)
        let data = try encodeBody(body)
        guard let request = request(path: "/api/v1/polls/\(pollServerId)/vote", method: "POST", body: data) else {
            throw ServerError.invalidURL
        }
        return try await perform(request)
    }

    // MARK: Profile & karma

    func fetchProfile(tag: String) async throws -> ServerProfile {
        guard let request = request(path: "/api/v1/profile?tag=\(queryEncoded(tag))") else { throw ServerError.invalidURL }
        return try await perform(request)
    }

    func claimKarma(tag: String) async throws -> ServerKarmaClaimResult {
        let data = try encodeBody(ServerKarmaClaim(tag: tag))
        guard let request = request(path: "/api/v1/karma/claim", method: "POST", body: data) else {
            throw ServerError.invalidURL
        }
        return try await perform(request)
    }

    // MARK: Top & search

    func fetchTop(days: Int) async throws -> [ServerPost] {
        guard let request = request(path: "/api/v1/top?days=\(days)&limit=20") else { throw ServerError.invalidURL }
        return try await perform(request)
    }

    func searchPosts(query: String) async throws -> [ServerPost] {
        guard let request = request(path: "/api/v1/search?q=\(queryEncoded(query))&limit=20") else { throw ServerError.invalidURL }
        return try await perform(request)
    }

    private struct EmptyResponse: Decodable {}
}

// MARK: - Saved state

/// Everything persisted under the single UserDefaults key.
struct SavedState: Codable {
    var posts: [Post]
    var replies: [UUID: [Reply]]
    var channels: [Channel]
    var conversations: [Conversation]
    var profile: UserProfile
    var cities: [City]
    var currentCityId: String
    var feedSort: FeedSort
    var messageRequestsEnabled: Bool
    /// وضع الخادم المحفوظ (.local افتراضياً؛ له قيمة افتراضية حتى تظل
    /// البيانات المحفوظة القديمة قابلة للفك).
    var backendMode: BackendMode = .local
}

// MARK: - AppStore

final class AppStore: ObservableObject {
    static let legacyStorageKey = "com.nebra.jodelzero.store.v1"
    static let zeroStorageKey = "com.nebra.jodelzero.zero.v1"
    static let accountsStorageKey = "com.nebra.jodelzero.accounts.v1"

    /// مفتاح حفظ الحالة للحساب النشط الحالي (كل حساب له ملف حفظ خاص به).
    var storageKey: String { activeSlot?.storageKey ?? Self.legacyStorageKey }

    /// الحساب النشط (nil قبل تحميل الحسابات).
    var activeSlot: AccountSlot? { slots.first { $0.id == activeSlotId } }

    @Published var posts: [Post] = []
    @Published var replies: [UUID: [Reply]] = [:]        // postId -> replies
    @Published var channels: [Channel] = []
    @Published var conversations: [Conversation] = []
    @Published var profile: UserProfile
    @Published var cities: [City] = []
    @Published var currentCity: City
    @Published var feedSort: FeedSort = .newest
    @Published var searchText: String = ""
    @Published var isLoading: Bool = false
    @Published var backendMode: BackendMode = .local     // .local | .server
    @Published var messageRequestsEnabled: Bool = true

    // MARK: - Zero settings & accounts

    @Published var zero: ZeroSettings = ZeroSettings()
    @Published var slots: [AccountSlot] = []
    @Published var activeSlotId: UUID = UUID()
    /// يتحول إلى true عند رفض الخادم للطلبات برمز 403 (كشف حظر — نائم حالياً
    /// لأن الخادم لا يعيد 403 أبداً).
    @Published var serverBanned: Bool = false

    var serverClient = ServerClient()

    init() {
        self.profile = SeedData.defaultProfile()
        self.currentCity = SeedData.cities.first(where: { $0.isHometown }) ?? SeedData.cities[0]
        loadZero()
        loadAccounts()
        load()
        applyFontChoice()
    }

    // MARK: - Feed

    /// Feed filtered by current city + search text, ordered by the chosen sort.
    /// Posts hidden by voting (score <= -5) stay in the list so views can
    /// show the "hidden by voting" card instead of silently dropping them.
    func feedPosts() -> [Post] {
        var result = posts.filter { $0.city == currentCity.name }
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        if query.isEmpty == false {
            let lowered = query.lowercased()
            result = result.filter { post in
                post.text.lowercased().contains(lowered)
                    || post.hashtags.contains(where: { $0.lowercased().contains(lowered) })
                    || channelName(for: post)?.lowercased().contains(lowered) == true
            }
        }
        switch feedSort {
        case .newest:
            return result.sorted { $0.createdAt > $1.createdAt }
        case .top:
            return result.sorted { $0.score > $1.score }
        case .commented:
            return result.sorted { $0.replyCount > $1.replyCount }
        }
    }

    /// Trending: top 10 posts from the last `days` days, across all cities.
    func topPosts(days: Int) -> [Post] {
        let cutoff = Date().addingTimeInterval(TimeInterval(-days * 24 * 3600))
        return posts
            .filter { $0.createdAt >= cutoff }
            .sorted { $0.score > $1.score }
            .prefix(10)
            .map { $0 }
    }

    /// Pull-to-refresh: في وضع الخادم يزامن من الخادم مع رجوع تلقائي
    /// للمحلي عند أي فشل؛ في الوضع المحلي تأخير قصير ثم إعادة تحميل.
    func refresh() {
        isLoading = true
        if backendMode == .server {
            Task { @MainActor [weak self] in
                guard let self = self else { return }
                do {
                    try await self.syncFromServer()
                } catch {
                    self.noteServerError(error)
                    self.load()
                }
                self.isLoading = false
            }
        } else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
                guard let self = self else { return }
                self.isLoading = false
                self.load()
            }
        }
    }

    // MARK: - Posting and voting

    func createPost(text: String, imageSymbol: String?, hashtags: [String], channelId: UUID?, imageData: Data? = nil) -> Post {
        let post = Post(
            id: UUID(),
            authorTag: profile.tag,
            text: text,
            imageSymbol: imageSymbol,
            hashtags: hashtags,
            channelId: channelId,
            city: currentCity.name,
            createdAt: Date(),
            upvotes: 0,
            downvotes: 0,
            myVote: .none,
            replyCount: 0,
            poll: nil,
            postColor: "green",
            isBoosted: false,
            isMine: true,
            imageData: imageData
        )
        posts.insert(post, at: 0)
        profile.myPostIds.append(post.id)
        addKarma(KarmaRules.postCreated)
        if let channelId = channelId, let index = channels.firstIndex(where: { $0.id == channelId }) {
            channels[index].postCount += 1
        }
        save()
        // إرسال أفضل جهد للخادم في وضع الخادم (الصور تُرسل كرمز فقط؛
        // الخادم لا يخزّن ملفات صور).
        if backendMode == .server {
            let channelServerId = channelId.flatMap { ServerIDs.serverId(from: $0, kind: 1) }
            let body = ServerPostCreate(
                text: post.text,
                imageSymbol: post.imageSymbol ?? "",
                hashtags: post.hashtags,
                channelId: channelServerId,
                city: post.city,
                authorTag: post.authorTag
            )
            Task { try? await self.serverClient.sendPost(body) }
        }
        return post
    }

    func votePost(_ post: Post, _ vote: Vote) {
        guard let index = posts.firstIndex(where: { $0.id == post.id }) else { return }
        let previous = posts[index].myVote
        if previous == vote {
            // Tapping the same vote again removes it.
            applyVoteDelta(to: &posts[index], removing: previous)
            posts[index].myVote = .none
        } else {
            if previous != .none {
                applyVoteDelta(to: &posts[index], removing: previous)
            }
            applyVoteDelta(to: &posts[index], adding: vote)
            posts[index].myVote = vote
            addKarma(KarmaRules.voteCast)
            profile.myVoteCount += 1
            // Karma for receiving a vote on one of my own posts.
            if posts[index].isMine {
                if vote == .up {
                    addKarma(KarmaRules.receivedUpvote)
                } else if vote == .down {
                    addKarma(KarmaRules.receivedDownvote)
                }
            }
        }
        save()
        // إرسال أفضل جهد للخادم في وضع الخادم (فقط للمنشورات القادمة منه).
        if backendMode == .server,
           let serverId = ServerIDs.serverId(from: post.id, kind: 0),
           let currentVote = posts.first(where: { $0.id == post.id })?.myVote {
            Task { try? await self.serverClient.votePost(serverId: serverId, vote: currentVote, voterTag: self.profile.tag) }
        }
    }

    func addReply(to post: Post, text: String) {
        let reply = Reply(
            id: UUID(),
            postId: post.id,
            authorTag: profile.tag,
            text: text,
            createdAt: Date(),
            upvotes: 0,
            downvotes: 0,
            myVote: .none,
            isMine: true
        )
        var list = replies[post.id] ?? []
        list.append(reply)
        replies[post.id] = list
        if let index = posts.firstIndex(where: { $0.id == post.id }) {
            posts[index].replyCount += 1
        }
        addKarma(KarmaRules.replyCreated)
        save()
        // إرسال أفضل جهد للخادم في وضع الخادم (فقط للمنشورات القادمة منه).
        if backendMode == .server, let serverId = ServerIDs.serverId(from: post.id, kind: 0) {
            let body = ServerReplyCreate(text: text, authorTag: profile.tag)
            Task { try? await self.serverClient.sendReply(postServerId: serverId, body: body) }
        }
    }

    func voteReply(_ reply: Reply, _ vote: Vote) {
        guard var list = replies[reply.postId],
              let index = list.firstIndex(where: { $0.id == reply.id }) else { return }
        let previous = list[index].myVote
        if previous == vote {
            applyReplyVoteDelta(to: &list[index], removing: previous)
            list[index].myVote = .none
        } else {
            if previous != .none {
                applyReplyVoteDelta(to: &list[index], removing: previous)
            }
            applyReplyVoteDelta(to: &list[index], adding: vote)
            list[index].myVote = vote
            addKarma(KarmaRules.voteCast)
            profile.myVoteCount += 1
            if list[index].isMine {
                if vote == .up {
                    addKarma(KarmaRules.receivedUpvote)
                } else if vote == .down {
                    addKarma(KarmaRules.receivedDownvote)
                }
            }
        }
        replies[reply.postId] = list
        save()
    }

    func votePoll(_ post: Post, optionId: UUID) {
        guard let index = posts.firstIndex(where: { $0.id == post.id }),
              var poll = posts[index].poll,
              poll.isActive else { return }
        guard poll.options.contains(where: { $0.id == optionId }) else { return }
        if let previousChoice = poll.myChoice,
           let previousIndex = poll.options.firstIndex(where: { $0.id == previousChoice }) {
            poll.options[previousIndex].votes = max(0, poll.options[previousIndex].votes - 1)
        } else {
            addKarma(KarmaRules.voteCast)
            profile.myVoteCount += 1
        }
        if let optionIndex = poll.options.firstIndex(where: { $0.id == optionId }) {
            poll.options[optionIndex].votes += 1
        }
        poll.myChoice = optionId
        posts[index].poll = poll
        save()
    }

    /// Boosts a post for 10 minutes of extra visibility. Costs 1 boost.
    /// Returns false when no boosts remain or the post is already boosted.
    func boostPost(_ post: Post) -> Bool {
        guard profile.boostsAvailable > 0 else { return false }
        guard let index = posts.firstIndex(where: { $0.id == post.id }),
              posts[index].isBoosted == false else { return false }
        profile.boostsAvailable -= KarmaRules.boostCost
        posts[index].isBoosted = true
        save()
        return true
    }

    // MARK: - Channels

    func joinChannel(_ channel: Channel) {
        guard let index = channels.firstIndex(where: { $0.id == channel.id }),
              channels[index].isJoined == false else { return }
        channels[index].isJoined = true
        channels[index].memberCount += 1
        save()
    }

    func leaveChannel(_ channel: Channel) {
        guard let index = channels.firstIndex(where: { $0.id == channel.id }),
              channels[index].isJoined == true else { return }
        channels[index].isJoined = false
        channels[index].memberCount = max(0, channels[index].memberCount - 1)
        save()
    }

    func createChannel(name: String, description: String, icon: String, color: String, category: String) -> Channel {
        let channel = Channel(
            id: UUID(),
            name: name,
            description: description,
            icon: icon,
            color: color,
            category: category,
            memberCount: 1,
            isJoined: true,
            postCount: 0
        )
        channels.append(channel)
        save()
        return channel
    }

    /// Local-only report: the channel stays visible locally; the report is
    /// recorded by persisting state and would be sent to moderators in server mode.
    func reportChannel(_ channel: Channel) {
        save()
    }

    // MARK: - Chat

    func sendMessage(to conversation: Conversation, text: String, isMedia: Bool) {
        guard let index = conversations.firstIndex(where: { $0.id == conversation.id }) else { return }
        let message = ChatMessage(
            id: UUID(),
            text: text,
            isMine: true,
            createdAt: Date(),
            isMedia: isMedia,
            mediaConsented: isMedia == false
        )
        conversations[index].messages.append(message)
        conversations[index].lastMessage = text
        conversations[index].lastAt = Date()
        conversations[index].unreadCount = 0
        save()
        // إرسال أفضل جهد للخادم في وضع الخادم (فقط للمحادثات القادمة منه).
        if backendMode == .server, let serverId = ServerIDs.serverId(from: conversation.id, kind: 3) {
            let body = ServerChatMessageCreate(text: text, isMedia: isMedia, authorTag: profile.tag)
            Task { try? await self.serverClient.sendChatMessage(conversationServerId: serverId, body: body) }
        }
    }

    /// Grants mutual media consent for media already shared in the conversation.
    /// Media sharing itself always requires this mutual consent first.
    func requestMediaConsent(in conversation: Conversation) {
        guard let index = conversations.firstIndex(where: { $0.id == conversation.id }) else { return }
        for messageIndex in conversations[index].messages.indices where conversations[index].messages[messageIndex].isMedia {
            conversations[index].messages[messageIndex].mediaConsented = true
        }
        save()
    }

    func blockUser(tag: String) {
        if profile.blockedTags.contains(tag) == false {
            profile.blockedTags.append(tag)
        }
        conversations.removeAll { $0.otherTag == tag }
        save()
    }

    func unblockUser(tag: String) {
        profile.blockedTags.removeAll { $0 == tag }
        save()
    }

    func toggleMessageRequests(_ enabled: Bool) {
        messageRequestsEnabled = enabled
        save()
    }

    // MARK: - Karma and rewards

    /// Daily reward: +10 karma, once per calendar day. Returns false if already claimed today.
    func claimDailyReward() -> Bool {
        if let last = profile.lastRewardDate,
           Calendar.current.isDateInToday(last),
           profile.dailyRewardsClaimed {
            return false
        }
        addKarma(KarmaRules.dailyReward)
        profile.dailyRewardsClaimed = true
        profile.lastRewardDate = Date()
        save()
        return true
    }

    func karmaLevel() -> Int {
        KarmaRules.level(forKarma: profile.karma)
    }

    // MARK: - Settings

    func setLanguage(_ language: AppLanguage) {
        profile.language = language
        save()
    }

    func setDarkMode(_ enabled: Bool) {
        profile.darkMode = enabled
        save()
    }

    func setTheme(_ theme: String) {
        profile.selectedTheme = theme
        save()
    }

    func setAppIcon(_ icon: String) {
        profile.selectedIcon = icon
        save()
    }

    /// Deletes all local data and reseeds the demo content.
    func deleteAccount() {
        UserDefaults.standard.removeObject(forKey: storageKey)
        seed()
        save()
    }

    // MARK: - Persistence

    func save() {
        let state = SavedState(
            posts: posts,
            replies: replies,
            channels: channels,
            conversations: conversations,
            profile: profile,
            cities: cities,
            currentCityId: currentCity.id,
            feedSort: feedSort,
            messageRequestsEnabled: messageRequestsEnabled,
            backendMode: backendMode
        )
        if let data = try? JSONEncoder().encode(state) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
    }

    func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let state = try? JSONDecoder().decode(SavedState.self, from: data) else {
            seed()
            return
        }
        posts = state.posts
        replies = state.replies
        channels = state.channels
        conversations = state.conversations
        profile = state.profile
        cities = state.cities.isEmpty ? SeedData.cities : state.cities
        if let city = cities.first(where: { $0.id == state.currentCityId }) {
            currentCity = city
        } else if let hometown = cities.first(where: { $0.isHometown }) {
            currentCity = hometown
        } else if let first = cities.first {
            currentCity = first
        }
        feedSort = state.feedSort
        messageRequestsEnabled = state.messageRequestsEnabled
        backendMode = state.backendMode
        profile.level = karmaLevel()
    }

    // MARK: - Zero settings (#3–#41 من FEATURES.md)

    func loadZero() {
        guard let data = UserDefaults.standard.data(forKey: Self.zeroStorageKey),
              let decoded = try? JSONDecoder().decode(ZeroSettings.self, from: data) else {
            zero = ZeroSettings()
            return
        }
        zero = decoded
    }

    func saveZero() {
        if let data = try? JSONEncoder().encode(zero) {
            UserDefaults.standard.set(data, forKey: Self.zeroStorageKey)
        }
    }

    /// يعيد كل إعدادات Zero إلى الافتراضية (#34).
    func resetZeroSettings() {
        zero = ZeroSettings()
        saveZero()
        applyFontChoice()
    }

    /// يختار خطاً مخصصاً (#14) ويطبّقه فوراً على كل الواجهات.
    func setFontChoice(_ choice: AppFontChoice) {
        zero.fontChoice = choice
        zero.customFonts = true
        saveZero()
        applyFontChoice()
    }

    private func applyFontChoice() {
        if zero.customFonts {
            JodelZeroTheme.useSystemFont = zero.fontChoice == .system
            JodelZeroTheme.customBoldFontName = zero.fontChoice.boldName
            JodelZeroTheme.customBookFontName = zero.fontChoice.bookName
            JodelZeroTheme.customMediumFontName = zero.fontChoice.mediumName
        } else {
            JodelZeroTheme.useSystemFont = false
            JodelZeroTheme.customBoldFontName = nil
            JodelZeroTheme.customBookFontName = nil
            JodelZeroTheme.customMediumFontName = nil
        }
    }

    // MARK: - Account manager (#19 — حتى 3 حسابات محلية)

    func loadAccounts() {
        if let data = UserDefaults.standard.data(forKey: Self.accountsStorageKey),
           let store = try? JSONDecoder().decode(AccountStore.self, from: data),
           store.slots.isEmpty == false {
            slots = store.slots
            activeSlotId = store.activeSlotId
            if slots.contains(where: { $0.id == activeSlotId }) == false {
                activeSlotId = slots[0].id
            }
            return
        }
        // الترحيل: حساب واحد بالمفتاح القديم يحمل بيانات المستخدم الحالية.
        let slot = AccountSlot(id: UUID(), name: "الحساب الرئيسي", tag: profile.tag, storageKey: Self.legacyStorageKey)
        slots = [slot]
        activeSlotId = slot.id
        saveAccounts()
    }

    func saveAccounts() {
        let store = AccountStore(slots: slots, activeSlotId: activeSlotId)
        if let data = try? JSONEncoder().encode(store) {
            UserDefaults.standard.set(data, forKey: Self.accountsStorageKey)
        }
    }

    /// يبدّل إلى حساب آخر (يحفظ الحالي أولاً). لا يفعل شيئاً للحساب النشط.
    func switchAccount(to slot: AccountSlot) {
        guard slots.contains(where: { $0.id == slot.id }), slot.id != activeSlotId else { return }
        save()
        activeSlotId = slot.id
        saveAccounts()
        load()
        if profile.tag != slot.tag {
            profile.tag = slot.tag
            save()
        }
    }

    /// ينشئ حساباً جديداً بوسم عشوائي ويبدّل إليه. يعيد false عند بلوغ
    /// الحد الأقصى (3 حسابات).
    func createAccount(name: String) -> Bool {
        guard slots.count < 3 else { return false }
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let slotName = trimmed.isEmpty ? "الحساب \(slots.count + 1)" : trimmed
        var tag = "جار #\(Int.random(in: 1000...9999))"
        while slots.contains(where: { $0.tag == tag }) {
            tag = "جار #\(Int.random(in: 1000...9999))"
        }
        save()
        let slotId = UUID()
        let slot = AccountSlot(id: slotId, name: slotName, tag: tag, storageKey: "com.nebra.jodelzero.account.\(slotId.uuidString)")
        slots.append(slot)
        activeSlotId = slotId
        saveAccounts()
        load()
        if profile.tag != tag {
            profile.tag = tag
            save()
        }
        return true
    }

    func renameAccount(_ slot: AccountSlot, newName: String) {
        let trimmed = newName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.isEmpty == false, let index = slots.firstIndex(where: { $0.id == slot.id }) else { return }
        slots[index].name = trimmed
        saveAccounts()
    }

    /// يحذف حساباً (لا يمكن حذف الأخير). يعيد false عند الرفض.
    func deleteAccountSlot(_ slot: AccountSlot) -> Bool {
        guard slots.count > 1, let index = slots.firstIndex(where: { $0.id == slot.id }) else { return false }
        UserDefaults.standard.removeObject(forKey: slot.storageKey)
        slots.remove(at: index)
        if slot.id == activeSlotId, let first = slots.first {
            activeSlotId = first.id
            saveAccounts()
            load()
            if profile.tag != first.tag {
                profile.tag = first.tag
                save()
            }
        } else {
            saveAccounts()
        }
        return true
    }

    // MARK: - Follow status (#31 — أنا أتابعهم)

    func isFollowing(tag: String) -> Bool { zero.followedTags.contains(tag) }

    func toggleFollow(tag: String) {
        if zero.followedTags.contains(tag) {
            zero.followedTags.removeAll { $0 == tag }
        } else {
            zero.followedTags.append(tag)
        }
        saveZero()
    }

    // MARK: - Copy history (#12 — آخر 50 نصاً)

    func addCopiedText(_ text: String) {
        guard zero.copyHistoryEnabled else { return }
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.isEmpty == false else { return }
        zero.copyHistory.removeAll { $0.text == trimmed }
        zero.copyHistory.insert(CopiedText(id: UUID(), text: trimmed, createdAt: Date()), at: 0)
        if zero.copyHistory.count > 50 {
            zero.copyHistory = Array(zero.copyHistory.prefix(50))
        }
        saveZero()
    }

    func clearCopyHistory() {
        zero.copyHistory = []
        saveZero()
    }

    func deleteCopiedText(_ item: CopiedText) {
        zero.copyHistory.removeAll { $0.id == item.id }
        saveZero()
    }

    // MARK: - Chat extras (#21، #27)

    /// يحذف رسالة؛ إن كان «الاحتفاظ بالرسائل المحذوفة» مفعّلاً تُبقى ظاهرة
    /// كـ «رسالة محذوفة» بدل إزالتها.
    func deleteMessage(_ message: ChatMessage, in conversation: Conversation) {
        guard let index = conversations.firstIndex(where: { $0.id == conversation.id }),
              let messageIndex = conversations[index].messages.firstIndex(where: { $0.id == message.id }) else { return }
        if zero.keepDeletedMessages {
            conversations[index].messages[messageIndex].isDeleted = true
        } else {
            conversations[index].messages.remove(at: messageIndex)
        }
        save()
    }

    /// يرسل ملفاً صوتياً من «الملفات» إلى المحادثة (#27 جزئياً: إرسال ملف
    /// صوتي جاهز؛ تسجيل الصوت داخل التطبيق واستخراج الصوت من فيديو غير منفذين).
    func sendAudioMessage(to conversation: Conversation, fileURL: URL) {
        guard let index = conversations.firstIndex(where: { $0.id == conversation.id }) else { return }
        let fileName = "\(UUID().uuidString).\(fileURL.pathExtension.isEmpty ? "m4a" : fileURL.pathExtension)"
        let audioDir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("audio", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: audioDir, withIntermediateDirectories: true)
            let destination = audioDir.appendingPathComponent(fileName)
            if FileManager.default.fileExists(atPath: destination.path) {
                try FileManager.default.removeItem(at: destination)
            }
            try FileManager.default.copyItem(at: fileURL, to: destination)
        } catch {
            return
        }
        let message = ChatMessage(
            id: UUID(),
            text: "رسالة صوتية: \(fileURL.lastPathComponent)",
            isMine: true,
            createdAt: Date(),
            isMedia: true,
            mediaConsented: true,
            audioFileName: fileName
        )
        conversations[index].messages.append(message)
        conversations[index].lastMessage = "رسالة صوتية"
        conversations[index].lastAt = Date()
        conversations[index].unreadCount = 0
        save()
    }

    /// مسار ملف صوتي محفوظ (للتشغيل عبر AVAudioPlayer في ChatView).
    static func audioFileURL(fileName: String) -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("audio", isDirectory: true)
            .appendingPathComponent(fileName)
    }

    /// يمسح كل بيانات التطبيق (كل الحسابات + إعدادات Zero) ويعيد التهيئة (#35).
    func eraseAllData() {
        for slot in slots {
            UserDefaults.standard.removeObject(forKey: slot.storageKey)
        }
        UserDefaults.standard.removeObject(forKey: Self.legacyStorageKey)
        UserDefaults.standard.removeObject(forKey: Self.zeroStorageKey)
        UserDefaults.standard.removeObject(forKey: Self.accountsStorageKey)
        zero = ZeroSettings()
        applyFontChoice()
        slots = []
        activeSlotId = UUID()
        backendMode = .local
        serverBanned = false
        seed()
        loadAccounts()
        save()
    }

    // MARK: - Server sync

    /// يزامن الخلاصة والقنوات والمحادثات والكارما من الخادم. يرمي عند أي فشل
    /// ليعود المتصل إلى الوضع المحلي. لا يُستدعى إلا في وضع الخادم.
    /// يعمل على MainActor لأنه يكتب في @Published.
    @MainActor
    func syncFromServer() async throws {
        guard await serverClient.health() else {
            throw ServerError.requestFailed("الخادم غير متاح.")
        }
        let serverPosts = try await serverClient.fetchPosts(city: currentCity.name, sort: feedSort.rawValue)
        let serverChannels = try await serverClient.fetchChannels()
        let myTag = profile.tag
        let joinedNames = Set(channels.filter { $0.isJoined }.map { $0.name })
        posts = serverPosts.map { $0.toLocal(myTag: myTag) }
        channels = serverChannels.map { serverChannel in
            var channel = serverChannel.toLocal(isJoined: false)
            if joinedNames.contains(channel.name) { channel.isJoined = true }
            return channel
        }
        // المحادثات: تُجلب مع رسائلها؛ فشلها لا يفشل المزامنة كلها.
        if let serverChats = try? await serverClient.fetchChats(tag: myTag) {
            var synced: [Conversation] = []
            for chat in serverChats {
                let messages = (try? await serverClient.fetchChatMessages(conversationServerId: chat.id)) ?? []
                let localMessages = messages.map { $0.toLocal(myTag: myTag) }
                let last = localMessages.last
                synced.append(Conversation(
                    id: ServerIDs.uuid(kind: 3, id: chat.id),
                    otherTag: chat.otherTag,
                    vibe: "🙂",
                    lastMessage: last?.text ?? "",
                    lastAt: last?.createdAt ?? chat.createdAt,
                    unreadCount: 0,
                    isRequest: false,
                    isBlocked: false,
                    messages: localMessages
                ))
            }
            conversations = synced
        }
        // الكارما من الخادم.
        if let serverProfile = try? await serverClient.fetchProfile(tag: myTag) {
            profile.karma = serverProfile.karma
            profile.level = karmaLevel()
        }
        save()
    }

    /// يفعّل وضع الخادم بعد فحص صحته ومزامنة أولية. يعيد false ويبقى محلياً
    /// عند أي فشل (الخادم غير متاح) — وهذا ما يجعل الافتراضي .local آمناً.
    @MainActor
    func enableServerMode() async -> Bool {
        guard await serverClient.health() else { return false }
        do {
            try await syncFromServer()
        } catch {
            noteServerError(error)
            return false
        }
        backendMode = .server
        save()
        return true
    }

    func disableServerMode() {
        backendMode = .local
        serverBanned = false
        save()
        load()
    }

    /// كشف حظر (#20): رفض الخادم برمز 403 يرفع علم serverBanned.
    /// الخادم الحالي لا يعيد 403 أبداً، فهذه الميزة نائمة.
    private func noteServerError(_ error: Error) {
        if case ServerError.badStatus(let code) = error, code == 403 {
            serverBanned = true
        }
    }

    // MARK: - Private helpers

    private func seed() {
        posts = SeedData.posts()
        replies = SeedData.replies()
        channels = SeedData.channels()
        conversations = SeedData.conversations()
        cities = SeedData.cities
        profile = SeedData.defaultProfile()
        currentCity = cities.first(where: { $0.isHometown }) ?? cities[0]
        feedSort = .newest
        messageRequestsEnabled = true
    }

    private func addKarma(_ amount: Int) {
        profile.karma = max(0, profile.karma + amount)
        profile.level = karmaLevel()
    }

    private func applyVoteDelta(to post: inout Post, adding vote: Vote) {
        if vote == .up {
            post.upvotes += 1
        } else if vote == .down {
            post.downvotes += 1
        }
    }

    private func applyVoteDelta(to post: inout Post, removing vote: Vote) {
        if vote == .up {
            post.upvotes = max(0, post.upvotes - 1)
        } else if vote == .down {
            post.downvotes = max(0, post.downvotes - 1)
        }
    }

    private func applyReplyVoteDelta(to reply: inout Reply, adding vote: Vote) {
        if vote == .up {
            reply.upvotes += 1
        } else if vote == .down {
            reply.downvotes += 1
        }
    }

    private func applyReplyVoteDelta(to reply: inout Reply, removing vote: Vote) {
        if vote == .up {
            reply.upvotes = max(0, reply.upvotes - 1)
        } else if vote == .down {
            reply.downvotes = max(0, reply.downvotes - 1)
        }
    }

    private func channelName(for post: Post) -> String? {
        guard let channelId = post.channelId else { return nil }
        return channels.first(where: { $0.id == channelId })?.name
    }
}
