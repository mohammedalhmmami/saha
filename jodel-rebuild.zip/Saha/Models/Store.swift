// Store.swift
// ساحة (Saha) — AppStore: local-first store + ServerClient
// Original code for the Saha app. SwiftUI + Foundation only, iOS 16, Swift 5.
// Local mode is the default and always works. The server is optional and
// never breaks local mode. No external backend is ever called.

import Foundation
import SwiftUI

// MARK: - Server errors

enum ServerError: Error, LocalizedError {
    case invalidURL
    case requestFailed(String)
    case badStatus(Int)
    case decodingFailed

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "عنوان الخادم غير صحيح."
        case .requestFailed(let message):
            return "تعذّر الاتصال بالخادم: \(message)"
        case .badStatus(let code):
            return "أعاد الخادم رمز الحالة \(code)."
        case .decodingFailed:
            return "تعذّر فهم رد الخادم."
        }
    }
}

// MARK: - ServerClient

/// Minimal async client for the Saha server. Local mode never depends on it.
struct ServerClient {
    var baseURL: URL
    var session: URLSession

    init(baseURLString: String = "http://192.3.239.105:8081") {
        if let url = URL(string: baseURLString) {
            self.baseURL = url
        } else {
            self.baseURL = URL(string: "http://192.3.239.105:8081") ?? URL(fileURLWithPath: "/")
        }
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 10
        config.timeoutIntervalForResource = 10
        self.session = URLSession(configuration: config)
    }

    private func request(path: String, method: String = "GET", body: Data? = nil) -> URLRequest? {
        guard let url = URL(string: path, relativeTo: baseURL) else { return nil }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = body
        return request
    }

    private func perform<T: Decodable>(_ request: URLRequest) async throws -> T {
        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await session.data(for: request)
        } catch let error {
            throw ServerError.requestFailed(error.localizedDescription)
        }
        guard let http = response as? HTTPURLResponse else {
            throw ServerError.requestFailed("رد غير صالح من الخادم.")
        }
        guard (200..<300).contains(http.statusCode) else {
            throw ServerError.badStatus(http.statusCode)
        }
        guard let decoded = try? JSONDecoder().decode(T.self, from: data) else {
            throw ServerError.decodingFailed
        }
        return decoded
    }

    /// Quick liveness check. Returns false on any failure instead of throwing.
    func health() async -> Bool {
        guard let request = request(path: "/health") else { return false }
        do {
            let _: EmptyResponse = try await perform(request)
            return true
        } catch {
            return false
        }
    }

    func fetchPosts() async throws -> [Post] {
        guard let request = request(path: "/api/posts") else { throw ServerError.invalidURL }
        return try await perform(request)
    }

    func sendPost(_ post: Post) async throws -> Post {
        guard let body = try? JSONEncoder().encode(post) else { throw ServerError.decodingFailed }
        guard let request = request(path: "/api/posts", method: "POST", body: body) else {
            throw ServerError.invalidURL
        }
        return try await perform(request)
    }

    func fetchChannels() async throws -> [Channel] {
        guard let request = request(path: "/api/channels") else { throw ServerError.invalidURL }
        return try await perform(request)
    }

    private struct EmptyResponse: Decodable {}
}

// MARK: - Saved state

/// Everything persisted under the single UserDefaults key.
struct SavedState: Codable {
    var posts: [Post]
    var replies: [UUID: [Reply]]
    var channels: [Channel]
    var conversations: [Conversation]
    var profile: UserProfile
    var cities: [City]
    var currentCityId: String
    var feedSort: FeedSort
    var messageRequestsEnabled: Bool
}

// MARK: - AppStore

final class AppStore: ObservableObject {
    static let storageKey = "com.nebra.saha.store.v1"

    @Published var posts: [Post] = []
    @Published var replies: [UUID: [Reply]] = [:]        // postId -> replies
    @Published var channels: [Channel] = []
    @Published var conversations: [Conversation] = []
    @Published var profile: UserProfile
    @Published var cities: [City] = []
    @Published var currentCity: City
    @Published var feedSort: FeedSort = .newest
    @Published var searchText: String = ""
    @Published var isLoading: Bool = false
    @Published var backendMode: BackendMode = .local     // .local | .server
    @Published var messageRequestsEnabled: Bool = true

    var serverClient = ServerClient()

    init() {
        self.profile = SeedData.defaultProfile()
        self.currentCity = SeedData.cities.first(where: { $0.isHometown }) ?? SeedData.cities[0]
        load()
    }

    // MARK: - Feed

    /// Feed filtered by current city + search text, ordered by the chosen sort.
    /// Posts hidden by voting (score <= -5) stay in the list so views can
    /// show the "hidden by voting" card instead of silently dropping them.
    func feedPosts() -> [Post] {
        var result = posts.filter { $0.city == currentCity.name }
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        if query.isEmpty == false {
            let lowered = query.lowercased()
            result = result.filter { post in
                post.text.lowercased().contains(lowered)
                    || post.hashtags.contains(where: { $0.lowercased().contains(lowered) })
                    || channelName(for: post)?.lowercased().contains(lowered) == true
            }
        }
        switch feedSort {
        case .newest:
            return result.sorted { $0.createdAt > $1.createdAt }
        case .top:
            return result.sorted { $0.score > $1.score }
        case .commented:
            return result.sorted { $0.replyCount > $1.replyCount }
        }
    }

    /// Trending: top 10 posts from the last `days` days, across all cities.
    func topPosts(days: Int) -> [Post] {
        let cutoff = Date().addingTimeInterval(TimeInterval(-days * 24 * 3600))
        return posts
            .filter { $0.createdAt >= cutoff }
            .sorted { $0.score > $1.score }
            .prefix(10)
            .map { $0 }
    }

    /// Pull-to-refresh: short simulated network delay, then reloads local state.
    func refresh() {
        isLoading = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
            guard let self = self else { return }
            self.isLoading = false
            self.load()
        }
    }

    // MARK: - Posting and voting

    func createPost(text: String, imageSymbol: String?, hashtags: [String], channelId: UUID?) -> Post {
        let post = Post(
            id: UUID(),
            authorTag: profile.tag,
            text: text,
            imageSymbol: imageSymbol,
            hashtags: hashtags,
            channelId: channelId,
            city: currentCity.name,
            createdAt: Date(),
            upvotes: 0,
            downvotes: 0,
            myVote: .none,
            replyCount: 0,
            poll: nil,
            postColor: "green",
            isBoosted: false,
            isMine: true
        )
        posts.insert(post, at: 0)
        profile.myPostIds.append(post.id)
        addKarma(KarmaRules.postCreated)
        if let channelId = channelId, let index = channels.firstIndex(where: { $0.id == channelId }) {
            channels[index].postCount += 1
        }
        save()
        return post
    }

    func votePost(_ post: Post, _ vote: Vote) {
        guard let index = posts.firstIndex(where: { $0.id == post.id }) else { return }
        let previous = posts[index].myVote
        if previous == vote {
            // Tapping the same vote again removes it.
            applyVoteDelta(to: &posts[index], removing: previous)
            posts[index].myVote = .none
        } else {
            if previous != .none {
                applyVoteDelta(to: &posts[index], removing: previous)
            }
            applyVoteDelta(to: &posts[index], adding: vote)
            posts[index].myVote = vote
            addKarma(KarmaRules.voteCast)
            profile.myVoteCount += 1
            // Karma for receiving a vote on one of my own posts.
            if posts[index].isMine {
                if vote == .up {
                    addKarma(KarmaRules.receivedUpvote)
                } else if vote == .down {
                    addKarma(KarmaRules.receivedDownvote)
                }
            }
        }
        save()
    }

    func addReply(to post: Post, text: String) {
        let reply = Reply(
            id: UUID(),
            postId: post.id,
            authorTag: profile.tag,
            text: text,
            createdAt: Date(),
            upvotes: 0,
            downvotes: 0,
            myVote: .none,
            isMine: true
        )
        var list = replies[post.id] ?? []
        list.append(reply)
        replies[post.id] = list
        if let index = posts.firstIndex(where: { $0.id == post.id }) {
            posts[index].replyCount += 1
        }
        addKarma(KarmaRules.replyCreated)
        save()
    }

    func voteReply(_ reply: Reply, _ vote: Vote) {
        guard var list = replies[reply.postId],
              let index = list.firstIndex(where: { $0.id == reply.id }) else { return }
        let previous = list[index].myVote
        if previous == vote {
            applyReplyVoteDelta(to: &list[index], removing: previous)
            list[index].myVote = .none
        } else {
            if previous != .none {
                applyReplyVoteDelta(to: &list[index], removing: previous)
            }
            applyReplyVoteDelta(to: &list[index], adding: vote)
            list[index].myVote = vote
            addKarma(KarmaRules.voteCast)
            profile.myVoteCount += 1
            if list[index].isMine {
                if vote == .up {
                    addKarma(KarmaRules.receivedUpvote)
                } else if vote == .down {
                    addKarma(KarmaRules.receivedDownvote)
                }
            }
        }
        replies[reply.postId] = list
        save()
    }

    func votePoll(_ post: Post, optionId: UUID) {
        guard let index = posts.firstIndex(where: { $0.id == post.id }),
              var poll = posts[index].poll,
              poll.isActive else { return }
        guard poll.options.contains(where: { $0.id == optionId }) else { return }
        if let previousChoice = poll.myChoice,
           let previousIndex = poll.options.firstIndex(where: { $0.id == previousChoice }) {
            poll.options[previousIndex].votes = max(0, poll.options[previousIndex].votes - 1)
        } else {
            addKarma(KarmaRules.voteCast)
            profile.myVoteCount += 1
        }
        if let optionIndex = poll.options.firstIndex(where: { $0.id == optionId }) {
            poll.options[optionIndex].votes += 1
        }
        poll.myChoice = optionId
        posts[index].poll = poll
        save()
    }

    /// Boosts a post for 10 minutes of extra visibility. Costs 1 boost.
    /// Returns false when no boosts remain or the post is already boosted.
    func boostPost(_ post: Post) -> Bool {
        guard profile.boostsAvailable > 0 else { return false }
        guard let index = posts.firstIndex(where: { $0.id == post.id }),
              posts[index].isBoosted == false else { return false }
        profile.boostsAvailable -= KarmaRules.boostCost
        posts[index].isBoosted = true
        save()
        return true
    }

    // MARK: - Channels

    func joinChannel(_ channel: Channel) {
        guard let index = channels.firstIndex(where: { $0.id == channel.id }),
              channels[index].isJoined == false else { return }
        channels[index].isJoined = true
        channels[index].memberCount += 1
        save()
    }

    func leaveChannel(_ channel: Channel) {
        guard let index = channels.firstIndex(where: { $0.id == channel.id }),
              channels[index].isJoined == true else { return }
        channels[index].isJoined = false
        channels[index].memberCount = max(0, channels[index].memberCount - 1)
        save()
    }

    func createChannel(name: String, description: String, icon: String, color: String, category: String) -> Channel {
        let channel = Channel(
            id: UUID(),
            name: name,
            description: description,
            icon: icon,
            color: color,
            category: category,
            memberCount: 1,
            isJoined: true,
            postCount: 0
        )
        channels.append(channel)
        save()
        return channel
    }

    /// Local-only report: the channel stays visible locally; the report is
    /// recorded by persisting state and would be sent to moderators in server mode.
    func reportChannel(_ channel: Channel) {
        save()
    }

    // MARK: - Chat

    func sendMessage(to conversation: Conversation, text: String, isMedia: Bool) {
        guard let index = conversations.firstIndex(where: { $0.id == conversation.id }) else { return }
        let message = ChatMessage(
            id: UUID(),
            text: text,
            isMine: true,
            createdAt: Date(),
            isMedia: isMedia,
            mediaConsented: isMedia == false
        )
        conversations[index].messages.append(message)
        conversations[index].lastMessage = text
        conversations[index].lastAt = Date()
        conversations[index].unreadCount = 0
        save()
    }

    /// Grants mutual media consent for media already shared in the conversation.
    /// Media sharing itself always requires this mutual consent first.
    func requestMediaConsent(in conversation: Conversation) {
        guard let index = conversations.firstIndex(where: { $0.id == conversation.id }) else { return }
        for messageIndex in conversations[index].messages.indices where conversations[index].messages[messageIndex].isMedia {
            conversations[index].messages[messageIndex].mediaConsented = true
        }
        save()
    }

    func blockUser(tag: String) {
        if profile.blockedTags.contains(tag) == false {
            profile.blockedTags.append(tag)
        }
        conversations.removeAll { $0.otherTag == tag }
        save()
    }

    func unblockUser(tag: String) {
        profile.blockedTags.removeAll { $0 == tag }
        save()
    }

    func toggleMessageRequests(_ enabled: Bool) {
        messageRequestsEnabled = enabled
        save()
    }

    // MARK: - Karma and rewards

    /// Daily reward: +10 karma, once per calendar day. Returns false if already claimed today.
    func claimDailyReward() -> Bool {
        if let last = profile.lastRewardDate,
           Calendar.current.isDateInToday(last),
           profile.dailyRewardsClaimed {
            return false
        }
        addKarma(KarmaRules.dailyReward)
        profile.dailyRewardsClaimed = true
        profile.lastRewardDate = Date()
        save()
        return true
    }

    func karmaLevel() -> Int {
        KarmaRules.level(forKarma: profile.karma)
    }

    // MARK: - Settings

    func setLanguage(_ language: AppLanguage) {
        profile.language = language
        save()
    }

    func setDarkMode(_ enabled: Bool) {
        profile.darkMode = enabled
        save()
    }

    func setTheme(_ theme: String) {
        profile.selectedTheme = theme
        save()
    }

    func setAppIcon(_ icon: String) {
        profile.selectedIcon = icon
        save()
    }

    /// Deletes all local data and reseeds the demo content.
    func deleteAccount() {
        UserDefaults.standard.removeObject(forKey: Self.storageKey)
        seed()
        save()
    }

    // MARK: - Persistence

    func save() {
        let state = SavedState(
            posts: posts,
            replies: replies,
            channels: channels,
            conversations: conversations,
            profile: profile,
            cities: cities,
            currentCityId: currentCity.id,
            feedSort: feedSort,
            messageRequestsEnabled: messageRequestsEnabled
        )
        if let data = try? JSONEncoder().encode(state) {
            UserDefaults.standard.set(data, forKey: Self.storageKey)
        }
    }

    func load() {
        guard let data = UserDefaults.standard.data(forKey: Self.storageKey),
              let state = try? JSONDecoder().decode(SavedState.self, from: data) else {
            seed()
            return
        }
        posts = state.posts
        replies = state.replies
        channels = state.channels
        conversations = state.conversations
        profile = state.profile
        cities = state.cities.isEmpty ? SeedData.cities : state.cities
        if let city = cities.first(where: { $0.id == state.currentCityId }) {
            currentCity = city
        } else if let hometown = cities.first(where: { $0.isHometown }) {
            currentCity = hometown
        } else if let first = cities.first {
            currentCity = first
        }
        feedSort = state.feedSort
        messageRequestsEnabled = state.messageRequestsEnabled
        profile.level = karmaLevel()
    }

    // MARK: - Private helpers

    private func seed() {
        posts = SeedData.posts()
        replies = SeedData.replies()
        channels = SeedData.channels()
        conversations = SeedData.conversations()
        cities = SeedData.cities
        profile = SeedData.defaultProfile()
        currentCity = cities.first(where: { $0.isHometown }) ?? cities[0]
        feedSort = .newest
        messageRequestsEnabled = true
    }

    private func addKarma(_ amount: Int) {
        profile.karma = max(0, profile.karma + amount)
        profile.level = karmaLevel()
    }

    private func applyVoteDelta(to post: inout Post, adding vote: Vote) {
        if vote == .up {
            post.upvotes += 1
        } else if vote == .down {
            post.downvotes += 1
        }
    }

    private func applyVoteDelta(to post: inout Post, removing vote: Vote) {
        if vote == .up {
            post.upvotes = max(0, post.upvotes - 1)
        } else if vote == .down {
            post.downvotes = max(0, post.downvotes - 1)
        }
    }

    private func applyReplyVoteDelta(to reply: inout Reply, adding vote: Vote) {
        if vote == .up {
            reply.upvotes += 1
        } else if vote == .down {
            reply.downvotes += 1
        }
    }

    private func applyReplyVoteDelta(to reply: inout Reply, removing vote: Vote) {
        if vote == .up {
            reply.upvotes = max(0, reply.upvotes - 1)
        } else if vote == .down {
            reply.downvotes = max(0, reply.downvotes - 1)
        }
    }

    private func channelName(for post: Post) -> String? {
        guard let channelId = post.channelId else { return nil }
        return channels.first(where: { $0.id == channelId })?.name
    }
}
